# Agent 21 — agent-21

Role: agent-21
Workspace: multi-agents/workspaces/
Branch: factory-2 (or dedicated sub-branch)
Connected apps: Linear (issues), Notion (docs), Gmail (notifications)
Real task: Review one PR item per session. No canned output.
Evidence required: Every verdict must reference a file or line.
