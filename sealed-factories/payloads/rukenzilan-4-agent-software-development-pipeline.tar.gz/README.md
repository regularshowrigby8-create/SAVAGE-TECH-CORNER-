# 4-Agent Software Development Pipeline

An interactive HTML artifact that simulates a 4-agent software development team using the Claude API. Enter a feature request, and four AI agents run in sequence — each one building on the previous agent's output — to take it from idea to reviewed code.

File: `dort_ajanli_gelistirme_hatti.html`

URL: https://rukenzilan.github.io/4-Agent-Software-Development-Pipeline/

## What it does

You describe a feature. The pipeline runs four agents, one after another:

| # | Agent | Role |
|---|-------|------|
| 01 | **Product Manager** | Turns the feature request into a problem statement, user stories, and acceptance criteria |
| 02 | **Developer** | Writes a working code implementation that satisfies the acceptance criteria |
| 03 | **QA Engineer** | Critically tests the code — edge cases, bugs, pass/fail per acceptance criterion |
| 04 | **Reviewer** | Final gate. Produces two dedicated sections — a **security audit** (injection risks, unvalidated input, unsafe eval/exec, credential handling, etc.) and a **truthfulness check** (whether the Developer's and QA's claims actually match what the code does) — then issues a verdict: Approved / Approved with changes / Rejected |

Each stage streams into a card connected by a vertical progress rail; the rail fills in as agents complete their work.

## How it works

- Built as a single self-contained HTML file (CSS + JS inline), following the artifact conventions for the Claude.ai environment.
- Each agent is a separate call to `https://api.anthropic.com/v1/messages` using `claude-sonnet-4-6`, with a distinct `system` prompt defining that agent's role.
- Agents are chained manually: each call's user message includes the accumulated output of prior agents (requirements → code → QA findings), so context carries forward through the pipeline.
- No API key handling is needed — this only works when opened inside a Claude.ai artifact, which proxies the request.
- A lightweight custom Markdown renderer (bold, inline code, fenced code blocks, bullet lists) formats each agent's raw text response into the UI.
- The Reviewer's verdict badge (pass/warn/fail) is derived by scanning the response text for verdict keywords in the active language.

## Language toggle

A **TR / EN** switch in the top-right corner controls:
- All interface labels, statuses, and hints
- The default example feature request
- The system prompts sent to each agent, so the agents themselves respond in the selected language

Switching languages does not erase anything you've typed into the feature request box.

## Using it

1. Open the file (as a Claude.ai artifact, or re-upload it into a conversation).
2. Edit the feature request, or leave the pre-filled example (a login flow with lockout after failed attempts).
3. Click **Run pipeline**. Watch each stage light up as its agent runs.
4. Read the Reviewer's security and truthfulness sections before trusting the output.
5. Click **Reset** to clear all stages and run again with a new request.

## Limitations

- Agents reason about the code; they don't execute or unit-test it. QA's "bugs found" and the Reviewer's "security findings" are based on code reading, not runtime verification.
- Each agent is capped at 1000 output tokens, so very large or complex features may get truncated responses.
- The verdict-keyword detection is a simple heuristic, not a strict parse — for anything you plan to act on, read the actual verdict paragraph rather than relying solely on the badge color.
- This is a demonstration of multi-agent orchestration patterns (sequential hand-off, role specialization, a dedicated review/audit gate), not a substitute for a real code review or security audit process.

## Customizing

- **Add a 5th agent** (e.g. a deployment/DevOps agent) by adding a new stage card, rail node, and `callClaude()` step that consumes the Reviewer's output.
- **Change the model** by editing the `model` field in the `callClaude()` function.
- **Adjust agent behavior** by editing the `systems.pm` / `systems.dev` / `systems.qa` / `systems.review` prompts in the `STR.tr` / `STR.en` objects near the top of the `<script>` block.
- **Add a third language** by adding a new key alongside `tr` and `en` in the `STR` object and a matching toggle button.
