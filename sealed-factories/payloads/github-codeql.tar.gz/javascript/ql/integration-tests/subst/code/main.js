function interesting() { }
