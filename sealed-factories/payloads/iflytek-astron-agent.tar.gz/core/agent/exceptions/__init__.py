"""Agent exceptions module."""
