borrowed from obra/superpowers
