"""Prompt management functionality."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from mcp_types import INVALID_PARAMS, InputRequiredResult

from mcp.server.mcpserver.prompts.base import Message, Prompt
from mcp.server.mcpserver.utilities.logging import get_logger
from mcp.shared.exceptions import MCPError

if TYPE_CHECKING:
    from mcp.server.context import LifespanContextT, RequestT
    from mcp.server.mcpserver.context import Context

logger = get_logger(__name__)


class PromptManager:
    """Manages MCPServer prompts."""

    def __init__(self, warn_on_duplicate_prompts: bool = True):
        self._prompts: dict[str, Prompt] = {}
        self.warn_on_duplicate_prompts = warn_on_duplicate_prompts

    def get_prompt(self, name: str) -> Prompt | None:
        """Get prompt by name."""
        return self._prompts.get(name)

    def list_prompts(self) -> list[Prompt]:
        """List all registered prompts."""
        return list(self._prompts.values())

    def add_prompt(
        self,
        prompt: Prompt,
    ) -> Prompt:
        """Add a prompt to the manager."""

        # Check for duplicates
        existing = self._prompts.get(prompt.name)
        if existing:
            if self.warn_on_duplicate_prompts:
                logger.warning(f"Prompt already exists: {prompt.name}")
            return existing

        self._prompts[prompt.name] = prompt
        return prompt

    def remove_prompt(self, name: str) -> None:
        """Remove a prompt by name."""
        if name not in self._prompts:
            raise ValueError(f"Unknown prompt: {name}")
        del self._prompts[name]

    async def render_prompt(
        self,
        name: str,
        arguments: dict[str, Any] | None,
        context: Context[LifespanContextT, RequestT],
    ) -> list[Message] | InputRequiredResult:
        """Render a prompt by name with arguments.

        Raises:
            MCPError: If the prompt name is unknown or a required argument is missing,
                with code `INVALID_PARAMS`, or if the prompt function raises it.
            ValueError: If rendering fails.
        """
        prompt = self.get_prompt(name)
        if not prompt:
            raise MCPError(code=INVALID_PARAMS, message=f"Unknown prompt: {name}")

        return await prompt.render(arguments, context)
