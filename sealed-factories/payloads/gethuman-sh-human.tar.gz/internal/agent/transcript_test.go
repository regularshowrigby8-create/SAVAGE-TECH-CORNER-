package agent

import (
	"archive/tar"
	"bytes"
	"context"
	"io"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/gethuman-sh/human/internal/devcontainer"
)

// tarArchive builds a tar archive from name->contents entries.
func tarArchive(entries map[string]string) io.ReadCloser {
	var buf bytes.Buffer
	tw := tar.NewWriter(&buf)
	for name, contents := range entries {
		_ = tw.WriteHeader(&tar.Header{Name: name, Mode: 0o600, Size: int64(len(contents)), Typeflag: tar.TypeReg})
		_, _ = tw.Write([]byte(contents))
	}
	_ = tw.Close()
	return io.NopCloser(&buf)
}

type copyMock struct {
	mockDockerClient
	archive func() io.ReadCloser

	mu    sync.Mutex
	calls []string // ordered record of "copy"/"remove"
}

func (m *copyMock) CopyFromContainer(_ context.Context, _, _ string) (io.ReadCloser, error) {
	m.mu.Lock()
	m.calls = append(m.calls, "copy")
	m.mu.Unlock()
	return m.archive(), nil
}

func (m *copyMock) ContainerRemove(_ context.Context, _ string, _ devcontainer.ContainerRemoveOptions) error {
	m.mu.Lock()
	m.calls = append(m.calls, "remove")
	m.mu.Unlock()
	return nil
}

// stalledReadCloser models a docker tar stream that never yields data: Read
// parks until Close is called, mirroring a hung CopyFromContainer stream. Only
// a context-aware CopyTranscript (which closes the stream on ctx.Done) can
// unblock it.
type stalledReadCloser struct {
	closed chan struct{}
	once   sync.Once
}

func newStalledReadCloser() *stalledReadCloser {
	return &stalledReadCloser{closed: make(chan struct{})}
}

func (s *stalledReadCloser) Read(_ []byte) (int, error) {
	<-s.closed
	// A real docker tar stream closed mid-read surfaces a "use of closed
	// connection" error, not a clean EOF — model that so the tar reader reports
	// failure rather than treating the truncated stream as a complete archive.
	return 0, io.ErrClosedPipe
}

func (s *stalledReadCloser) Close() error {
	s.once.Do(func() { close(s.closed) })
	return nil
}

// TestCopyTranscript_UnblocksOnContextCancel is the SC-427 regression guard: a
// stalled tar stream must not park the caller forever. When the context expires
// the watchdog closes the ReadCloser so tr.Next()/io.Copy return, and
// CopyTranscript reports a (best-effort, swallowed by callers) error instead of
// blocking the single zombie-sweep goroutine indefinitely.
func TestCopyTranscript_UnblocksOnContextCancel(t *testing.T) {
	dest := t.TempDir()
	docker := &copyMock{archive: func() io.ReadCloser { return newStalledReadCloser() }}

	ctx, cancel := context.WithTimeout(context.Background(), 100*time.Millisecond)
	defer cancel()

	done := make(chan error, 1)
	go func() { done <- CopyTranscript(ctx, docker, "cid", "vscode", "", dest) }()

	select {
	case err := <-done:
		if err == nil {
			t.Fatal("expected a non-nil error when the stream is closed on context cancel")
		}
	case <-time.After(2 * time.Second):
		t.Fatal("CopyTranscript did not unblock on context cancel within 2s")
	}
}

func TestClaudeProjectDirName(t *testing.T) {
	cases := []struct{ cwd, want string }{
		{"/workspaces/cli", "-workspaces-cli"},
		{"/home/vscode/.human/wt/run_1", "-home-vscode--human-wt-run-1"},
	}
	for _, c := range cases {
		if got := claudeProjectDirName(c.cwd); got != c.want {
			t.Fatalf("claudeProjectDirName(%q) = %q, want %q", c.cwd, got, c.want)
		}
	}
}

// TestCopyTranscript_Fallback_EmptyWorktree pins that an empty worktree takes the
// whole-root path unchanged: the copy still extracts.
func TestCopyTranscript_Fallback_EmptyWorktree(t *testing.T) {
	dest := t.TempDir()
	docker := &copyMock{archive: func() io.ReadCloser {
		return tarArchive(map[string]string{"projects/p/s.jsonl": "ROOT-DATA"})
	}}
	if err := CopyTranscript(context.Background(), docker, "cid", "vscode", "", dest); err != nil {
		t.Fatalf("CopyTranscript: %v", err)
	}
	if got := readTree(t, dest); !strings.Contains(got, "ROOT-DATA") {
		t.Fatalf("expected root copy to land, got %q", got)
	}
}

// TestCopyTranscript_Fallback_ScopedMissing is the SC-2463 fallback guard: when a
// run's worktree sanitises to a subdir the container does not hold, the scoped
// copy errors and we fall back to the whole projects root — preserve more, not
// less.
func TestCopyTranscript_Fallback_ScopedMissing(t *testing.T) {
	dest := t.TempDir()
	docker := &scopedProjectsMock{tree: map[string]string{
		"/home/vscode/.claude/projects/-w-run-b/b.jsonl": "RUN-B-DATA",
	}}
	// worktree "/w/run-a" -> subdir "-w-run-a", which is absent from the tree.
	if err := CopyTranscript(context.Background(), docker, "cid", "vscode", "/w/run-a", dest); err != nil {
		t.Fatalf("CopyTranscript: %v", err)
	}
	if got := readTree(t, dest); !strings.Contains(got, "RUN-B-DATA") {
		t.Fatalf("expected fallback to root to preserve available sessions, got %q", got)
	}
}

func TestContainerTranscriptPath(t *testing.T) {
	if got := containerTranscriptPath("vscode"); got != "/home/vscode/.claude/projects" {
		t.Fatalf("got %q", got)
	}
	if got := containerTranscriptPath(""); got != "/root/.claude/projects" {
		t.Fatalf("empty user got %q", got)
	}
	if got := containerTranscriptPath("root"); got != "/root/.claude/projects" {
		t.Fatalf("root got %q", got)
	}
}

func TestCopyTranscript_ExtractsTar(t *testing.T) {
	dest := t.TempDir()
	docker := &copyMock{archive: func() io.ReadCloser {
		return tarArchive(map[string]string{"projects/p/s.jsonl": "SESSION-DATA"})
	}}
	if err := CopyTranscript(context.Background(), docker, "cid", "vscode", "", dest); err != nil {
		t.Fatalf("CopyTranscript: %v", err)
	}
	data, err := os.ReadFile(filepath.Join(dest, "projects", "p", "s.jsonl"))
	if err != nil {
		t.Fatalf("read extracted: %v", err)
	}
	if string(data) != "SESSION-DATA" {
		t.Fatalf("contents = %q", string(data))
	}
}

func TestCopyTranscript_RejectsTraversal(t *testing.T) {
	dest := t.TempDir()
	docker := &copyMock{archive: func() io.ReadCloser {
		return tarArchive(map[string]string{"../escape.txt": "EVIL"})
	}}
	if err := CopyTranscript(context.Background(), docker, "cid", "vscode", "", dest); err != nil {
		t.Fatalf("CopyTranscript should skip traversal, not error: %v", err)
	}
	// The escaping entry must not be written outside dest.
	if _, err := os.Stat(filepath.Join(filepath.Dir(dest), "escape.txt")); err == nil {
		t.Fatal("traversal entry escaped destDir")
	}
}

// SC-627: absolute entry names are non-local and skipped outright (they were
// previously re-rooted under destDir; docker tars are always relative, so
// nothing real is lost — this pins the deliberate behavioral delta).
func TestCopyTranscript_SkipsAbsoluteEntry(t *testing.T) {
	dest := t.TempDir()
	docker := &copyMock{archive: func() io.ReadCloser {
		return tarArchive(map[string]string{"/abs.txt": "DATA"})
	}}
	if err := CopyTranscript(context.Background(), docker, "cid", "vscode", "", dest); err != nil {
		t.Fatalf("CopyTranscript should skip absolute entries, not error: %v", err)
	}
	if _, err := os.Stat(filepath.Join(dest, "abs.txt")); err == nil {
		t.Fatal("absolute entry must not be extracted")
	}
}

func TestCopyTranscript_TopLevelFile(t *testing.T) {
	dest := t.TempDir()
	docker := &copyMock{archive: func() io.ReadCloser {
		return tarArchive(map[string]string{"file.jsonl": "TOP"})
	}}
	if err := CopyTranscript(context.Background(), docker, "cid", "vscode", "", dest); err != nil {
		t.Fatalf("CopyTranscript: %v", err)
	}
	data, err := os.ReadFile(filepath.Join(dest, "file.jsonl"))
	if err != nil {
		t.Fatalf("read extracted: %v", err)
	}
	if string(data) != "TOP" {
		t.Fatalf("contents = %q", string(data))
	}
}

func TestStopLocked_CopiesTranscriptBeforeRemove(t *testing.T) {
	tmp := withLogRoot(t)
	t.Setenv("HOME", tmp)

	exe, err := NewExecution(LaunchRecord{ID: "e1", Agent: "s1", StartedAt: time.Now()})
	if err != nil {
		t.Fatal(err)
	}
	meta := Meta{
		Name: "s1", ContainerID: "cid", RemoteUser: "vscode",
		Status: StatusRunning, CreatedAt: time.Now(), ExecutionID: exe.Launch.ID,
	}
	if err := WriteMeta(meta); err != nil {
		t.Fatal(err)
	}
	docker := &copyMock{archive: func() io.ReadCloser {
		return tarArchive(map[string]string{"projects/p/s.jsonl": "X"})
	}}
	mgr := &Manager{Docker: docker}
	if err := mgr.Stop(context.Background(), "s1"); err != nil {
		t.Fatal(err)
	}
	if len(docker.calls) < 2 || docker.calls[0] != "copy" || docker.calls[1] != "remove" {
		t.Fatalf("copy must precede remove, got %v", docker.calls)
	}
	var oc OutcomeRecord
	if err := readJSONFile(filepath.Join(exe.Dir(), "outcome.json"), &oc); err != nil {
		t.Fatalf("outcome not written: %v", err)
	}
	if oc.Reason != "completed" {
		t.Fatalf("reason = %q, want completed", oc.Reason)
	}
}

func TestPreserveExecutionArtifacts_CopiesTranscriptAndOutcome(t *testing.T) {
	withLogRoot(t)

	exe, err := NewExecution(LaunchRecord{ID: "e9", Agent: "d1", StartedAt: time.Now()})
	if err != nil {
		t.Fatal(err)
	}
	meta := Meta{
		Name: "d1", ContainerID: "cid", RemoteUser: "vscode",
		CreatedAt: time.Now(), ExecutionID: exe.Launch.ID, Status: StatusFailed,
	}
	docker := &copyMock{archive: func() io.ReadCloser {
		return tarArchive(map[string]string{"projects/p/s.jsonl": "DECOM-DATA"})
	}}
	PreserveExecutionArtifacts(context.Background(), docker, meta)

	data, err := os.ReadFile(filepath.Join(exe.TranscriptDir(), "projects", "p", "s.jsonl"))
	if err != nil {
		t.Fatalf("transcript not copied: %v", err)
	}
	if string(data) != "DECOM-DATA" {
		t.Fatalf("contents = %q", string(data))
	}
	var oc OutcomeRecord
	if err := readJSONFile(filepath.Join(exe.Dir(), "outcome.json"), &oc); err != nil {
		t.Fatalf("outcome not written: %v", err)
	}
	if oc.Reason != "reaped" {
		t.Fatalf("reason = %q, want reaped", oc.Reason)
	}
}

func TestPreserveExecutionArtifacts_NoExecutionIsNoop(t *testing.T) {
	withLogRoot(t)

	docker := &copyMock{archive: func() io.ReadCloser { return tarArchive(nil) }}
	// No execution dir exists for this agent; preservation must be a silent no-op.
	PreserveExecutionArtifacts(context.Background(), docker, Meta{Name: "ghost", ContainerID: "cid", Status: StatusFailed})
	if len(docker.calls) != 0 {
		t.Fatalf("expected no docker calls, got %v", docker.calls)
	}
}

func TestStopLocked_ReapedReason(t *testing.T) {
	tmp := withLogRoot(t)
	t.Setenv("HOME", tmp)

	exe, err := NewExecution(LaunchRecord{ID: "e2", Agent: "s2", StartedAt: time.Now()})
	if err != nil {
		t.Fatal(err)
	}
	// A reaped agent is marked StatusFailed before teardown.
	meta := Meta{
		Name: "s2", ContainerID: "cid", RemoteUser: "vscode",
		Status: StatusFailed, CreatedAt: time.Now(), ExecutionID: exe.Launch.ID,
	}
	if err := WriteMeta(meta); err != nil {
		t.Fatal(err)
	}
	docker := &copyMock{archive: func() io.ReadCloser { return tarArchive(nil) }}
	mgr := &Manager{Docker: docker}
	if err := mgr.Stop(context.Background(), "s2"); err != nil {
		t.Fatal(err)
	}
	var oc OutcomeRecord
	if err := readJSONFile(filepath.Join(exe.Dir(), "outcome.json"), &oc); err != nil {
		t.Fatalf("outcome not written: %v", err)
	}
	if oc.Reason != "reaped" {
		t.Fatalf("reason = %q, want reaped", oc.Reason)
	}
}
