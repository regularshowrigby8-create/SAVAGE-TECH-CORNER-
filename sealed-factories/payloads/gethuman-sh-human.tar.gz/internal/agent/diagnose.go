package agent

// Post-mortem failure diagnosis for board agent runs. When a stage agent dies,
// the daemon's failure watcher used to post a bare "agent exited without
// completing the stage" — every real cause then had to be dug out of the run's
// artifacts by hand. All the material is already persisted per run by the
// execution log store (output.log, outcome.json, launch.json); this file reads
// it back and distills a headline + detail block for the failed marker.

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"slices"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"

	"github.com/gethuman-sh/human/internal/redact"
)

// FailureDiagnosis is the distilled cause of a dead agent run. Headline is a
// single plain-text line (the board card's badge/tooltip text and the first
// body line of the failed marker); Detail is a markdown block for the ticket's
// detail pane.
type FailureDiagnosis struct {
	Headline string
	Detail   string
}

const (
	// diagnoseTailLines lines of output are quoted in the detail block; the
	// wider diagnoseScanLines window is searched for error lines and the exit
	// trailer.
	diagnoseTailLines   = 15
	diagnoseScanLines   = 200
	diagnoseMaxHeadline = 200
	diagnoseMaxDetail   = 2000
	diagnoseMaxLineLen  = 300
)

// The wait exists because artifact availability depends on how the run died:
// on the live hook path the tee's exit trailer may still be in flight when the
// Stop event arrives, while a reaped run already has outcome.json. Package
// vars so tests can zero the wait.
var (
	diagnoseWaitStep  = 2 * time.Second
	diagnoseWaitTries = 3
)

// genericFailureHeadline is the pre-diagnosis wording, kept as the terminal
// fallback so a run with no readable artifacts reports exactly what it always
// did.
const genericFailureHeadline = "agent exited without completing the stage"

// DiagnoseFailure inspects the agent's latest execution artifacts (outcome.json,
// output.log tail) plus the hook event's error type and distills why the run
// died. It never fails: missing or unreadable artifacts degrade stepwise down
// to the generic headline. hookErrorType is the hook event's ErrorType ("" when
// the event carried none).
func DiagnoseFailure(agentName, hookErrorType string) FailureDiagnosis {
	exe, err := LatestExecution(agentName)
	if err != nil {
		return FailureDiagnosis{Headline: headlineFor(hookErrorType, false, 0, false, "")}
	}
	outcome := waitForRunEnd(exe.Dir())
	scan := readOutputTail(exe.Dir(), diagnoseScanLines)
	exitCode, haveExit := parseExitTrailer(scan)
	errLine := redact.Text(lastErrorLine(scan))

	// A reap is now recorded as a container DISPOSITION, so an exit-1 run that
	// was later reaped reports reason "failed" and still reads as reaped here
	// (SC-4820). The Reason fallback keeps a record written before that change
	// diagnosable.
	reaped := outcome != nil && (outcome.Disposition == DispositionReaped || outcome.Reason == "reaped")
	headline := truncateRunes(headlineFor(hookErrorType, reaped, exitCode, haveExit, errLine), diagnoseMaxHeadline)
	detail := truncateRunes(detailFor(exe, outcome, exitCode, haveExit, scan), diagnoseMaxDetail)
	return FailureDiagnosis{Headline: headline, Detail: detail}
}

// waitForRunEnd waits briefly until the run's end-of-life evidence exists —
// outcome.json (reap path) or the tee's exit trailer (live path) — then
// returns whatever outcome is readable. nil is a valid answer: the trailer
// alone carries the exit code.
func waitForRunEnd(dir string) *OutcomeRecord {
	for try := 0; ; try++ {
		var oc OutcomeRecord
		if err := readJSONFile(filepath.Join(dir, "outcome.json"), &oc); err == nil {
			return &oc
		}
		if _, ok := parseExitTrailer(readOutputTail(dir, 5)); ok {
			return nil
		}
		if try >= diagnoseWaitTries-1 {
			return nil
		}
		time.Sleep(diagnoseWaitStep)
	}
}

// readOutputTail returns the last n non-trailing-blank lines of the run's
// output.log, or no lines when the log is missing/unreadable.
func readOutputTail(dir string, n int) []string {
	data, err := os.ReadFile(filepath.Join(dir, "output.log")) // #nosec G304 -- path derived from validated agent name + hex id
	if err != nil {
		return []string{}
	}
	lines := strings.Split(strings.ReplaceAll(string(data), "\r\n", "\n"), "\n")
	for len(lines) > 0 && strings.TrimSpace(lines[len(lines)-1]) == "" {
		lines = lines[:len(lines)-1]
	}
	if len(lines) > n {
		lines = lines[len(lines)-n:]
	}
	return lines
}

// ansiRe strips terminal escape sequences before pattern matching — claude's
// output is colored, and a colored "Error:" must still match.
var ansiRe = regexp.MustCompile(`\x1b\[[0-9;]*[a-zA-Z]`)

func stripANSI(s string) string { return ansiRe.ReplaceAllString(s, "") }

// parseExitTrailer finds the tee's exit trailer in the scanned lines, newest
// first, and returns the recorded exit code.
func parseExitTrailer(lines []string) (int, bool) {
	for _, line := range slices.Backward(lines) {
		line := strings.TrimSpace(stripANSI(line))
		if !strings.HasPrefix(line, execExitTrailerPrefix) {
			continue
		}
		code, err := strconv.Atoi(strings.TrimSpace(strings.TrimPrefix(line, execExitTrailerPrefix)))
		if err != nil {
			continue
		}
		return code, true
	}
	return 0, false
}

// errorLineRes are the shapes a "real" error line takes in claude/tool output.
// Heuristic by design: a false positive still shows a line from the actual run,
// which beats the generic message.
var errorLineRes = []*regexp.Regexp{
	regexp.MustCompile(`(?i)^(error|fatal|panic)[:\s]`),
	regexp.MustCompile(`(?i)api.?error|overloaded_error|rate.?limit`),
	regexp.MustCompile(`(?i)invalid_request_error|authentication_error|authentication_failed|permission_error|billing`),
	regexp.MustCompile(`(?i)context deadline exceeded|connection refused|no space left on device|out of memory|\bkilled\b`),
}

// lastErrorLine returns the last line of the scan window that looks like an
// error, skipping the exit trailer itself.
func lastErrorLine(lines []string) string {
	for _, line := range slices.Backward(lines) {
		line := strings.TrimSpace(stripANSI(line))
		if line == "" || strings.HasPrefix(line, execExitTrailerPrefix) {
			continue
		}
		for _, re := range errorLineRes {
			if re.MatchString(line) {
				return line
			}
		}
	}
	return ""
}

// headlineFor implements the interpretation table, most-specific signal first:
// the hook's own error type beats artifact inference, a reap beats only a
// nonzero (killed) exit code — the reaped process's code is the killer's, not
// the cause — but a recorded clean exit (code 0) is direct evidence of a
// normal self-termination and overrides the reap, known exit codes beat the
// error-line heuristic.
//
// Every branch returns a STATUS, never a stack trace (SC-3024): no exit codes,
// signal names, container/OOM/reaping/segfault vocabulary, and never a raw log
// line as the headline. That evidence still reaches the reader — detailFor
// carries the exit code and the log tail in the Detail block below — it is
// just never mistaken for the one-line badge/tooltip text a card shows.
func headlineFor(hookErrorType string, reaped bool, exitCode int, haveExit bool, errLine string) string {
	if h := hookHeadline(hookErrorType); h != "" {
		return h
	}
	cleanExit := haveExit && exitCode == 0
	if reaped && !cleanExit {
		return "the run stopped before finishing this stage — check the evidence below, then Retry"
	}
	if haveExit {
		return exitHeadline(exitCode, errLine)
	}
	// A raw/panic log line is never the headline — it stays in the Detail
	// evidence (fenceSafeTail) instead of standing in for a diagnosis.
	return genericFailureHeadline
}

// hookHeadline maps the hook event's error type to a status, not a stack
// trace; "" means no hook signal. rate_limit/overloaded are unavailability —
// they are classified upstream by the daemon's classifyUnavailability (which
// routes them to the paused/outage register before this is ever reached for
// the ordinary failure path), so this only names that the daemon is on it;
// this branch is reached when that classification did not already handle the
// exit (e.g. resumeTimeFromDiagnosis's scan, or a nil latestClass with no
// hook-level routing upstream). Any other errorType gets the same neutral
// status the exit-based branches use.
func hookHeadline(errorType string) string {
	t := strings.ToLower(strings.TrimSpace(errorType))
	switch t {
	case "":
		return ""
	case "rate_limit", "rate-limit", "overloaded", "overloaded_error":
		return "the run stopped at the model API — the daemon is handling it"
	default:
		return "the run stopped at the model boundary; check the evidence below, then Retry"
	}
}

// exitHeadline maps an exit code to a status, never the code itself: the
// per-code branches (124/137/139/other) that used to name timeouts, OOM kills
// and segfaults are collapsed into one neutral "stopped before finishing"
// status — the exit code is guessed-at cause vocabulary the reader cannot act
// on directly, and it still reaches the Detail block via detailFor. A clean
// exit-0 is the one case worth splitting: with no error line it is a bare
// missing handoff; with one, the run logged something before finishing
// without handing off.
func exitHeadline(code int, errLine string) string {
	if code == 0 {
		if errLine != "" {
			return "the run finished without handing off the stage — check the evidence below, then re-run this stage."
		}
		return "agent finished without posting the stage handoff"
	}
	return "the run stopped before finishing this stage — check the evidence below, then Retry"
}

// detailFor composes the markdown detail block: run identity, duration, exit
// code, then the sanitized last lines of output inside a ~~~ fence (tildes, not
// backticks, so log lines containing ``` cannot break out of the fence).
func detailFor(exe *Execution, outcome *OutcomeRecord, exitCode int, haveExit bool, scan []string) string {
	var b strings.Builder
	fmt.Fprintf(&b, "agent: %s\n", exe.Launch.Agent)
	if d := runDuration(exe, outcome); d != "" {
		fmt.Fprintf(&b, "duration: %s\n", d)
	}
	if haveExit {
		fmt.Fprintf(&b, "exit code: %d\n", exitCode)
	}
	tail := fenceSafeTail(scan)
	if len(tail) > 0 {
		b.WriteString("\nlast output:\n~~~\n")
		for _, l := range tail {
			b.WriteString(l)
			b.WriteByte('\n')
		}
		b.WriteString("~~~")
	}
	return strings.TrimSpace(b.String())
}

// fenceSafeTail sanitizes and caps the quoted tail: last diagnoseTailLines
// lines, each length-capped, secret-scrubbed, and never itself a ~ fence line.
func fenceSafeTail(scan []string) []string {
	// Drop the shutdown suffix (exit trailer + trailing blank/ANSI-only lines)
	// before choosing the window, so it cannot evict the agent's real last words.
	scan = scan[:len(scan)-trailingNoiseLen(scan)]
	if len(scan) > diagnoseTailLines {
		scan = scan[len(scan)-diagnoseTailLines:]
	}
	out := make([]string, 0, len(scan))
	for _, l := range scan {
		l = strings.TrimRight(stripANSI(l), " \t")
		if t := strings.TrimSpace(l); t != "" && strings.Trim(t, "~") == "" {
			continue
		}
		out = append(out, truncateRunes(redact.Text(l), diagnoseMaxLineLen))
	}
	return out
}

// trailingNoiseLen counts the suffix of lines that carry no agent message —
// the tee's exit trailer and blank/ANSI-only shutdown lines — walking backward
// and stopping at the first line with real content. The trailer stays in the
// wider scan for exit-code and error-line parsing; only the quoted tail drops it.
func trailingNoiseLen(scan []string) int {
	n := 0
	for _, l := range slices.Backward(scan) {
		t := strings.TrimSpace(stripANSI(l))
		if t != "" && !strings.HasPrefix(t, execExitTrailerPrefix) {
			break
		}
		n++
	}
	return n
}

// runDuration prefers the recorded outcome duration; a run without an outcome
// yet is measured from its launch. Second precision — this is for humans.
func runDuration(exe *Execution, outcome *OutcomeRecord) string {
	if outcome != nil && outcome.DurationMs > 0 {
		return (time.Duration(outcome.DurationMs) * time.Millisecond).Truncate(time.Second).String()
	}
	if !exe.Launch.StartedAt.IsZero() {
		return time.Since(exe.Launch.StartedAt).Truncate(time.Second).String()
	}
	return ""
}

// truncateRunes caps s at max runes, marking the cut with an ellipsis.
func truncateRunes(s string, max int) string {
	if utf8.RuneCountInString(s) <= max {
		return s
	}
	r := []rune(s)
	return string(r[:max-1]) + "…"
}
