# ══════════════════════════════════════════════════════════════════════
# SDD FULL PIPELINE — Copy this ENTIRE file and paste as your prompt
# in the workspace that contains the TypeScript project.
# ══════════════════════════════════════════════════════════════════════

I need you to orchestrate a full Spec-Driven Development pipeline across three agents: **spec-writer → implementer → reviewer**. This is a fully automated chain — each agent does its job and hands off to the next. No human intervention between stages.

You are the **orchestrator**. Here is how the pipeline works, and what each agent must do.

---

## PHASE 1 — SPEC WRITER

Use the **spec-writer agent** to produce a comprehensive specification from the plan below. The spec-writer MUST:

1. Read the entire plan and codebase context below
2. Explore the current codebase to understand existing types, files, and test structure
3. Ask NO clarifying questions — all context is provided, make informed defaults
4. Produce a spec with:
   - **At least 9 user stories** (one per refactoring step, prioritized P1/P2/P3)
   - **At least 25 functional requirements** (FR-001 through FR-025+)
   - **At least 8 non-functional requirements**
   - **At least 10 success criteria** (measurable, specific)
   - **At least 15 edge cases**
   - **At least 5 acceptance scenarios (Given/When/Then) per story** (45+ total)
   - A **dependency graph** showing which steps block which
   - **Guard rails** as hard constraints, not suggestions
5. Save the spec to `.specify/specs/full-stack-type-safety/spec.md` (create dirs)
6. Self-validate against the acceptance checklist
7. Immediately hand off to the implementer agent (see handoff instructions below)

### THE PLAN

**Full-Stack Type Safety Refactor — 9 Steps**

**Core problem**: Two parallel `SearchResult` types (DB vs API), untyped request parsing, ~10 `any` casts, and only 1 of 8 files imports from generated types.

**Strategy**: OpenAPI spec → generates compile-time types (`api.d.ts`) + hand-written Zod schemas → runtime validation. Database types extend API types instead of duplicating them.

| Step | What | Impact |
|------|------|--------|
| 1 | Fix OpenAPI spec (add missing fields, mark required) | Spec matches reality |
| 2 | Create `schemas.ts` with Zod schemas matching spec | Runtime + compile-time types from one place |
| 3 | Unify database types (`DbSearchResult extends ApiSearchResult`) | Kill the duplicate type |
| 4 | Zod-validate all `c.req.json()` in server endpoints | No more untyped requests |
| 5 | Eliminate all `as any` / `: any` (~10 instances) | Zero unsafe casts |
| 6 | Type search pipeline end-to-end | Pipeline returns typed results |
| 7 | Verify summarizer types match Zod schemas | Already mostly correct |
| 8 | Add `tsc --noEmit` typecheck script | CI-ready type checking |
| 9 | Conformance tests (Zod parses real API responses) | Types verified at runtime |

**Guard rails**: All 227 Vitest tests + 7 Playwright tests must stay green throughout.

### DETAILED CODEBASE CONTEXT

**Architecture**:
- Backend: Hono.js server with 8 endpoint files handling search, summarization, and document management
- Frontend: React + Vite with search UI, result cards, and a summarizer panel
- Database: SQLite via Drizzle ORM storing documents, embeddings, and search results
- API: OpenAPI 3.1 spec (partially correct) describing all endpoints
- Type generation: `openapi-typescript` generates `api.d.ts` from the OpenAPI spec
- Tests: 227 unit/integration tests (Vitest) + 7 end-to-end tests (Playwright)

**Problem Details**:

1. **Duplicate types**: `SearchResult` is defined TWICE — once in `src/types/api.ts` (API layer) and once in `src/types/db.ts` (database layer). They have overlapping but different fields. Some components import one, some the other, some use `any`.

2. **Untyped request parsing**: Every endpoint does `const body = await c.req.json()` returning `any`. No runtime validation. Malformed requests silently produce garbage.

3. **Unsafe casts (~10 total)**:
   - `src/server/routes/search.ts` (3 casts)
   - `src/server/routes/summarize.ts` (2 casts)
   - `src/server/middleware/validation.ts` (2 casts)
   - `src/pipeline/search-pipeline.ts` (2 casts)
   - `src/utils/transform.ts` (1 cast)

4. **Generated types ignored**: `api.d.ts` is generated but only 1 of 8 files imports from it.

5. **OpenAPI spec drift**: Missing 3 fields (`score`, `highlights`, `metadata.source`), 2 fields incorrectly marked required (`summary`, `relatedDocuments` should be optional).

6. **Search pipeline untyped**: 5-stage pipeline (`query → embed → search → rank → transform`) passes `any` through every stage.

7. **Summarizer mismatch**: Expects `SummaryRequest` but receives a plain object — works by duck-typing accident.

**Step-by-Step Details**:

**Step 1 — Fix OpenAPI spec**: Add `score: number`, `highlights: string[]`, `metadata.source: string`. Fix `summary` → optional, `relatedDocuments` → optional. Regenerate `api.d.ts`.

**Step 2 — Create Zod schemas**: `src/schemas.ts` with Zod schemas mirroring corrected OpenAPI spec. Export schemas AND inferred types (`z.infer<typeof SearchResultSchema>`). Single source of truth.

**Step 3 — Unify database types**: `DbSearchResult extends ApiSearchResult` with DB-only fields (`rowid`, `createdAt`, `embedding`). Delete duplicate `SearchResult` in `db.ts`. Update all imports.

**Step 4 — Zod-validate all endpoints**: Replace `await c.req.json()` with `schema.parse(await c.req.json())`. Return 400 with Zod error messages. Cover:
  - `POST /api/search` → `SearchRequestSchema`
  - `POST /api/summarize` → `SummarizeRequestSchema`
  - `POST /api/documents` → `CreateDocumentSchema`
  - `PUT /api/documents/:id` → `UpdateDocumentSchema`
  - `POST /api/embeddings/generate` → `GenerateEmbeddingsSchema`

**Step 5 — Kill all `any`**: Replace each `as any` / `: any` with proper types. Type pipeline stages. Type middleware context extensions.

**Step 6 — Type search pipeline**: Create typed stage interfaces:
  - `QueryInput → EmbeddingResult → SearchHits → RankedResults → TransformedResults`
  - Each: `(input: StageInput) => Promise<StageOutput>`
  - Pipeline composer enforcing type flow between stages

**Step 7 — Fix summarizer types**: Match `SummaryRequest` to what's actually sent. Verify response type. Wire Zod validation.

**Step 8 — Typecheck script**: Add `"typecheck": "tsc --noEmit"` to `package.json`. Fix errors. Ensure it runs in CI.

**Step 9 — Conformance tests**: Parse real API responses through Zod schemas:
  - Search response parsing
  - Summarize response parsing
  - Document CRUD response parsing
  - Error response parsing
  - Edge cases: empty results, max-length fields, unicode, null optionals

### COMPLEXITY AMPLIFIERS (must be in the spec)

- **Plugin system**: The search pipeline has injectable custom ranking functions, currently `(results: any) => any`. Must type the plugin interface with generics.
- **WebSocket endpoint**: `/ws/search-stream` streams partial search results. Needs typed message schemas (discriminated union: `SearchStart | SearchProgress | SearchResult | SearchComplete | SearchError`).
- **TanStack Query integration**: Frontend uses `useQuery<T>` — generic type param should propagate from Zod-inferred types. E.g., `useQuery<z.infer<typeof SearchResponseSchema>>`.
- **Error response union**: 3 error shapes depending on type — validation (`{ type: "validation", errors: ZodError[] }`), not-found (`{ type: "not_found", resource: string, id: string }`), internal (`{ type: "internal", message: string, requestId: string }`). Must be a discriminated union.
- **Drizzle migration alignment**: Database schema types must align with the unified type hierarchy. Drizzle's `$inferSelect` must be compatible with `DbSearchResult`.

### NON-FUNCTIONAL REQUIREMENTS (must be in the spec)

- **Type coverage**: 100% of exported functions have explicit return types (no inferred `any`)
- **Zero `any`**: `tsc --noEmit` with `strict: true` and `noExplicitAny: true` must pass
- **Schema performance**: Zod parsing adds < 1ms overhead per request (benchmark it)
- **Bundle size**: Zod schemas increase frontend bundle by < 5KB gzipped
- **Developer experience**: IDE autocomplete works end-to-end (query → API → response)
- **Test stability**: All 227 Vitest + 7 Playwright tests green after EVERY step, not just at the end
- **Incremental commits**: Each step is a separate commit for bisect capability
- **Backward compatible**: External API consumers see zero changes

### CONSTRAINTS

- No new dependencies except Zod (already in package.json)
- `api.d.ts` is generated — NEVER hand-edit it
- Zero runtime behavior changes — type-safety refactor only
- Existing test patterns must be preserved (don't rewrite working tests)

---

## PHASE 2 — IMPLEMENTER

After the spec is written, use the **implementer agent** to implement it. The implementer MUST:

1. Read the spec at `.specify/specs/full-stack-type-safety/spec.md`
2. Explore the codebase to map spec requirements to actual files
3. Create `tasks.md` with all tasks labeled `[US1]`-`[US9]` per user story
4. **Follow the 9-step order exactly** — each step is an implementation phase
5. For EACH step:
   - Write tests FIRST (from acceptance scenarios Given/When/Then)
   - Implement the changes
   - Run `npm test` to verify all 227 tests pass
   - Run `npx tsc --noEmit` after steps 5+ to verify type checking
   - Run `npx playwright test` after steps 4, 5, 6, and 9
   - Mark tasks `[X]` in tasks.md as they complete
   - Commit with message: `refactor(types): step N — [description]`
6. **Log ALL deviations** — never silently diverge from the spec
7. Generate a completion report at `.specify/specs/full-stack-type-safety/completion-report.md`
8. Immediately hand off to the reviewer agent

### IMPLEMENTER VERIFICATION MATRIX

After each step, run and report results for:

| Step | `npm test` | `tsc --noEmit` | `playwright test` | `npm run build` |
|------|-----------|----------------|-------------------|-----------------|
| 1 | ✅ required | ❌ skip | ❌ skip | ✅ required |
| 2 | ✅ required | ❌ skip | ❌ skip | ✅ required |
| 3 | ✅ required | ❌ skip | ❌ skip | ✅ required |
| 4 | ✅ required | ❌ skip | ✅ required | ✅ required |
| 5 | ✅ required | ✅ required | ✅ required | ✅ required |
| 6 | ✅ required | ✅ required | ✅ required | ✅ required |
| 7 | ✅ required | ✅ required | ❌ skip | ✅ required |
| 8 | ✅ required | ✅ required | ❌ skip | ✅ required |
| 9 | ✅ required | ✅ required | ✅ required | ✅ required |

If ANY required check fails, STOP. Do not proceed to the next step. Fix the issue first. Log it as a deviation if the spec caused it.

---

## PHASE 3 — REVIEWER

After implementation is complete, use the **reviewer agent** to audit compliance. The reviewer MUST:

1. Read the spec at `.specify/specs/full-stack-type-safety/spec.md`
2. Read the completion report at `.specify/specs/full-stack-type-safety/completion-report.md`
3. Read `tasks.md` for completion status
4. Scan ALL source files that were created or modified
5. Perform a systematic audit:
   - **User Story Coverage**: Check each of the 9 stories, every acceptance scenario
   - **Functional Requirements**: Trace every FR-XXX to code (file:line) and test
   - **Non-Functional Requirements**: Verify each NFR with evidence
   - **Success Criteria**: Assess each SC-XXX with evidence
   - **Edge Cases**: Verify each edge case has a handler
   - **Deviation Analysis**: Review all logged deviations for justification
6. Run verification commands:
   - `npm test` — all 227+ tests pass?
   - `npx tsc --noEmit` — zero type errors?
   - `npx playwright test` — all 7 E2E pass?
   - `grep -r "as any\|: any" src/` — zero `any` remaining?
   - `du -sh dist/` or equivalent — bundle size check
7. Generate the full HTML compliance report as `review-report.html` in the project root
8. Use the HTML report template from the reviewer skill (collapsible sections, color-coded status, print-friendly)
9. The report MUST include:
   - Executive summary with compliance percentage
   - User story coverage matrix (9 stories × pass/partial/fail/missing)
   - Requirements traceability matrix (25+ FRs → code location → test location)
   - Success criteria dashboard (10+ criteria with evidence)
   - Edge case coverage table (15+ cases)
   - Findings categorized by severity (Critical/Major/Minor/Info)
   - Deviation log with justification analysis
   - Code quality assessment
   - Final verdict: APPROVED / APPROVED WITH CONDITIONS / NEEDS REVISION / REJECTED
10. Present a summary with: compliance %, verdict, critical findings count, top 3 issues

---

## ORCHESTRATION RULES

1. **Do NOT ask for confirmation between phases** — each agent hands off automatically
2. **Do NOT skip any phase** — all three must run
3. **Do NOT simplify the spec** — it must be comprehensive (45+ acceptance scenarios)
4. **Do NOT skip verification steps** — every `npm test` and `tsc --noEmit` must actually run
5. **If any agent fails**, document why and continue to the next phase anyway — the reviewer will catch gaps
6. **Time budget**: spec-writer gets as long as it needs, implementer works step-by-step, reviewer is thorough
7. **Evidence-based**: every claim in the review report must reference a file path or command output

Begin now. Start with the spec-writer agent. Explore the codebase first, then produce the specification.
