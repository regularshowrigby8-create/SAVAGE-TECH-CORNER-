# SDD Stress Test — Full-Stack Type Safety Refactor
# ══════════════════════════════════════════════════
# Copy everything below and paste it as your prompt to the spec-writer agent.
# The agents will hand off to each other automatically.
# ══════════════════════════════════════════════════

Use the spec-writer agent for this task.

## Plan to Specify

I need a comprehensive specification for a **Full-Stack Type Safety Refactor** across an existing TypeScript monorepo (Hono backend + React frontend). This is a brownfield refactoring project — the codebase already works (227 Vitest tests + 7 Playwright E2E tests all pass), but has severe type-safety gaps that need surgical fixing without breaking anything.

### Context: What Exists Today

The project is a **semantic search application** with:
- **Backend**: Hono.js server with 8 endpoint files handling search, summarization, and document management
- **Frontend**: React + Vite with search UI, result cards, and a summarizer panel
- **Database**: SQLite via Drizzle ORM storing documents, embeddings, and search results
- **API**: OpenAPI 3.1 spec (partially correct) describing all endpoints
- **Tests**: 227 unit/integration tests (Vitest) + 7 end-to-end tests (Playwright)
- **Type generation**: `openapi-typescript` generates `api.d.ts` from the OpenAPI spec, but only 1 of 8 files actually imports from it

### The Problem (be very specific in the spec about each of these)

1. **Duplicate types**: `SearchResult` is defined TWICE — once in `src/types/api.ts` (API layer) and once in `src/types/db.ts` (database layer). They have overlapping but different fields. Some components import one, some import the other, some use `any`.

2. **Untyped request parsing**: Every endpoint does `const body = await c.req.json()` which returns `any`. No runtime validation. A malformed request silently produces garbage results instead of a 400 error.

3. **Unsafe casts**: There are approximately 10 instances of `as any` or `: any` scattered across:
   - `src/server/routes/search.ts` (3 casts)
   - `src/server/routes/summarize.ts` (2 casts)
   - `src/server/middleware/validation.ts` (2 casts)
   - `src/pipeline/search-pipeline.ts` (2 casts)
   - `src/utils/transform.ts` (1 cast)

4. **Generated types ignored**: `api.d.ts` is generated from the OpenAPI spec but almost nobody imports it. Hand-written types duplicate and diverge from the spec.

5. **OpenAPI spec drift**: The spec is missing 3 fields that the API actually returns (`score`, `highlights`, `metadata.source`) and incorrectly marks 2 optional fields as required (`summary`, `relatedDocuments`).

6. **Search pipeline untyped**: The search pipeline (`query → embed → search → rank → transform`) passes data through 5 stages with no intermediate type annotations. Each stage uses `any` for input/output.

7. **Summarizer type mismatch**: The summarizer expects `SummaryRequest` but receives a plain object that doesn't match — it works by accident because JS is duck-typed, but TypeScript can't verify it.

### The 9-Step Refactoring Strategy (turn each into user stories)

**Step 1 — Fix OpenAPI spec**: Add missing fields (`score: number`, `highlights: string[]`, `metadata.source: string`), fix required/optional markers (`summary` → optional, `relatedDocuments` → optional), regenerate `api.d.ts`.

**Step 2 — Create Zod schemas**: Create `src/schemas.ts` with Zod schemas that mirror the corrected OpenAPI spec. Export both the schemas AND the inferred TypeScript types (`z.infer<typeof SearchResultSchema>`). This becomes the single source of truth for runtime AND compile-time types.

**Step 3 — Unify database types**: Make `DbSearchResult` extend `ApiSearchResult` (add only DB-specific fields like `rowid`, `createdAt`, `embedding`). Delete the duplicate standalone `SearchResult` in `db.ts`. Update all imports.

**Step 4 — Zod-validate all endpoints**: Replace every `await c.req.json()` with `schema.parse(await c.req.json())`. Return proper 400 errors with Zod error messages on validation failure. Cover ALL endpoints:
  - `POST /api/search` (SearchRequestSchema)
  - `POST /api/summarize` (SummarizeRequestSchema)
  - `POST /api/documents` (CreateDocumentSchema)
  - `PUT /api/documents/:id` (UpdateDocumentSchema)
  - `POST /api/embeddings/generate` (GenerateEmbeddingsSchema)

**Step 5 — Eliminate all `any` casts**: Replace each of the ~10 `as any` / `: any` with proper types. For the search pipeline, type each stage's input/output. For middleware, type the context extensions.

**Step 6 — Type search pipeline end-to-end**: Create typed interfaces for each pipeline stage:
  - `QueryInput → EmbeddingResult → SearchHits → RankedResults → TransformedResults`
  - Each stage function signature: `(input: StageInput) => Promise<StageOutput>`
  - Pipeline composer that enforces type flow between stages

**Step 7 — Fix summarizer types**: Ensure `SummaryRequest` matches what's actually sent. Verify the response type matches what's returned. Wire through Zod schema validation.

**Step 8 — Add typecheck script**: Add `"typecheck": "tsc --noEmit"` to package.json. Run it. Fix any errors it surfaces. Ensure it runs in CI alongside tests.

**Step 9 — Conformance tests**: Write tests that parse REAL API responses through Zod schemas. If the schema parses successfully, types are correct at runtime. Cover:
  - Search response parsing
  - Summarize response parsing
  - Document CRUD response parsing
  - Error response parsing
  - Edge cases: empty results, max-length fields, unicode, null optionals

### Constraints & Guard Rails (CRITICAL — put these in the spec)

- **ALL 227 Vitest tests MUST stay green** after every step (not just at the end)
- **ALL 7 Playwright E2E tests MUST stay green** after every step
- **Zero runtime behavior changes** — this is a type-safety refactor, not a feature change
- **No new dependencies** except Zod (already in package.json but unused)
- **Incremental commits** — each step is a separate commit so we can bisect if something breaks
- **Backward compatible** — any external consumers of the API see zero changes
- **No generated code modification** — `api.d.ts` is generated, never hand-edited

### Complexity Amplifiers (stress-test the spec)

- The search pipeline has a **plugin system** where custom ranking functions can be injected. These plugins are currently untyped (`(results: any) => any`). The spec should require typing the plugin interface.
- There's a **WebSocket endpoint** (`/ws/search-stream`) that streams partial results. It needs typed message schemas too.
- The frontend uses **TanStack Query** with generic type parameters that should propagate from the Zod schemas (e.g., `useQuery<SearchResponse>` should use the Zod-inferred type).
- Error responses have 3 different shapes depending on the error type (validation, not-found, internal). These need a discriminated union type.
- The database has **migrations** — ensure the Drizzle schema types align with the unified type hierarchy.

### Non-Functional Requirements

- **Type coverage**: 100% of exported functions must have explicit return types (no inferred `any`)
- **Zero `any`**: `tsc --noEmit` with `strict: true` and `noExplicitAny: true` must pass
- **Schema performance**: Zod parsing must add < 1ms overhead per request (benchmark it)
- **Bundle size**: Adding Zod schemas should increase frontend bundle by < 5KB gzipped
- **Developer experience**: IDE autocomplete must work end-to-end (query builder → API → response)

---

## IMPORTANT — Agent Orchestration Instructions

After completing the specification:

1. **Save the spec** to `.specify/specs/full-stack-type-safety/spec.md`
2. **Self-validate** against every item in the Acceptance Checklist
3. **Generate a validation report** showing which checklist items pass/fail
4. **Then hand off** to the implementer agent with this exact message:

> Use the implementer agent to implement the spec at `.specify/specs/full-stack-type-safety/spec.md`. Implementation constraints:
>
> - Follow the 9-step order exactly (each step is a phase)
> - Write tests BEFORE implementation for each step (from acceptance scenarios)
> - Run `npm test` after EVERY step to verify 227 tests still pass
> - Run `npx playwright test` after steps 4, 5, 6, and 9 to verify E2E
> - Run `npx tsc --noEmit` after steps 5+ to verify type checking
> - Create tasks.md tracking every task with [US1]-[US9] labels
> - Log ALL deviations — do NOT silently diverge from the spec
> - After completing all 9 steps, hand off to the reviewer agent with:
>
>   "Use the reviewer agent to review the implementation against the spec at `.specify/specs/full-stack-type-safety/spec.md`. Generate the HTML compliance report as `review-report.html`. Check EVERY functional requirement, EVERY acceptance scenario, EVERY success criterion. Run tests to verify. Score the implementation and provide the verdict."

This is a **full automated pipeline test**: spec-writer → implementer → reviewer. Each agent must do its job completely and hand off cleanly. No human intervention between agents.

---

## Acceptance Criteria for the SPEC ITSELF (meta-level)

The spec you produce must:
- [ ] Have at least 9 user stories (one per step) with P1/P2/P3 priorities
- [ ] Have at least 25 functional requirements (FR-001 through FR-025+)
- [ ] Have at least 8 non-functional requirements
- [ ] Have at least 10 success criteria
- [ ] Have at least 15 edge cases documented
- [ ] Have at least 5 Given/When/Then scenarios per user story (45+ total)
- [ ] Include the plugin system, WebSocket, TanStack Query, and error union types
- [ ] Include the guard rails as hard constraints (not suggestions)
- [ ] Be technology-specific where needed (TypeScript, Zod, Hono, Drizzle, Vitest, Playwright)
- [ ] Have zero ambiguity — the implementer should need ZERO clarification
- [ ] Include a dependency graph showing which steps block which
- [ ] Include the conformance test strategy in detail
