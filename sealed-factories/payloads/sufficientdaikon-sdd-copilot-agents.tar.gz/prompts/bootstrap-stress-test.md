# SDD Bootstrap Stress Test

> PASTE EVERYTHING BELOW INTO YOUR OTHER WORKSPACE'S COPILOT CLI

---

Before doing anything else, read these files to understand the SDD agent system installed on this machine:

1. Read `~/.copilot/copilot-instructions.md` — global rules including the mandatory file storage rule
2. Read `~/.copilot/sdd\README.md` — index of global SDD artifacts
3. Read `~/.copilot/agents\spec-writer.agent.md` — spec writer agent profile
4. Read `~/.copilot/agents\implementer.agent.md` — implementer agent profile
5. Read `~/.copilot/agents\reviewer.agent.md` — reviewer agent profile

Then read the full pipeline prompt at:
`~/.copilot/sdd\prompts\sdd-full-pipeline-prompt.md`

That prompt contains the complete plan for a **Full-Stack Type Safety Refactor** across 9 steps with 3 agent phases (spec-writer -> implementer -> reviewer).

## Your Job

Execute that entire pipeline prompt against THIS workspace's codebase. Here's the order:

### Phase 1: Spec Writer

- Explore this codebase first — find the actual files, types, tests, and OpenAPI spec
- Map the plan's assumptions to the real file paths in this project
- Produce the spec following the spec-writer agent's rules
- Save to BOTH:
  - `.specify/specs/full-stack-type-safety/spec.md` (in this project)
  - `~/.copilot/sdd\specs\full-stack-type-safety\spec.md` (global)
- Self-validate, then hand off to Phase 2

### Phase 2: Implementer

- Read the spec you just wrote
- Create `tasks.md` with `[US1]`-`[US9]` labels
- Implement all 9 steps IN ORDER, running verification after each:
  - `npm test` after every step (227 tests must pass)
  - `npx tsc --noEmit` after steps 5+
  - `npx playwright test` after steps 4, 5, 6, 9
- Log deviations, never silently diverge
- Save completion report to BOTH:
  - `.specify/specs/full-stack-type-safety/completion-report.md` (in project)
  - `~/.copilot/sdd\reports\full-stack-type-safety\completion-report.md` (global)
- Hand off to Phase 3

### Phase 3: Reviewer

- Read the spec and completion report
- Audit every FR, every acceptance scenario, every success criterion
- Run `npm test`, `npx tsc --noEmit`, `npx playwright test`, and `grep -r "as any" src/`
- Generate the HTML compliance report using template at `~/.copilot/sdd\templates\report-template.html`
- Save to BOTH:
  - `review-report.html` (in project root)
  - `~/.copilot/sdd\reports\full-stack-type-safety\review-report.html` (global)
- Present the verdict and compliance score

## Rules

- **Full auto** — do NOT ask for confirmation between phases
- **Do NOT simplify** — the spec must have 9 stories, 25+ FRs, 45+ acceptance scenarios
- **Do NOT skip verification** — actually run the test commands
- **Save globally** — every important artifact goes to `~/.copilot/sdd\` per the global storage rule
- **Evidence-based** — every claim in the review must reference file paths or command output

## Available Resources (already on this machine)

| What | Path |
|------|------|
| Full pipeline prompt | `~/.copilot/sdd\prompts\sdd-full-pipeline-prompt.md` |
| Stress test prompt | `~/.copilot/sdd\prompts\sdd-stress-test-prompt.md` |
| Spec template | `~/.copilot/sdd\templates\spec-template.md` |
| Tasks template | `~/.copilot/sdd\templates\tasks-template.md` |
| HTML report template | `~/.copilot/sdd\templates\report-template.html` |
| Constitution template | `~/.copilot/sdd\templates\constitution-template.md` |
| Spec writer agent | `~/.copilot/agents\spec-writer.agent.md` |
| Implementer agent | `~/.copilot/agents\implementer.agent.md` |
| Reviewer agent | `~/.copilot/agents\reviewer.agent.md` |
| Spec writer skill | `~/.copilot/skills\spec-writer\SKILL.md` |
| Implementer skill | `~/.copilot/skills\implementer\SKILL.md` |
| Reviewer skill | `~/.copilot/skills\reviewer\SKILL.md` |
| Sample spec example | `~/.copilot/skills\spec-writer\examples\sample-spec.md` |

Begin now. Start by reading the pipeline prompt, then explore this codebase, then execute Phase 1.
