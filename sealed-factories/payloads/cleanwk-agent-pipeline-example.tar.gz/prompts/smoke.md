# Smoke Test

读取 Deployment Receipt，在授权环境中执行最小但具有代表性的 Smoke Test。发布包含环境引用、检查项、结果、失败证据和回滚建议的 Test Report。
