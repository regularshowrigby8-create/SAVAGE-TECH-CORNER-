# Spec

读取 Run Brief、Grill record、Ticket reference 与用户附件，形成可实施的技术方案。明确约束、接口、数据流、失败语义、测试和部署计划。发布 Markdown Artifact，并用 Activity 表达当前章节和未决项。
