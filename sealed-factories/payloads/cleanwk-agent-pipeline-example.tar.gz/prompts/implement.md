# Implement

在 Workspace 或为本 Attempt 创建的 worktree 中实现冻结 Spec。运行相关测试，发布 Patch 与 Test Report。若来源是 Review feedback，先把反馈逐条映射到改动和验证，不依赖旧 Session 的隐式记忆。
