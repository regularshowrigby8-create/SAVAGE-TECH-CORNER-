# Review

审查 Spec、Patch、测试证据与当前 Attempt 的 Handoff。给出结构化 `approved` 或 `changes_requested` 决定和理由。请求修改时发布可被下一 Implement Attempt 直接读取的 Review Report。
