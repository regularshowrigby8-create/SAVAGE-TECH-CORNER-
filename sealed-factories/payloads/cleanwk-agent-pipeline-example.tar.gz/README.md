# Agent Pipeline Example

一个可安装的七阶段研发交付 Pipeline Package，用来验证 Agent Pipeline 的公开协议与完整运行体验：

`Grill → Ticket → Spec → Implement ⇄ Review → Deploy → Smoke Test`

Review 请求修改时回到 Implement，并创建新的不可变 Attempt；循环最多三次，耗尽后进入人工 Attention。Package 不包含凭据，也不绑定某个 Agent 品牌。Node 声明能力，由安装它的 Workspace 解析到本机 Runtime、Skill、MCP 与业务 Adapter。

## Layout

- `agent-pipeline.package.yaml` — Package 元数据和入口
- `pipelines/product-delivery.yaml` — Graph、节点契约与 Policy
- `prompts/` — Agent Node 的工作说明
- `schemas/` — 旁路 Activity 与 Artifact 输出 Schema
- `tests/scenarios.yaml` — 确定性协议场景

## Install

一期可在 Agent Pipeline 中选择本地目录，或安装固定 commit 的 Git 仓库。发布后目标地址为 `https://github.com/cleanwk/agent-pipeline-example`。

License: Apache-2.0.
