# Agent Guide

This file orients coding agents (Claude Code and others) working in this
repository. It is intentionally short.

## Start here

1. Read [`CONTRIBUTING.md`](CONTRIBUTING.md) — project layout, the build/test/
   lint/docs commands, the coding conventions, and the commit/PR expectations
   every change must follow.
2. Then read, only as the task needs them, the docs under [`docs/`](docs/):
   [`technical-design.md`](docs/technical-design.md) (architecture and the
   `internal/` and `pkg/` packages — read before changing core behavior),
   [`installation.md`](docs/installation.md) (install / setup / distribution UX),
   [`read-only-mode.md`](docs/read-only-mode.md) (the write-safety posture), and
   [`releasing.md`](docs/releasing.md) (versioning, tagging, the release/CI
   workflows — read before cutting a release or touching `.github/workflows/`).

## What this is

`jenkins-cli` is an agent-facing CLI for a developer's Jenkins debugging
workflow: discover jobs and builds, read status / logs / stages / tests /
changes, and trigger or stop builds. It is a Go + Cobra CLI that mirrors the
architecture of the sibling `confluence-cli` / `bitbucket-cli` / `openobserve-cli`.

## Layout

- `cmd/jenkins-cli` — entry point; `cmd/gen-docs` — CLI reference generator.
- `internal/app` — one file per noun (job, build, queue, auth, config, doctor,
  skill); `root.go` assembles the tree; `context.go` holds the shared `appState`;
  `build_log.go` is the streaming `build log --follow`.
- `pkg/apiclient` — the Jenkins HTTP surface and models. One file per
  resource (jobs, builds, console, pipeline, tests, changes, queue, writes);
  `paths.go` maps human job paths and build refs to Jenkins URLs; `models.go`
  normalizes Jenkins JSON (color → status); `readonly.go` blocks the writes.
- `pkg/errors` — re-exports the shared `CLIError` model and exit-code map (0–11)
  and installs jenkins-cli's hints (`hints.go`).
- `pkg/transport` — re-exports the shared retrying HTTP client with
  jenkins-cli's User-Agent.
- `internal/config` — registers jenkins-cli's settings, file location and
  wording with the shared config engine, and keeps the YAML shape of
  `config.yaml`.
- `internal/auth` — declares jenkins-cli's auth schemes and recovery wording
  and maps config onto the shared resolver.
- Output rendering, argv correction, the update check, the credential store,
  credential resolution and the configuration engine come from [agent-cli-kit](https://github.com/AngelMsger/agent-cli-kit), shared
  by every CLI in the family. Fix bugs in those there, not here.
- `pkg/timeutil` — Jenkins epoch-millis → ISO instant + relative phrase.
- `skills/jenkins` — the companion Skill, embedded into the binary.

## Ground rules

- Run `make test` and `make build` before claiming a change is complete.
- stdout is data only; errors / notices / `--verbose` go to stderr.
- Keep paginated NDJSON rows on stdout and continuation in a structured
  `_notice.pagination` record on stderr after successful rendering, including
  filtered empty pages. Keep the real continuation flag in table and notice
  guidance; projections never remove pagination metadata.
  Current Jenkins list endpoints are unpaginated: do not invent cursors or
  advertise a `--cursor` flag for them.
- Never commit credentials, `.env`, or build artifacts.

## Discoverability — no dead-end inputs

**Every identifier a command accepts as input must be discoverable through
another command in this CLI.** A job path → `job list` / `job get`. A build
number → `build list`. A queue id → `queue list`. When you add a command or flag
that takes a new kind of input, also provide (or point its error `next_steps` at)
the command that lists values of that kind.

## When extending the control plane (P1)

Jenkins' control plane (create / configure jobs, credentials, nodes, CASC) is the
roadmap. New write commands must: add `--dry-run` (emit the would-be request via
a pure `*Plan` builder in `apiclient`, so it works even in read-only mode),
require `--yes` for destructive ops, route through `apiclient.NewReadOnly`
(override the new method to return `READONLY_BLOCKED`), fetch a CSRF crumb for
POSTs, and keep the `{items,has_more}` + structured-error contract.

**Keep the companion Skill in sync — it is the agent-facing source of truth.**
Any new command, subcommand, flag, or alias (and any change to write-gating) must
be reflected in the embedded Skill ([`skills/jenkins/`](skills/jenkins/): the
`SKILL.md` `## Commands` cheat-sheet and the relevant `references/` file) **in the
same commit**. Agents read the Skill instead of `--help`, so a capability it omits
effectively does not exist for them; a flag whose help text points at another
command must have that command listed in the Skill, and no Skill claim may
contradict the code.

Diagnosis examples must resolve moving build selectors once and reuse the
numeric build across stages, tests, logs and changes. Queue handoff uses
`executable.number`; a missing queue item is not evidence of a started build.
Keep unavailable-report errors neutral and preserve the selected run in recovery
steps. Agent monitoring needs an overall host deadline and output budget;
`--timeout` bounds individual requests. Execute shell recovery examples against
stubbed exit codes in tests, rather than asserting policy prose. Normalize
checkout line endings before extracting/executing examples and exercise both
LF and CRLF inputs.

## Team setup contract

Keep service presets separate from personal credentials. `config set-context`
must resolve the named destination (including a new one), ignore personal
variables before scheme inference, remain offline and credential-store-free,
and share one merge for dry-run and execution. Preserve other contexts, personal
usernames and shared defaults. Login must persist its identity as well as its
secret and reject a different complete service URL before credential writes.
Use the common acquisition guide in all prompt styles and missing-credential
recovery; never request a guide URL with credentials. Cover a fresh config reload,
conflict/idempotent setup, and partial persistence failures when changing this
flow. The canonical behavior is in the installation guide's team setup section.

## Credential reuse

Keep `auth reuse` separate from public service setup. Match complete URLs and
provider scope before credential access, preserve configured destination identities,
verify native credentials before associating missing identity, and retain operational
failures. Never copy secrets, infer identity from environment variables or activate
a context. Cover dry-run, ambiguity, scope mismatch, concurrent edits and fresh-load
credential resolution. Native self-configuration follows the existing read-only exception.

## Credential storage and cleanup

A stored secret is keyed by `<host>:<scheme>` (`auth.AccountKey`), not by
context: every context on one Jenkins shares it, including a team preset and
the personal context `auth reuse` associates with it. `config init` normalizes
the server URL and only ever saves a secret; it has no orphan cleanup.
`config delete-context` and `auth logout` are the paths that remove one.
`delete-context` forgets a secret only when no remaining context resolves the
same account (`forgetUnusedCredential`, as in the Atlassian CLIs), and only
after the config write. `internal/app/config_credentials_test.go` pins that an
edit which merely respells the URL, or moves a context to another server, keeps
every credential still in use, and that `delete-context` keeps a secret another
context resolves. A test that runs the command tree must call `keyring.MockInit()`
and clear `JENKINS_*` first, so it never reaches a developer's keychain or
environment.
