# SAVAGE FACTORY v4 DEBUG FINAL

Run `python3 SAVAGE_FACTORY.py --root /path/to/repo doctor` and `gate` from a disposable clone first. Read `docs/DEBUG_RUNBOOK.md` and `docs/FACTORY_REVIEW_FINAL.md` before applying cleanup or using APK release gates.

The `source/` directory is the readable materialized source corresponding to the standalone `SAVAGE_FACTORY.py` engine. The tests are intentionally adversarial and include false-green and destructive-cleanup regressions.
