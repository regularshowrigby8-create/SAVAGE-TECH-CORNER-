#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
 SAVAGE FACTORY - GENESIS
 One file. One command. A whole multi-stage software factory.
================================================================================

READ THIS FIRST (it is the entire manual)
-----------------------------------------
You are a model, possibly a small one. You do NOT need to understand the code in
this file. You only need to RUN it. Running it builds the whole factory on disk,
identically every time, and then the factory builds, verifies, packages, ships
and improves software with zero human intervention.

STEP 1 - put this file at the root of your repository, named exactly:

    SAVAGE_FACTORY.py

STEP 2 - run these three commands, in this order, from the repo root:

    python3 SAVAGE_FACTORY.py init      # materialise the factory (writes ~90 files)
    python3 SAVAGE_FACTORY.py doctor    # self-verify; must print: VERDICT: ALL GREEN
    python3 SAVAGE_FACTORY.py catalog   # print the 200+ tool registry

STEP 3 - that is it. If `doctor` prints ALL GREEN, the factory is real and
working. Nothing else is required. There is nothing to configure and no
dependency to install: this file uses only the Python standard library.

STEP 4 (optional) - build something:

    python3 SAVAGE_FACTORY.py build "car racing game"

STEP 5 (optional) - see exactly what the factory will delete and keep in your
existing repository BEFORE anything is touched:

    python3 SAVAGE_FACTORY.py adopt          # dry-run report (writes ADOPT.md)
    python3 SAVAGE_FACTORY.py adopt --apply  # only then does it delete anything

WHAT TO RUN IF YOU ONLY RUN ONE THING
-------------------------------------
    python3 SAVAGE_FACTORY.py all

`all` = init + doctor + catalog, in one shot. Use this if you are unsure.

WHAT THIS FILE KEEPS AND WHAT IT DELETES IN YOUR EXISTING REPO
--------------------------------------------------------------
The factory is ADDITIVE by default. `init` only ever WRITES new files
(savage/, factory/, .github/workflows/, README.md, docs/, tools/). It never
deletes or overwrites your existing work unless you pass `--force`.

Deletion is a separate, explicit, dry-run-first command: `adopt`. It classifies
every path in your repo into five buckets and prints them to ADOPT.md:

    KEEP     - never touched: .git/, README*, LICENSE*, docs/, and the factory.
    DELETE   - safe to remove: __pycache__/, *.pyc, node_modules/, caches, junk.
    MIRROR   - a duplicate tree (e.g. factory-2/ shadowed by factories/factory-2/);
               needs the extra `--mirrors` flag before it will ever be removed.
    REWRITE  - a hollow CI gate (contains `continue-on-error: true` or `|| true`);
               replace it with .github/workflows/savage-factory-gate.yml.
    UNKNOWN  - left completely alone. The model decides.

So the answer to "what gets deleted?" is: nothing, until you run
`adopt --apply`. And even then, only the DELETE bucket. KEEP and UNKNOWN are
never touched.

THE MODEL THIS FILE BUILDS
--------------------------
7 STAGES : intake -> spec -> build -> verify -> package -> ship -> improve
4 TIERS  : VERIFIED (green) / PROVISIONAL (yellow) / UNVERIFIED (orange) /
           QUARANTINE (red). Only VERIFIED tools may gate a release.
10 LAYERS: L1 Spec Amplifier, L2 Scaffold Selector, L3 Best-of-N Sampler,
           L4 Verifier/Ensemble, L5 Self-Repair Loop, L6 Constrained Decoding,
           L7 Golden Retrieval, L8 Deterministic Gates, L9 Sealed Holdout,
           L10 Worktree Isolation.
5 SPACES : factory/manager (routing+queue), factory/spaces/apk-cli (isolated APK
           build cell, the only release emitter), factory/cleaner (destructive
           maintenance), factory/improver (24/7 self-improvement),
           factory/adopt (keep/delete planner).
1 BUS    : MCP (stdio JSON-RPC 2.0) - a 32-server fleet.

DESIGN LAW
----------
"Deterministic shell, agentic core." The workflow is plain Python + JSON. Agents
are bounded nodes. Nothing merges without a deterministic gate. No piracy, no
leaked keys, no ToS bypass, no faked results. Ever.

HOW A LOW-END MODEL GETS PREMIUM OUTPUT
---------------------------------------
1. Run `init`. Everything appears. Nothing to interpret.
2. Run `doctor`. ALL GREEN means the factory is real and working.
3. Call `build("your idea")`. The harness amplifies the spec (L1), picks a
   scaffold (L2), samples N candidates in isolated worktrees (L3/L10), verifies
   with a DIFFERENT model (L4), repairs until the deterministic gates pass
   (L5/L8), then re-checks against a SEALED holdout the generator never saw
   (L9). It returns a verified artifact + a BuildResult.
4. That is it. The premium result comes from the harness, not from the model.

Everything below is real, runnable code. There are no stubs and no placeholders.
================================================================================
"""

from __future__ import annotations

import argparse
import base64
import dataclasses
import datetime as _dt
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import textwrap
import time
import traceback
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

# ------------------------------------------------------------------------------
# 0. CONSTANTS
# ------------------------------------------------------------------------------

GENESIS_VERSION = "4.0.0"
GENESIS_CODENAME = "SAVAGE-GENESIS"

# The canonical filename of this single file.  Referenced by every generated
# document so the instructions never drift from reality.
SELF_NAME = "SAVAGE_FACTORY.py"

# Harness defaults (mirrored inside savage/config.py so the embedded package and
# the single-file CLI agree).  Override with SAVAGE_N / SAVAGE_BUDGET_ROUNDS.
DEFAULT_N = int(os.environ.get("SAVAGE_N", "8"))
DEFAULT_BUDGET_ROUNDS = int(os.environ.get("SAVAGE_BUDGET_ROUNDS", "4"))

STAGES: Tuple[str, ...] = (
    "intake", "spec", "build", "verify", "package", "ship", "improve",
)

TIERS: Tuple[str, ...] = ("verified", "provisional", "unverified", "quarantine")
TIER_ICON: Dict[str, str] = {
    "verified": "\U0001F7E2",     # green
    "provisional": "\U0001F7E1",  # yellow
    "unverified": "\U0001F7E0",   # orange
    "quarantine": "\U0001F534",   # red
}
# Only these tiers are allowed to gate a release.
GATE_TIERS: Tuple[str, ...] = ("verified",)

# Stage -> model class.  "premium" = strong reasoning model, "cheap" = fast small
# model, "none" = no LLM at all (pure deterministic tooling).
ROUTING: Dict[str, str] = {
    "intake": "none",
    "spec": "premium",
    "build": "cheap",
    "verify": "premium",
    "package": "none",
    "ship": "none",
    "improve": "cheap",
}

GROUPS: Dict[str, str] = {
    "A": "Adopted app-builder / IDE-agent repos",
    "B": "Free LLM model endpoints (OpenAI-compatible)",
    "C": "Build / agent tooling",
    "D": "Android / APK tooling",
    "E": "Technique libraries (premium harness ingredients)",
    "F": "Core native tools",
    "G": "Verify native tools",
    "H": "Package native tools",
    "I": "Ship native tools",
    "J": "Intake native tools",
    "K": "Improve native tools",
    "L": "MCP native tools",
    "M": "Security native tools",
    "N": "Media native tools",
    "O": "Factory-pattern repos (sealed verification / worktree isolation)",
}

# ------------------------------------------------------------------------------
# 1. THE TOOL CATALOG  (200+ tools; schema: id, name, group, tier, kind,
#    requires, purpose, network)
#    kind in {check, build, report, fetch, transform, sandbox, sign, scan,
#             agent, endpoint, mcp}
# ------------------------------------------------------------------------------

ToolTuple = Tuple[str, str, str, str, str, str, str, bool]


def _t(i: str, n: str, g: str, tier: str, kind: str, req: str, purpose: str,
       net: bool = False) -> ToolTuple:
    return (i, n, g, tier, kind, req, purpose, net)


TOOL_CATALOG: List[ToolTuple] = [
    # ---- Group A: adopted app-builder / IDE-agent repos (30) -----------------
    _t("bolt-diy", "bolt.diy", "A", "provisional", "agent", "node", "Browser AI app builder; scaffold + live preview", True),
    _t("dyad", "Dyad", "A", "provisional", "agent", "node", "Local-first AI app builder", True),
    _t("onlook", "Onlook", "A", "unverified", "agent", "node", "Visual editor that writes React code", True),
    _t("void", "Void", "A", "provisional", "agent", "node", "Open-source AI code editor", True),
    _t("continue", "Continue", "A", "provisional", "agent", "node", "IDE assistant with custom context", True),
    _t("cline", "Cline", "A", "provisional", "agent", "node", "Autonomous coding agent for VS Code", True),
    _t("roo-code", "Roo Code", "A", "provisional", "agent", "node", "Multi-mode coding agent", True),
    _t("tabby", "Tabby", "A", "unverified", "agent", "node", "Self-hosted coding assistant", True),
    _t("openhands", "OpenHands", "A", "provisional", "agent", "docker", "General software-dev agent platform", True),
    _t("gpt-pilot", "GPT-Pilot", "A", "unverified", "agent", "python", "Multi-agent app generator", True),
    _t("sweep", "Sweep", "A", "unverified", "agent", "python", "Issue-to-PR agent", True),
    _t("pr-agent", "PR-Agent", "A", "provisional", "agent", "python", "Automated PR review agent", True),
    _t("aider", "Aider", "A", "verified", "agent", "python", "Repo-aware pair programmer (git-native)", True),
    _t("open-interpreter", "Open Interpreter", "A", "provisional", "agent", "python", "Natural-language code execution", True),
    _t("gpt-engineer", "gpt-engineer", "A", "provisional", "agent", "python", "Spec-to-codebase generator", True),
    _t("metagpt", "MetaGPT", "A", "provisional", "agent", "python", "Multi-agent software company sim", True),
    _t("autogen", "AutoGen", "A", "provisional", "agent", "python", "Conversable multi-agent framework", True),
    _t("crewai", "CrewAI", "A", "provisional", "agent", "python", "Role-based agent crews", True),
    _t("langgraph", "LangGraph", "A", "verified", "agent", "python", "Stateful agent graphs", True),
    _t("swarm", "OpenAI Swarm", "A", "unverified", "agent", "python", "Lightweight agent handoffs", True),
    _t("camel", "CAMEL", "A", "unverified", "agent", "python", "Communicative agent societies", True),
    _t("agent-zero", "Agent Zero", "A", "unverified", "agent", "docker", "General autonomous agent", True),
    _t("devika", "Devika", "A", "unverified", "agent", "python", "Agentic software engineer", True),
    _t("smol-developer", "smol-developer", "A", "unverified", "agent", "python", "Tiny codebase generator", True),
    _t("potpie", "Potpie", "A", "unverified", "agent", "python", "Codebase knowledge-graph agent", True),
    _t("gpt-researcher", "GPT Researcher", "A", "provisional", "agent", "python", "Autonomous research agent", True),
    _t("storm", "STORM", "A", "unverified", "agent", "python", "Wiki-article generation", True),
    _t("khoj", "Khoj", "A", "unverified", "agent", "python", "Personal AI knowledge base", True),
    _t("morphic", "Morphic", "A", "unverified", "agent", "node", "AI answer engine UI", True),
    _t("perplexica", "Perplexica", "A", "unverified", "agent", "node", "Open-source answer engine", True),

    # ---- Group B: free model endpoints (26) ----------------------------------
    _t("github-models", "GitHub Models", "B", "verified", "endpoint", "token", "Free GPT/o-series inference via GitHub token", True),
    _t("groq", "Groq", "B", "verified", "endpoint", "key", "Ultra-fast LPU inference, free tier", True),
    _t("cerebras", "Cerebras", "B", "provisional", "endpoint", "key", "Wafer-scale fast inference, free tier", True),
    _t("gemini", "Google Gemini", "B", "verified", "endpoint", "key", "Gemini free tier via AI Studio", True),
    _t("deepseek", "DeepSeek", "B", "provisional", "endpoint", "key", "Cheap strong coder models", True),
    _t("openrouter", "OpenRouter", "B", "provisional", "endpoint", "key", "Multi-provider gateway incl. free models", True),
    _t("mistral", "Mistral", "B", "provisional", "endpoint", "key", "Mistral free tier", True),
    _t("together", "Together AI", "B", "provisional", "endpoint", "key", "Open-model hosting, free credits", True),
    _t("fireworks", "Fireworks", "B", "unverified", "endpoint", "key", "Fast open-model hosting", True),
    _t("hyperbolic", "Hyperbolic", "B", "unverified", "endpoint", "key", "Cheap open-model inference", True),
    _t("sambanova", "SambaNova", "B", "unverified", "endpoint", "key", "Fast inference cloud", True),
    _t("nvidia-nim", "NVIDIA NIM", "B", "provisional", "endpoint", "key", "NVIDIA-hosted model APIs", True),
    _t("cloudflare-ai", "Cloudflare Workers AI", "B", "unverified", "endpoint", "key", "Edge inference, free allowance", True),
    _t("hf-inference", "HuggingFace Inference", "B", "provisional", "endpoint", "token", "Hosted open models", True),
    _t("replicate", "Replicate", "B", "unverified", "endpoint", "token", "Model zoo with pay-per-run", True),
    _t("ollama", "Ollama", "B", "verified", "endpoint", "local", "Local model runtime (offline capable)", False),
    _t("lmstudio", "LM Studio", "B", "provisional", "endpoint", "local", "Local OpenAI-compatible server", False),
    _t("vllm", "vLLM", "B", "provisional", "endpoint", "local", "High-throughput local serving", False),
    _t("llamacpp", "llama.cpp", "B", "verified", "endpoint", "local", "CPU/GPU local inference", False),
    _t("textgen-webui", "Text-Gen-WebUI", "B", "unverified", "endpoint", "local", "Local model web UI + API", False),
    _t("jan", "Jan", "B", "unverified", "endpoint", "local", "Desktop local model app", False),
    _t("gpt4all", "GPT4All", "B", "unverified", "endpoint", "local", "Local model desktop app", False),
    _t("openrouter-free", "OpenRouter :free", "B", "provisional", "endpoint", "key", "Zero-cost model variants", True),
    _t("glhf", "GLHF", "B", "quarantine", "endpoint", "key", "Unstable free endpoint (quarantined)", True),
    _t("novita", "Novita AI", "B", "unverified", "endpoint", "key", "Open-model hosting", True),
    _t("lepton", "Lepton AI", "B", "unverified", "endpoint", "key", "Serverless model hosting", True),

    # ---- Group C: build / agent tooling (28) ---------------------------------
    _t("repomix", "Repomix", "C", "verified", "transform", "node", "Pack a repo into one LLM-friendly file", True),
    _t("aider-cli", "Aider CLI", "C", "verified", "agent", "python", "Headless pair-programming CLI", True),
    _t("open-interpreter-cli", "Open Interpreter CLI", "C", "provisional", "agent", "python", "Headless interpreter", True),
    _t("gpt-engineer-cli", "gpt-engineer CLI", "C", "provisional", "agent", "python", "Headless spec-to-code", True),
    _t("metagpt-cli", "MetaGPT CLI", "C", "unverified", "agent", "python", "Headless multi-agent", True),
    _t("autogen-cli", "AutoGen CLI", "C", "unverified", "agent", "python", "Headless agent chat", True),
    _t("crewai-cli", "CrewAI CLI", "C", "unverified", "agent", "python", "Headless crews", True),
    _t("langgraph-cli", "LangGraph CLI", "C", "provisional", "agent", "python", "Graph server + dev runner", True),
    _t("swe-agent", "SWE-agent", "C", "provisional", "agent", "python", "SWE-bench style issue fixer", True),
    _t("openhands-cli", "OpenHands CLI", "C", "provisional", "agent", "docker", "Headless OpenHands", True),
    _t("continue-cli", "Continue CLI", "C", "unverified", "agent", "node", "Headless Continue", True),
    _t("cline-cli", "Cline CLI", "C", "unverified", "agent", "node", "Headless Cline", True),
    _t("roo-cli", "Roo CLI", "C", "unverified", "agent", "node", "Headless Roo", True),
    _t("tabby-cli", "Tabby CLI", "C", "unverified", "agent", "node", "Headless Tabby", True),
    _t("aider-chat", "aider-chat", "C", "verified", "agent", "python", "Aider chat entrypoint", True),
    _t("codex-cli", "OpenAI Codex CLI", "C", "provisional", "agent", "node", "Terminal coding agent", True),
    _t("claude-code", "Claude Code", "C", "provisional", "agent", "node", "Anthropic terminal agent", True),
    _t("gemini-cli", "Gemini CLI", "C", "provisional", "agent", "node", "Google terminal agent", True),
    _t("qwen-code", "Qwen Code", "C", "unverified", "agent", "node", "Qwen terminal agent", True),
    _t("opencode", "opencode", "C", "unverified", "agent", "node", "Open terminal agent", True),
    _t("goose", "Goose", "C", "provisional", "agent", "node", "Block's local agent", True),
    _t("amp", "Amp", "C", "unverified", "agent", "node", "Frontier coding agent", True),
    _t("cursor-agent", "Cursor Agent", "C", "unverified", "agent", "node", "Cursor headless agent", True),
    _t("windsurf-agent", "Windsurf Agent", "C", "unverified", "agent", "node", "Windsurf headless agent", True),
    _t("cody", "Sourcegraph Cody", "C", "unverified", "agent", "node", "Codebase-aware assistant", True),
    _t("cody-cli", "Cody CLI", "C", "unverified", "agent", "node", "Headless Cody", True),
    _t("pieces", "Pieces", "C", "unverified", "agent", "node", "Snippet memory assistant", True),
    _t("zed-agent", "Zed Agent", "C", "unverified", "agent", "node", "Zed editor agent", True),

    # ---- Group D: Android / APK tooling (31) ---------------------------------
    _t("jadx", "jadx", "D", "verified", "transform", "java", "Dex -> Java decompiler", False),
    _t("apktool", "apktool", "D", "verified", "transform", "java", "APK decode/rebuild", False),
    _t("mobsf", "MobSF", "D", "provisional", "scan", "docker", "Mobile security analysis", False),
    _t("apkid", "APKiD", "D", "verified", "scan", "python", "Packer/obfuscator fingerprint", False),
    _t("dex2jar", "dex2jar", "D", "verified", "transform", "java", "Dex -> jar bridge", False),
    _t("androguard", "Androguard", "D", "verified", "scan", "python", "Static APK analysis", False),
    _t("frida", "Frida", "D", "provisional", "sandbox", "python", "Dynamic instrumentation", False),
    _t("objection", "objection", "D", "provisional", "sandbox", "python", "Frida-powered mobile runtime", False),
    _t("lief", "LIEF", "D", "provisional", "transform", "python", "Binary (ELF/DEX) rewriting", False),
    _t("ghidra", "Ghidra", "D", "provisional", "transform", "java", "NSA reverse-engineering suite", False),
    _t("radare2", "radare2", "D", "provisional", "transform", "system", "Binary analysis framework", False),
    _t("classyshark", "ClassyShark", "D", "unverified", "scan", "java", "APK class browser", False),
    _t("smali", "smali/baksmali", "D", "verified", "transform", "java", "Dex <-> smali assembler", False),
    _t("bytecode-viewer", "Bytecode Viewer", "D", "unverified", "transform", "java", "Multi-decompiler GUI", False),
    _t("jadx-gui", "jadx-gui", "D", "unverified", "transform", "java", "jadx GUI", False),
    _t("uber-apk-signer", "uber-apk-signer", "D", "provisional", "sign", "java", "One-shot APK signing", False),
    _t("apksigner", "apksigner", "D", "verified", "sign", "android-sdk", "Official APK signer", False),
    _t("zipalign", "zipalign", "D", "verified", "build", "android-sdk", "Align APK for mmap", False),
    _t("aapt2", "aapt2", "D", "verified", "build", "android-sdk", "Android asset packaging", False),
    _t("d8", "d8", "D", "verified", "build", "android-sdk", "Dex compiler", False),
    _t("r8", "r8", "D", "verified", "build", "android-sdk", "Shrinker/optimizer", False),
    _t("baksmali", "baksmali", "D", "verified", "transform", "java", "Dex -> smali", False),
    _t("drozer", "drozer", "D", "unverified", "scan", "python", "Android attack-surface scanner", False),
    _t("quark-engine", "Quark-Engine", "D", "provisional", "scan", "python", "Malware scoring engine", False),
    _t("capa", "capa", "D", "provisional", "scan", "python", "Capability detection", False),
    _t("floss", "FLOSS", "D", "unverified", "scan", "python", "Obfuscated string extraction", False),
    _t("apkleaks", "APKLeaks", "D", "provisional", "scan", "python", "Secret scanning in APKs", False),
    _t("androwarn", "Androwarn", "D", "unverified", "scan", "python", "Malicious-behaviour report", False),
    _t("exodus", "Exodus", "D", "unverified", "scan", "python", "Tracker detection", False),
    _t("dexcalibur", "Dexcalibur", "D", "unverified", "sandbox", "node", "Automated dynamic analysis", False),
    _t("classyshark3xodus", "ClassyShark3xodus", "D", "unverified", "scan", "java", "Tracker scanner", False),

    # ---- Group E: technique libraries (35) -----------------------------------
    _t("dspy", "DSPy", "E", "provisional", "transform", "python", "Programmatic prompt optimisation", True),
    _t("textgrad", "TextGrad", "E", "unverified", "transform", "python", "Textual gradient optimisation", True),
    _t("outlines", "Outlines", "E", "provisional", "transform", "python", "Structured generation", True),
    _t("guidance", "Guidance", "E", "provisional", "transform", "python", "Constrained generation DSL", True),
    _t("lmql", "LMQL", "E", "unverified", "transform", "python", "Query language for LLMs", True),
    _t("instructor", "Instructor", "E", "provisional", "transform", "python", "Pydantic-validated outputs", True),
    _t("sglang", "SGLang", "E", "unverified", "transform", "python", "Fast structured serving", True),
    _t("llama-cpp-python", "llama-cpp-python", "E", "provisional", "transform", "python", "Python bindings to llama.cpp", False),
    _t("ollama-python", "ollama-python", "E", "verified", "transform", "python", "Python client for Ollama", False),
    _t("jsonformer", "Jsonformer", "E", "unverified", "transform", "python", "JSON-constrained decoding", True),
    _t("grammar-sampling", "Grammar Sampling", "E", "unverified", "transform", "python", "CFG-constrained sampling", True),
    _t("gbnf", "GBNF Grammars", "E", "provisional", "transform", "local", "llama.cpp grammar format", False),
    _t("llguidance", "llguidance", "E", "unverified", "transform", "python", "Fast grammar guidance", True),
    _t("xgrammar", "XGrammar", "E", "provisional", "transform", "python", "Flexible grammar engine", True),
    _t("pydantic", "Pydantic", "E", "verified", "transform", "python", "Data validation core", False),
    _t("marvin", "Marvin", "E", "unverified", "transform", "python", "AI functions + typing", True),
    _t("mirascope", "Mirascope", "E", "unverified", "transform", "python", "LLM toolkit", True),
    _t("langchain", "LangChain", "E", "provisional", "transform", "python", "LLM app framework", True),
    _t("llamaindex", "LlamaIndex", "E", "provisional", "transform", "python", "RAG/data framework", True),
    _t("haystack", "Haystack", "E", "unverified", "transform", "python", "NLP pipelines", True),
    _t("semantic-kernel", "Semantic Kernel", "E", "unverified", "transform", "python", "Microsoft agent SDK", True),
    _t("litellm", "LiteLLM", "E", "verified", "transform", "python", "One API for 100+ providers", True),
    _t("openai-python", "openai-python", "E", "verified", "transform", "python", "OpenAI client (compatible)", True),
    _t("anthropic-sdk", "anthropic-sdk", "E", "provisional", "transform", "python", "Anthropic client", True),
    _t("transformers", "HF Transformers", "E", "verified", "transform", "python", "Model loading/training", True),
    _t("peft", "PEFT", "E", "provisional", "transform", "python", "Parameter-efficient fine-tuning", True),
    _t("trl", "TRL", "E", "provisional", "transform", "python", "RL fine-tuning", True),
    _t("unsloth", "Unsloth", "E", "unverified", "transform", "python", "Fast fine-tuning", True),
    _t("axolotl", "Axolotl", "E", "unverified", "transform", "python", "Fine-tuning toolkit", True),
    _t("autotrain", "AutoTrain", "E", "unverified", "transform", "python", "No-code fine-tuning", True),
    _t("mergekit", "mergekit", "E", "unverified", "transform", "python", "Model merging", True),
    _t("exllamav2", "ExLlamaV2", "E", "unverified", "transform", "python", "Fast local inference", False),
    _t("awq", "AWQ", "E", "unverified", "transform", "python", "Activation-aware quantisation", True),
    _t("gptqmodel", "GPTQModel", "E", "unverified", "transform", "python", "GPTQ quantisation", True),

    # ---- Group F: core native tools (40) -------------------------------------
    _t("git", "Git", "F", "verified", "check", "git", "Reject whitespace errors in patch", False),
    _t("gh", "GitHub CLI", "F", "verified", "report", "gh", "CI state without publishing", True),
    _t("ripgrep", "ripgrep", "F", "verified", "check", "system", "Fast recursive search", False),
    _t("fd", "fd", "F", "verified", "check", "system", "Fast file finder", False),
    _t("jq", "jq", "F", "verified", "transform", "system", "JSON processor", False),
    _t("yq", "yq", "F", "verified", "transform", "system", "YAML processor", False),
    _t("ast-grep", "ast-grep", "F", "provisional", "check", "node", "Structural code search", False),
    _t("semgrep", "Semgrep", "F", "provisional", "scan", "python", "Pattern-based SAST", True),
    _t("tree-sitter", "tree-sitter", "F", "provisional", "transform", "system", "Incremental parser", False),
    _t("ctags", "ctags", "F", "unverified", "report", "system", "Symbol index", False),
    _t("universal-ctags", "universal-ctags", "F", "unverified", "report", "system", "Symbol index (extended)", False),
    _t("tokei", "tokei", "F", "verified", "report", "system", "Line-count stats", False),
    _t("scc", "scc", "F", "provisional", "report", "system", "Code counter (complexity)", False),
    _t("hyperfine", "hyperfine", "F", "verified", "report", "system", "Command benchmarking", False),
    _t("just", "just", "F", "provisional", "build", "system", "Command runner", False),
    _t("make", "GNU Make", "F", "verified", "build", "system", "Build orchestration", False),
    _t("task", "Task", "F", "unverified", "build", "system", "Task runner", False),
    _t("pre-commit", "pre-commit", "F", "verified", "check", "python", "Git hook manager", False),
    _t("lefthook", "lefthook", "F", "unverified", "check", "system", "Fast git hooks", False),
    _t("direnv", "direnv", "F", "unverified", "build", "system", "Per-dir env loader", False),
    _t("mise", "mise", "F", "provisional", "build", "system", "Toolchain version manager", False),
    _t("asdf", "asdf", "F", "provisional", "build", "system", "Multi-runtime version manager", False),
    _t("uv", "uv", "F", "verified", "build", "python", "Fast Python package manager", True),
    _t("pipx", "pipx", "F", "verified", "build", "python", "Isolated app installer", True),
    _t("poetry", "Poetry", "F", "provisional", "build", "python", "Python dep management", True),
    _t("pnpm", "pnpm", "F", "provisional", "build", "node", "Fast Node package manager", True),
    _t("bun", "Bun", "F", "unverified", "build", "node", "Fast JS runtime", True),
    _t("deno", "Deno", "F", "unverified", "build", "node", "Secure JS/TS runtime", True),
    _t("node", "Node.js", "F", "verified", "build", "node", "JS runtime", False),
    _t("python", "Python", "F", "verified", "build", "python", "Python runtime", False),
    _t("ruff", "Ruff", "F", "verified", "check", "python", "Fast Python linter/formatter", False),
    _t("black", "Black", "F", "verified", "transform", "python", "Python formatter", False),
    _t("isort", "isort", "F", "verified", "transform", "python", "Import sorter", False),
    _t("mypy", "mypy", "F", "verified", "check", "python", "Static type checker", False),
    _t("pyright", "Pyright", "F", "provisional", "check", "node", "Fast type checker", False),
    _t("pylint", "Pylint", "F", "provisional", "check", "python", "Python linter", False),
    _t("flake8", "Flake8", "F", "provisional", "check", "python", "Style checker", False),
    _t("bandit", "Bandit", "F", "verified", "scan", "python", "Python security linter", False),
    _t("vulture", "Vulture", "F", "provisional", "check", "python", "Dead-code finder", False),
    _t("interrogate", "Interrogate", "F", "unverified", "check", "python", "Docstring coverage", False),

    # ---- Group G: verify native tools (22) -----------------------------------
    _t("pytest", "pytest", "G", "verified", "check", "python", "Test runner", False),
    _t("coverage", "coverage.py", "G", "verified", "report", "python", "Coverage measurement", False),
    _t("hypothesis", "Hypothesis", "G", "provisional", "check", "python", "Property-based testing", False),
    _t("mutmut", "mutmut", "G", "provisional", "check", "python", "Mutation testing", False),
    _t("cosmic-ray", "Cosmic Ray", "G", "unverified", "check", "python", "Mutation testing", False),
    _t("tox", "tox", "G", "provisional", "check", "python", "Env matrix runner", False),
    _t("nox", "Nox", "G", "unverified", "check", "python", "Flexible test sessions", False),
    _t("schemathesis", "Schemathesis", "G", "provisional", "check", "python", "Property-based API testing", True),
    _t("dredd", "Dredd", "G", "unverified", "check", "node", "API contract testing", True),
    _t("pact", "Pact", "G", "unverified", "check", "node", "Consumer-driven contracts", True),
    _t("restler", "RESTler", "G", "unverified", "check", "python", "REST fuzzing", True),
    _t("k6", "k6", "G", "provisional", "report", "system", "Load testing", True),
    _t("locust", "Locust", "G", "provisional", "report", "python", "Load testing", True),
    _t("vegeta", "Vegeta", "G", "unverified", "report", "system", "HTTP load testing", True),
    _t("wrk", "wrk", "G", "unverified", "report", "system", "HTTP benchmarking", True),
    _t("ab", "ApacheBench", "G", "unverified", "report", "system", "HTTP benchmarking", True),
    _t("newman", "Newman", "G", "unverified", "check", "node", "Postman collection runner", True),
    _t("bats", "Bats", "G", "provisional", "check", "system", "Bash test framework", False),
    _t("shellcheck", "ShellCheck", "G", "verified", "check", "system", "Shell linter", False),
    _t("shfmt", "shfmt", "G", "provisional", "transform", "system", "Shell formatter", False),
    _t("actionlint", "actionlint", "G", "provisional", "check", "system", "GitHub Actions linter", False),
    _t("zizmor", "zizmor", "G", "unverified", "scan", "python", "Actions security audit", True),

    # ---- Group H: package native tools (18) ----------------------------------
    _t("docker", "Docker", "H", "verified", "build", "docker", "Container build/run", False),
    _t("podman", "Podman", "H", "provisional", "build", "system", "Rootless containers", False),
    _t("buildah", "Buildah", "H", "unverified", "build", "system", "Image building", False),
    _t("kaniko", "Kaniko", "H", "unverified", "build", "docker", "In-cluster image builds", False),
    _t("nerdctl", "nerdctl", "H", "unverified", "build", "system", "containerd CLI", False),
    _t("buildx", "Buildx", "H", "provisional", "build", "docker", "Advanced image builds", False),
    _t("skopeo", "Skopeo", "H", "unverified", "transform", "system", "Image copy/inspect", False),
    _t("trivy", "Trivy", "H", "verified", "scan", "system", "Vuln + misconfig scanner", True),
    _t("syft", "Syft", "H", "provisional", "report", "system", "SBOM generator", False),
    _t("grype", "Grype", "H", "provisional", "scan", "system", "Vuln scanner for SBOMs", True),
    _t("cosign", "Cosign", "H", "provisional", "sign", "system", "Container signing", True),
    _t("sbom-tool", "Microsoft SBOM Tool", "H", "unverified", "report", "system", "SBOM generation", False),
    _t("cyclonedx", "CycloneDX", "H", "provisional", "report", "python", "SBOM standard tooling", False),
    _t("spdx-sbom", "SPDX SBOM Gen", "H", "unverified", "report", "system", "SPDX SBOM generation", False),
    _t("in-toto", "in-toto", "H", "unverified", "sign", "python", "Supply-chain attestation", False),
    _t("slsa-verifier", "SLSA Verifier", "H", "unverified", "check", "system", "Provenance verification", True),
    _t("rekor", "Rekor", "H", "unverified", "sign", "system", "Transparency log", True),
    _t("fulcio", "Fulcio", "H", "unverified", "sign", "system", "Sigstore CA", True),

    # ---- Group I: ship native tools (22) -------------------------------------
    _t("helm", "Helm", "I", "provisional", "build", "system", "K8s package manager", True),
    _t("kubectl", "kubectl", "I", "provisional", "build", "system", "K8s CLI", True),
    _t("kustomize", "Kustomize", "I", "unverified", "build", "system", "K8s config overlay", True),
    _t("argocd", "Argo CD", "I", "unverified", "build", "system", "GitOps delivery", True),
    _t("flux", "Flux", "I", "unverified", "build", "system", "GitOps delivery", True),
    _t("terraform", "Terraform", "I", "provisional", "build", "system", "Infra as code", True),
    _t("pulumi", "Pulumi", "I", "unverified", "build", "node", "Infra as code", True),
    _t("ansible", "Ansible", "I", "provisional", "build", "python", "Config management", True),
    _t("fastlane", "fastlane", "I", "provisional", "build", "system", "Mobile release automation", True),
    _t("gradle", "Gradle", "I", "verified", "build", "java", "JVM/Android build system", True),
    _t("maven", "Maven", "I", "provisional", "build", "java", "JVM build system", True),
    _t("npm-publish", "npm publish", "I", "provisional", "sign", "node", "Publish Node packages", True),
    _t("twine", "Twine", "I", "provisional", "sign", "python", "Publish Python packages", True),
    _t("cargo-publish", "cargo publish", "I", "unverified", "sign", "system", "Publish Rust crates", True),
    _t("gh-release", "gh release", "I", "verified", "sign", "gh", "GitHub release creation", True),
    _t("semantic-release", "semantic-release", "I", "provisional", "sign", "node", "Automated versioning", True),
    _t("release-please", "release-please", "I", "provisional", "sign", "node", "Release PR automation", True),
    _t("changesets", "Changesets", "I", "unverified", "sign", "node", "Versioning workflow", True),
    _t("goreleaser", "GoReleaser", "I", "unverified", "sign", "system", "Go release automation", True),
    _t("jreleaser", "JReleaser", "I", "unverified", "sign", "java", "JVM release automation", True),
    _t("cargo-dist", "cargo-dist", "I", "unverified", "sign", "system", "Rust release automation", True),
    _t("nfpm", "nfpm", "I", "unverified", "sign", "system", "deb/rpm/apk packaging", False),

    # ---- Group J: intake native tools (18) -----------------------------------
    _t("pandoc", "Pandoc", "J", "verified", "transform", "system", "Universal doc converter", False),
    _t("pdftotext", "pdftotext", "J", "verified", "transform", "system", "PDF text extraction", False),
    _t("antiword", "antiword", "J", "provisional", "transform", "system", "Word doc extraction", False),
    _t("catdoc", "catdoc", "J", "provisional", "transform", "system", "Legacy doc extraction", False),
    _t("unrtf", "unrtf", "J", "unverified", "transform", "system", "RTF extraction", False),
    _t("tesseract", "Tesseract", "J", "provisional", "transform", "system", "OCR", False),
    _t("whisper", "Whisper", "J", "provisional", "transform", "python", "Speech-to-text", False),
    _t("ffmpeg", "FFmpeg", "J", "verified", "transform", "system", "Media transcode", False),
    _t("yt-dlp", "yt-dlp", "J", "provisional", "fetch", "python", "Media download", True),
    _t("trafilatura", "Trafilatura", "J", "provisional", "fetch", "python", "Web text extraction", True),
    _t("readability", "Readability", "J", "unverified", "fetch", "python", "Article extraction", True),
    _t("newspaper", "Newspaper3k", "J", "unverified", "fetch", "python", "News scraping", True),
    _t("beautifulsoup", "BeautifulSoup", "J", "verified", "transform", "python", "HTML parsing", False),
    _t("lxml", "lxml", "J", "verified", "transform", "python", "XML/HTML parsing", False),
    _t("html2text", "html2text", "J", "provisional", "transform", "python", "HTML -> Markdown", False),
    _t("markitdown", "MarkItDown", "J", "provisional", "transform", "python", "Anything -> Markdown", False),
    _t("docling", "Docling", "J", "unverified", "transform", "python", "Document understanding", False),
    _t("unstructured", "Unstructured", "J", "provisional", "transform", "python", "Document ETL", False),

    # ---- Group K: improve native tools (12) ----------------------------------
    _t("dvc", "DVC", "K", "unverified", "report", "python", "Data/model versioning", True),
    _t("mlflow", "MLflow", "K", "provisional", "report", "python", "Experiment tracking", True),
    _t("wandb", "Weights & Biases", "K", "unverified", "report", "python", "Experiment tracking", True),
    _t("optuna", "Optuna", "K", "provisional", "transform", "python", "Hyperparameter search", False),
    _t("ray-tune", "Ray Tune", "K", "unverified", "transform", "python", "Distributed tuning", False),
    _t("promptfoo", "promptfoo", "K", "provisional", "check", "node", "Prompt eval + red-team", True),
    _t("braintrust", "Braintrust", "K", "unverified", "report", "node", "Eval platform", True),
    _t("langfuse", "Langfuse", "K", "provisional", "report", "python", "LLM observability", True),
    _t("phoenix", "Arize Phoenix", "K", "unverified", "report", "python", "LLM tracing", True),
    _t("opik", "Opik", "K", "unverified", "report", "python", "LLM eval/tracing", True),
    _t("deepeval", "DeepEval", "K", "provisional", "check", "python", "LLM unit tests", False),
    _t("ragas", "Ragas", "K", "provisional", "check", "python", "RAG evaluation", False),

    # ---- Group L: MCP native tools (14) --------------------------------------
    _t("mcp-python-sdk", "MCP Python SDK", "L", "verified", "mcp", "python", "Reference MCP SDK (Python)", True),
    _t("mcp-ts-sdk", "MCP TypeScript SDK", "L", "provisional", "mcp", "node", "Reference MCP SDK (TS)", True),
    _t("mcp-inspector", "MCP Inspector", "L", "provisional", "mcp", "node", "MCP debugging UI", True),
    _t("mcp-proxy", "mcp-proxy", "L", "provisional", "mcp", "python", "stdio<->SSE MCP bridge", True),
    _t("mcp-gateway", "mcp-gateway", "L", "provisional", "mcp", "node", "MCP multiplexer", True),
    _t("fastmcp", "FastMCP", "L", "provisional", "mcp", "python", "Ergonomic MCP server builder", True),
    _t("mcp-filesystem", "MCP Filesystem", "L", "verified", "mcp", "node", "Sandboxed file access", False),
    _t("mcp-git", "MCP Git", "L", "provisional", "mcp", "python", "Git operations over MCP", False),
    _t("mcp-github", "MCP GitHub", "L", "provisional", "mcp", "node", "GitHub API over MCP", True),
    _t("mcp-fetch", "MCP Fetch", "L", "provisional", "mcp", "python", "HTTP fetch over MCP", True),
    _t("mcp-memory", "MCP Memory", "L", "provisional", "mcp", "node", "Knowledge-graph memory", False),
    _t("mcp-think", "MCP Sequential Thinking", "L", "provisional", "mcp", "node", "Structured reasoning", False),
    _t("mcp-sqlite", "MCP SQLite", "L", "provisional", "mcp", "python", "SQL over MCP", False),
    _t("mcp-shell", "MCP Shell", "L", "quarantine", "mcp", "node", "Arbitrary shell (quarantined)", False),

    # ---- Group M: security native tools (24) ---------------------------------
    _t("gitleaks", "Gitleaks", "M", "verified", "scan", "system", "Secret scanning", False),
    _t("trufflehog", "TruffleHog", "M", "provisional", "scan", "system", "Secret scanning", True),
    _t("detect-secrets", "detect-secrets", "M", "verified", "scan", "python", "Secret detection", False),
    _t("trufflehog3", "trufflehog3", "M", "unverified", "scan", "python", "Secret scanning (py)", False),
    _t("snyk", "Snyk", "M", "unverified", "scan", "node", "Dependency/SAST scanning", True),
    _t("osv-scanner", "OSV-Scanner", "M", "provisional", "scan", "system", "OSV vuln lookup", True),
    _t("safety", "Safety", "M", "provisional", "scan", "python", "Python vuln check", True),
    _t("pip-audit", "pip-audit", "M", "verified", "scan", "python", "Python dep audit", True),
    _t("npm-audit", "npm audit", "M", "provisional", "scan", "node", "Node dep audit", True),
    _t("cargo-audit", "cargo audit", "M", "unverified", "scan", "system", "Rust dep audit", True),
    _t("govulncheck", "govulncheck", "M", "unverified", "scan", "system", "Go vuln check", True),
    _t("dependency-check", "OWASP Dependency-Check", "M", "unverified", "scan", "java", "SCA scanning", True),
    _t("checkov", "Checkov", "M", "provisional", "scan", "python", "IaC scanning", False),
    _t("tfsec", "tfsec", "M", "unverified", "scan", "system", "Terraform scanning", False),
    _t("kics", "KICS", "M", "unverified", "scan", "docker", "IaC scanning", False),
    _t("terrascan", "Terrascan", "M", "unverified", "scan", "system", "IaC scanning", False),
    _t("kube-bench", "kube-bench", "M", "unverified", "scan", "system", "CIS K8s benchmark", False),
    _t("kube-hunter", "kube-hunter", "M", "unverified", "scan", "python", "K8s pentest", True),
    _t("falco", "Falco", "M", "unverified", "scan", "system", "Runtime threat detection", False),
    _t("clair", "Clair", "M", "unverified", "scan", "docker", "Container vuln scanning", False),
    _t("anchore", "Anchore", "M", "unverified", "scan", "docker", "Container scanning", False),
    _t("hadolint", "Hadolint", "M", "provisional", "check", "system", "Dockerfile linter", False),
    _t("dockle", "Dockle", "M", "unverified", "scan", "system", "Container image lint", False),
    _t("lynis", "Lynis", "M", "unverified", "scan", "system", "System hardening audit", False),

    # ---- Group N: media native tools (24) ------------------------------------
    _t("imagemagick", "ImageMagick", "N", "provisional", "transform", "system", "Raster image processing", False),
    _t("graphicsmagick", "GraphicsMagick", "N", "unverified", "transform", "system", "Raster image processing", False),
    _t("sox", "SoX", "N", "unverified", "transform", "system", "Audio processing", False),
    _t("exiftool", "ExifTool", "N", "provisional", "report", "system", "Metadata read/write", False),
    _t("mediainfo", "MediaInfo", "N", "unverified", "report", "system", "Media metadata", False),
    _t("optipng", "OptiPNG", "N", "provisional", "transform", "system", "PNG optimisation", False),
    _t("pngquant", "pngquant", "N", "provisional", "transform", "system", "Lossy PNG compression", False),
    _t("jpegoptim", "jpegoptim", "N", "unverified", "transform", "system", "JPEG optimisation", False),
    _t("svgo", "SVGO", "N", "provisional", "transform", "node", "SVG optimisation", False),
    _t("cwebp", "cwebp", "N", "provisional", "transform", "system", "WebP encoding", False),
    _t("avifenc", "avifenc", "N", "unverified", "transform", "system", "AVIF encoding", False),
    _t("gifsicle", "gifsicle", "N", "unverified", "transform", "system", "GIF optimisation", False),
    _t("libvips", "libvips", "N", "provisional", "transform", "system", "Fast image processing", False),
    _t("potrace", "Potrace", "N", "unverified", "transform", "system", "Bitmap -> vector", False),
    _t("inkscape", "Inkscape", "N", "unverified", "transform", "system", "Vector editing", False),
    _t("rsvg-convert", "rsvg-convert", "N", "unverified", "transform", "system", "SVG -> raster", False),
    _t("ghostscript", "Ghostscript", "N", "provisional", "transform", "system", "PS/PDF processing", False),
    _t("qpdf", "qpdf", "N", "provisional", "transform", "system", "PDF transformation", False),
    _t("pdfcpu", "pdfcpu", "N", "unverified", "transform", "system", "PDF processing", False),
    _t("asciidoctor", "Asciidoctor", "N", "unverified", "transform", "system", "AsciiDoc rendering", False),
    _t("mermaid-cli", "Mermaid CLI", "N", "provisional", "transform", "node", "Diagram rendering", False),
    _t("plantuml", "PlantUML", "N", "provisional", "transform", "java", "UML rendering", False),
    _t("pandoc-media", "Pandoc (media)", "N", "verified", "transform", "system", "Doc -> PDF/HTML", False),
    _t("wkhtmltopdf", "wkhtmltopdf", "N", "provisional", "transform", "system", "HTML -> PDF", False),

    # ---- Group O: factory-pattern repos + native capability (39) -------------
    # Sealed / holdout / independent verification (the dark-factory pattern)
    _t("dark-factory", "dark-factory", "O", "provisional", "agent", "python", "Sealed/holdout factory: grader never sees the generator's spec", True),
    _t("dark-factory-ms", "dark-factory (michaellaws)", "O", "unverified", "agent", "python", "Sealed verification fork", True),
    _t("dark-factory-dubs", "dark-factory (DUBSOpenHub)", "O", "unverified", "agent", "python", "Sealed verification fork", True),
    _t("dark-factory-jlee", "dark-factory (jleechanorg)", "O", "unverified", "agent", "python", "Sealed verification fork", True),
    _t("dark-factory-peter", "dark-factory (peter-stratton)", "O", "unverified", "agent", "python", "Sealed verification fork", True),
    _t("sealed-verify", "Sealed Verify", "O", "verified", "check", "python", "L9: run a sealed holdout the generator never saw", False),
    _t("holdout-runner", "Holdout Runner", "O", "verified", "check", "python", "Derive + execute a deterministic sealed check set", False),
    _t("independent-verifier", "Independent Verifier", "O", "provisional", "check", "python", "Verify with a model class != generator", False),
    # Worktree isolation + deterministic verify
    _t("har", "har (os-factory)", "O", "provisional", "agent", "python", "Worktree isolation + deterministic verify", True),
    _t("agentree", "agentree", "O", "provisional", "agent", "node", "Per-agent worktree isolation", True),
    _t("factory-factory", "factory-factory", "O", "unverified", "agent", "python", "Factory that builds factories", True),
    _t("agent-worktree", "agent-worktree", "O", "provisional", "agent", "node", "Git-worktree isolation for agents", True),
    _t("git-worktree", "git worktree", "O", "verified", "sandbox", "git", "Native per-candidate worktree isolation (L10)", False),
    _t("worktree-isolate", "Worktree Isolate", "O", "verified", "sandbox", "python", "L10: private disposable workspace per candidate", False),
    # Clean / minimal / strong process control
    _t("super-simple-software-factory", "super-simple-software-factory", "O", "provisional", "agent", "python", "Minimal, legible factory with strong process control", True),
    _t("minimum-viable-factory", "minimum-viable-factory", "O", "unverified", "agent", "python", "Smallest factory that still ships", True),
    _t("addyosmani-factory", "addyosmani/factory", "O", "provisional", "agent", "node", "Clean factory reference implementation", True),
    _t("watt-mind-factory", "watt-mind/factory", "O", "unverified", "agent", "node", "Minimal factory reference", True),
    _t("forgeo", "forgeo", "O", "unverified", "agent", "node", "Opinionated build/forge pipeline", True),
    _t("process-minimalism", "Process Minimalism", "O", "provisional", "check", "python", "Reject process that does not change the artifact", False),
    # Other strong end-to-end factories
    _t("ai-software-factory", "ai-software-factory", "O", "provisional", "agent", "python", "End-to-end agentic software factory", True),
    _t("promtengineer-software-factory", "software-factory (PromtEngineer)", "O", "provisional", "agent", "python", "Reference end-to-end factory", True),
    _t("gastown", "gastown", "O", "unverified", "agent", "python", "Multi-stage town-scale factory", True),
    _t("gascity", "gascity", "O", "unverified", "agent", "python", "Multi-stage city-scale factory", True),
    _t("agentic-orchestrator", "agentic-orchestrator", "O", "provisional", "agent", "python", "Doordash OSS agentic orchestration", True),
    _t("claude-lane-stack", "claude-lane-stack", "O", "unverified", "agent", "node", "Lane-based agent build stack", True),
    _t("fabro", "fabro", "O", "unverified", "agent", "node", "Composable factory building blocks", True),
    _t("mastra-softwarefactory-template", "softwarefactory-template", "O", "provisional", "agent", "node", "Mastra factory template", True),
    _t("loki-mode", "loki-mode", "O", "unverified", "agent", "python", "Mode-switching agent factory", True),
    _t("codeaf", "CodeAF", "O", "provisional", "agent", "python", "Agent-Field code agent factory", True),
    _t("swe-af", "SWE-AF", "O", "provisional", "agent", "python", "Agent-Field SWE agent factory", True),
    # Native capability backing the new layers
    _t("deterministic-verify", "Deterministic Verify", "O", "verified", "check", "python", "Re-run gates and require identical verdicts", False),
    _t("spec-seal", "Spec Seal", "O", "verified", "transform", "python", "Hash + freeze the spec before generation", False),
    _t("candidate-isolator", "Candidate Isolator", "O", "verified", "sandbox", "python", "Guarantee no cross-candidate contamination", False),
    _t("gate-replay", "Gate Replay", "O", "verified", "check", "python", "Replay stored gate evidence to detect drift", False),
    _t("provenance-attest", "Provenance Attest", "O", "provisional", "sign", "python", "Attach build provenance to every artifact", False),
    _t("tier-enforcer", "Tier Enforcer", "O", "verified", "check", "python", "Block any non-VERIFIED tool from gating", False),
    _t("drift-detector", "Drift Detector", "O", "verified", "report", "python", "Compare registry claims against host reality", False),
    _t("keep-delete-planner", "Keep/Delete Planner", "O", "verified", "report", "python", "Classify repo paths into KEEP/DELETE/MIRROR/REWRITE", False),
]

assert len(TOOL_CATALOG) >= 200, "catalog must contain 200+ tools"
# ------------------------------------------------------------------------------
# 2. THE REPO CATALOG  (adopted repos + the start corpus; schema:
#    id, url, group, tier, purpose)
# ------------------------------------------------------------------------------

RepoTuple = Tuple[str, str, str, str, str]


def _r(i: str, url: str, g: str, tier: str, purpose: str) -> RepoTuple:
    return (i, url, g, tier, purpose)


REPO_CATALOG: List[RepoTuple] = [
    # core factories / reference corpus
    _r("awesome-software-factories", "https://github.com/varun1505/awesome-software-factories", "core", "verified", "Starting reference corpus for software-factory patterns"),
    _r("savage-tech-corner", "https://github.com/regularshowrigby8-create/SAVAGE-TECH-CORNER-", "core", "verified", "This repository: agents + prose, to be upgraded to machinery"),
    # app builders / IDE agents
    _r("bolt-diy", "https://github.com/stackblitz-labs/bolt.diy", "app-builder", "provisional", "Browser AI app builder"),
    _r("dyad", "https://github.com/dyad-sh/dyad", "app-builder", "provisional", "Local-first AI app builder"),
    _r("onlook", "https://github.com/onlook-dev/onlook", "app-builder", "unverified", "Visual editor that writes React"),
    _r("void", "https://github.com/voideditor/void", "app-builder", "provisional", "Open-source AI code editor"),
    _r("continue", "https://github.com/continuedev/continue", "app-builder", "provisional", "IDE assistant"),
    _r("cline", "https://github.com/cline/cline", "app-builder", "provisional", "Autonomous VS Code agent"),
    _r("roo-code", "https://github.com/RooCodeInc/Roo-Code", "app-builder", "provisional", "Multi-mode coding agent"),
    _r("tabby", "https://github.com/TabbyML/tabby", "app-builder", "unverified", "Self-hosted coding assistant"),
    # agent frameworks
    _r("openhands", "https://github.com/All-Hands-AI/OpenHands", "agent", "provisional", "Software-dev agent platform"),
    _r("gpt-pilot", "https://github.com/Pythagora-io/gpt-pilot", "agent", "unverified", "Multi-agent app generator"),
    _r("sweep", "https://github.com/sweepai/sweep", "agent", "unverified", "Issue-to-PR agent"),
    _r("pr-agent", "https://github.com/Codium-ai/pr-agent", "agent", "provisional", "PR review agent"),
    _r("aider", "https://github.com/Aider-AI/aider", "agent", "verified", "Repo-aware pair programmer"),
    _r("open-interpreter", "https://github.com/OpenInterpreter/open-interpreter", "agent", "provisional", "Natural-language code execution"),
    _r("gpt-engineer", "https://github.com/gpt-engineer-org/gpt-engineer", "agent", "provisional", "Spec-to-codebase generator"),
    _r("metagpt", "https://github.com/geekan/MetaGPT", "agent", "provisional", "Multi-agent software company"),
    _r("autogen", "https://github.com/microsoft/autogen", "agent", "provisional", "Conversable multi-agent framework"),
    _r("crewai", "https://github.com/crewAIInc/crewAI", "agent", "provisional", "Role-based agent crews"),
    _r("langgraph", "https://github.com/langchain-ai/langgraph", "agent", "verified", "Stateful agent graphs"),
    _r("swarm", "https://github.com/openai/swarm", "agent", "unverified", "Lightweight agent handoffs"),
    _r("camel", "https://github.com/camel-ai/camel", "agent", "unverified", "Communicative agent societies"),
    _r("agent-zero", "https://github.com/frdel/agent-zero", "agent", "unverified", "General autonomous agent"),
    _r("devika", "https://github.com/stitionai/devika", "agent", "unverified", "Agentic software engineer"),
    _r("smol-developer", "https://github.com/smol-ai/developer", "agent", "unverified", "Tiny codebase generator"),
    _r("potpie", "https://github.com/potpie-ai/potpie", "agent", "unverified", "Codebase knowledge graph"),
    _r("gpt-researcher", "https://github.com/assafelovic/gpt-researcher", "agent", "provisional", "Autonomous research agent"),
    _r("storm", "https://github.com/stanford-oval/storm", "agent", "unverified", "Wiki-article generation"),
    _r("khoj", "https://github.com/khoj-ai/khoj", "agent", "unverified", "Personal AI knowledge base"),
    _r("morphic", "https://github.com/miurla/morphic", "agent", "unverified", "AI answer engine UI"),
    _r("perplexica", "https://github.com/ItzCrazyKns/Perplexica", "agent", "unverified", "Open-source answer engine"),
    # build / dev tooling
    _r("repomix", "https://github.com/yamadashy/repomix", "tooling", "verified", "Pack repo into one LLM file"),
    _r("swe-agent", "https://github.com/princeton-nlp/SWE-agent", "tooling", "provisional", "SWE-bench issue fixer"),
    _r("codex-cli", "https://github.com/openai/codex", "tooling", "provisional", "Terminal coding agent"),
    _r("claude-code", "https://github.com/anthropics/claude-code", "tooling", "provisional", "Anthropic terminal agent"),
    _r("gemini-cli", "https://github.com/google-gemini/gemini-cli", "tooling", "provisional", "Google terminal agent"),
    _r("opencode", "https://github.com/sst/opencode", "tooling", "unverified", "Open terminal agent"),
    _r("goose", "https://github.com/block/goose", "tooling", "provisional", "Block local agent"),
    _r("sourcegraph-cody", "https://github.com/sourcegraph/cody", "tooling", "unverified", "Codebase-aware assistant"),
    # android / apk
    _r("jadx", "https://github.com/skylot/jadx", "android", "verified", "Dex -> Java decompiler"),
    _r("apktool", "https://github.com/iBotPeaches/Apktool", "android", "verified", "APK decode/rebuild"),
    _r("mobsf", "https://github.com/MobSF/Mobile-Security-Framework-MobSF", "android", "provisional", "Mobile security analysis"),
    _r("apkid", "https://github.com/rednaga/APKiD", "android", "verified", "Packer/obfuscator fingerprint"),
    _r("dex2jar", "https://github.com/pxb1988/dex2jar", "android", "verified", "Dex -> jar bridge"),
    _r("androguard", "https://github.com/androguard/androguard", "android", "verified", "Static APK analysis"),
    _r("frida", "https://github.com/frida/frida", "android", "provisional", "Dynamic instrumentation"),
    _r("objection", "https://github.com/sensepost/objection", "android", "provisional", "Frida-powered runtime"),
    _r("lief", "https://github.com/lief-project/LIEF", "android", "provisional", "Binary rewriting"),
    _r("ghidra", "https://github.com/NationalSecurityAgency/ghidra", "android", "provisional", "Reverse-engineering suite"),
    _r("radare2", "https://github.com/radareorg/radare2", "android", "provisional", "Binary analysis framework"),
    _r("apkleaks", "https://github.com/dwisiswant0/apkleaks", "android", "provisional", "Secret scanning in APKs"),
    _r("quark-engine", "https://github.com/quark-engine/quark-engine", "android", "provisional", "Malware scoring"),
    # technique libraries
    _r("dspy", "https://github.com/stanfordnlp/dspy", "technique", "provisional", "Programmatic prompt optimisation"),
    _r("textgrad", "https://github.com/zou-group/textgrad", "technique", "unverified", "Textual gradient optimisation"),
    _r("outlines", "https://github.com/dottxt-ai/outlines", "technique", "provisional", "Structured generation"),
    _r("guidance", "https://github.com/guidance-ai/guidance", "technique", "provisional", "Constrained generation DSL"),
    _r("lmql", "https://github.com/eth-sri/lmql", "technique", "unverified", "Query language for LLMs"),
    _r("instructor", "https://github.com/567-labs/instructor", "technique", "provisional", "Pydantic-validated outputs"),
    _r("vllm", "https://github.com/vllm-project/vllm", "technique", "provisional", "High-throughput serving"),
    _r("sglang", "https://github.com/sgl-project/sglang", "technique", "unverified", "Fast structured serving"),
    _r("llama-cpp", "https://github.com/ggerganov/llama.cpp", "technique", "verified", "Local CPU/GPU inference"),
    _r("ollama", "https://github.com/ollama/ollama", "technique", "verified", "Local model runtime"),
    # mcp
    _r("mcp-python-sdk", "https://github.com/modelcontextprotocol/python-sdk", "mcp", "verified", "Reference MCP SDK (Python)"),
    _r("mcp-servers", "https://github.com/modelcontextprotocol/servers", "mcp", "provisional", "Reference MCP servers"),
    _r("fastmcp", "https://github.com/jlowin/fastmcp", "mcp", "provisional", "Ergonomic MCP server builder"),
    _r("mcp-gateway", "https://github.com/IBM/mcp-context-forge", "mcp", "provisional", "MCP multiplexer/gateway"),
    # free endpoints / meta
    _r("free-llm-apis", "https://github.com/open-free-llm-api/awesome-freellm-apis", "endpoints", "provisional", "Catalog of free LLM endpoints"),
    _r("github-models", "https://github.com/marketplace/models", "endpoints", "verified", "Free GitHub Models inference"),
    _r("gpt4free-EXCLUDED", "https://github.com/xtekky/gpt4free", "excluded", "quarantine", "EXCLUDED: ToS violation, unstable, poisons evidence chain"),
    # ---- factory-patterns: sealed verification / worktree isolation / minimal ----
    # Sealed / holdout / independent verification (the dark-factory pattern)
    _r("dark-factory", "https://github.com/michaellaws/dark-factory", "factory-patterns", "provisional", "Sealed/holdout verification: the grader never sees the generator's spec"),
    _r("dark-factory-dubs", "https://github.com/DUBSOpenHub/dark-factory", "factory-patterns", "unverified", "Sealed verification fork"),
    _r("dark-factory-jlee", "https://github.com/jleechanorg/dark-factory", "factory-patterns", "unverified", "Sealed verification fork"),
    _r("dark-factory-peter", "https://github.com/peter-stratton/dark-factory", "factory-patterns", "unverified", "Sealed verification fork"),
    # Worktree isolation + deterministic verify
    _r("har", "https://github.com/os-factory/har", "factory-patterns", "provisional", "Worktree isolation + deterministic verify"),
    _r("agentree", "https://github.com/AryaLabsHQ/agentree", "factory-patterns", "provisional", "Per-agent git-worktree isolation"),
    _r("factory-factory", "https://github.com/purplefish-ai/factory-factory", "factory-patterns", "unverified", "A factory that builds factories"),
    _r("agent-worktree", "https://github.com/Boulea7/agent-worktree", "factory-patterns", "provisional", "Git-worktree isolation for agents"),
    # Clean / minimal / strong process control
    _r("super-simple-software-factory", "https://github.com/disler/super-simple-software-factory", "factory-patterns", "provisional", "Minimal, legible factory with strong process control"),
    _r("minimum-viable-factory", "https://github.com/ashtilawat/minimum-viable-factory", "factory-patterns", "unverified", "Smallest factory that still ships"),
    _r("addyosmani-factory", "https://github.com/addyosmani/factory", "factory-patterns", "provisional", "Clean factory reference implementation"),
    _r("watt-mind-factory", "https://github.com/watt-mind/factory", "factory-patterns", "unverified", "Minimal factory reference"),
    _r("forgeo", "https://github.com/lucaGazzola/forgeo", "factory-patterns", "unverified", "Opinionated build/forge pipeline"),
    # Other strong end-to-end factories
    _r("ai-software-factory", "https://github.com/coleam00/ai-software-factory", "factory-patterns", "provisional", "End-to-end agentic software factory"),
    _r("promtengineer-software-factory", "https://github.com/PromtEngineer/software-factory", "factory-patterns", "provisional", "Reference end-to-end factory"),
    _r("gastown", "https://github.com/gastownhall/gastown", "factory-patterns", "unverified", "Multi-stage town-scale factory"),
    _r("gascity", "https://github.com/gastownhall/gascity", "factory-patterns", "unverified", "Multi-stage city-scale factory"),
    _r("agentic-orchestrator", "https://github.com/doordash-oss/agentic-orchestrator", "factory-patterns", "provisional", "Doordash OSS agentic orchestration"),
    _r("claude-lane-stack", "https://github.com/VKirill/claude-lane-stack", "factory-patterns", "unverified", "Lane-based agent build stack"),
    _r("fabro", "https://github.com/fabro-sh/fabro", "factory-patterns", "unverified", "Composable factory building blocks"),
    _r("mastra-softwarefactory-template", "https://github.com/mastra-ai/softwarefactory-template", "factory-patterns", "provisional", "Mastra factory template"),
    _r("loki-mode", "https://github.com/asklokesh/loki-mode", "factory-patterns", "unverified", "Mode-switching agent factory"),
    _r("codeaf", "https://github.com/Agent-Field/CodeAF", "factory-patterns", "provisional", "Agent-Field code agent factory"),
    _r("swe-af", "https://github.com/Agent-Field/SWE-AF", "factory-patterns", "provisional", "Agent-Field SWE agent factory"),
]

# ------------------------------------------------------------------------------
# 3. THE MCP FLEET  (32 servers; schema: id, name, tier, exposes, purpose)
# ------------------------------------------------------------------------------

McpTuple = Tuple[str, str, str, str, str]


def _m(i: str, name: str, tier: str, exposes: str, purpose: str) -> McpTuple:
    return (i, name, tier, exposes, purpose)


MCP_FLEET: List[McpTuple] = [
    _m("gate", "Gate Server", "verified", "gate.run,gate.list", "Run deterministic gates; the only release gatekeeper"),
    _m("registry", "Registry Server", "verified", "registry.list,registry.get,registry.tier", "Serve the tool registry with tier enforcement"),
    _m("fs", "Filesystem Server", "verified", "fs.read,fs.write,fs.list,fs.stat", "Sandboxed file access rooted at the repo"),
    _m("exec", "Exec Server", "provisional", "exec.run,exec.which", "Run allow-listed commands with timeout"),
    _m("git", "Git Server", "provisional", "git.status,git.diff,git.log,git.branch", "Git operations over MCP"),
    _m("github", "GitHub Server", "provisional", "gh.repo,gh.pr,gh.issue,gh.release", "GitHub API over MCP"),
    _m("fetch", "Fetch Server", "provisional", "fetch.get,fetch.head", "HTTP fetch with size/redirect caps"),
    _m("memory", "Memory Server", "provisional", "mem.set,mem.get,mem.search", "Knowledge-graph memory for agents"),
    _m("think", "Sequential Thinking Server", "provisional", "think.step,think.reset", "Structured multi-step reasoning"),
    _m("sqlite", "SQLite Server", "provisional", "sql.query,sql.exec", "SQL over a local database"),
    _m("shell", "Shell Server", "quarantine", "shell.run", "Arbitrary shell (quarantined; never gates)"),
    _m("apk", "APK Server", "provisional", "apk.build,apk.sign,apk.verify,apk.manifest", "Drive the isolated APK-CLI cell"),
    _m("jadx", "jadx Server", "provisional", "jadx.decompile", "Decompile dex to Java"),
    _m("apktool", "apktool Server", "provisional", "apktool.decode,apktool.build", "Decode/rebuild APKs"),
    _m("mobsf", "MobSF Server", "provisional", "mobsf.scan", "Mobile security scan"),
    _m("llm", "LLM Server", "provisional", "llm.complete,llm.chat", "Provider-agnostic completion"),
    _m("router", "Router Server", "verified", "router.pick,router.class", "Stage -> model-class routing"),
    _m("spec", "Spec Server", "provisional", "spec.amplify", "L1 spec amplification"),
    _m("scaffold", "Scaffold Server", "provisional", "scaffold.select", "L2 scaffold selection"),
    _m("sampler", "Sampler Server", "provisional", "sample.best_of_n", "L3 best-of-N sampling"),
    _m("verifier", "Verifier Server", "provisional", "verify.rank,verify.ensemble", "L4 adversarial verification"),
    _m("repair", "Repair Server", "provisional", "repair.until_green", "L5 self-repair loop"),
    _m("decode", "Decode Server", "provisional", "decode.grammar,decode.json", "L6 constrained decoding"),
    _m("retrieve", "Retrieve Server", "provisional", "retrieve.golden", "L7 golden-example retrieval"),
    _m("gates", "Gates Server", "verified", "gates.run_all", "L8 deterministic gates"),
    _m("cleaner", "Cleaner Server", "provisional", "cleaner.plan,cleaner.apply", "Destructive maintenance (dry-run first)"),
    _m("improver", "Improver Server", "provisional", "improver.cycle,improver.bench", "24/7 self-improvement"),
    _m("queue", "Queue Server", "provisional", "queue.push,queue.pop,queue.ack", "Durable job queue"),
    _m("policy", "Policy Server", "verified", "policy.check,policy.route", "Tier + routing policy"),
    _m("sbom", "SBOM Server", "provisional", "sbom.gen,sbom.scan", "SBOM generation + vuln scan"),
    _m("secrets", "Secrets Server", "verified", "secrets.scan", "Secret scanning (UTF-16LE aware)"),
    _m("docs", "Docs Server", "provisional", "docs.render,docs.index", "Render + index docs"),
]

# ------------------------------------------------------------------------------
# 4. PER-FACTORY RULES  (one ruleset per stage; machine-readable)
# ------------------------------------------------------------------------------

RULES: Dict[str, Dict[str, Any]] = {
    "intake": {
        "stage": "intake",
        "model_class": "none",
        "purpose": "Normalise any input (prompt, repo, doc, apk, url) into a canonical Job.",
        "entry_tools": ["pandoc", "pdftotext", "markitdown", "repomix", "beautifulsoup"],
        "inputs": ["prompt", "path", "url", "apk"],
        "outputs": ["job.json"],
        "invariants": [
            "Every Job carries a content hash of its inputs.",
            "No network unless the source is a URL.",
            "Inputs are copied into a read-only intake cell; originals never mutated.",
        ],
        "gate": ["job.json is valid JSON", "job.input_hash is present"],
    },
    "spec": {
        "stage": "spec",
        "model_class": "premium",
        "purpose": "Amplify a one-line prompt into a typed, testable spec (L1).",
        "entry_tools": ["dspy", "instructor", "outlines", "pydantic"],
        "inputs": ["job.json"],
        "outputs": ["spec.json"],
        "invariants": [
            "Spec MUST include: goal, non_goals, acceptance_tests[], interfaces[], data_model, risks[].",
            "Every acceptance test must be machine-checkable (a command or a predicate).",
            "If the model returns prose, the harness re-asks with a JSON grammar (L6).",
        ],
        "gate": ["spec.json validates against SPEC_SCHEMA", "len(acceptance_tests) >= 3"],
    },
    "build": {
        "stage": "build",
        "model_class": "cheap",
        "purpose": "Generate N candidate implementations from the spec (L2/L3/L7).",
        "entry_tools": ["aider", "gpt-engineer", "scaffold", "sampler", "retrieve"],
        "inputs": ["spec.json", "scaffold"],
        "outputs": ["candidates/*"],
        "invariants": [
            "Candidates are generated in isolated worktrees; no cross-contamination.",
            "Each candidate is paired with its diff and a deterministic build log.",
            "N defaults to 8; budget_rounds defaults to 4.",
        ],
        "gate": ["at least one candidate compiles", "each candidate has a diff"],
    },
    "verify": {
        "stage": "verify",
        "model_class": "premium",
        "purpose": "Adversarially verify candidates with a DIFFERENT model + deterministic gates (L4/L8).",
        "entry_tools": ["verifier", "gates", "pytest", "coverage", "mutmut", "bandit"],
        "inputs": ["candidates/*", "spec.json"],
        "outputs": ["verdict.json"],
        "invariants": [
            "The verifying model MUST differ from the generating model.",
            "A candidate is SHIP-eligible only if ALL deterministic gates pass.",
            "Hollow checks (return True / NotImplementedError / pass-only) are rejected.",
            "Binary scans are UTF-16LE aware.",
        ],
        "gate": ["verdict.json present", "no candidate marked PASS without gate evidence"],
    },
    "package": {
        "stage": "package",
        "model_class": "none",
        "purpose": "Reproducibly package the verified artifact + SBOM + provenance.",
        "entry_tools": ["docker", "syft", "trivy", "cyclonedx", "zipalign", "apksigner"],
        "inputs": ["verdict.json", "candidates/*"],
        "outputs": ["dist/*", "sbom.json", "provenance.json"],
        "invariants": [
            "Packaging is deterministic (pinned toolchain, pinned deps).",
            "Every artifact ships with an SBOM and a provenance attestation.",
        ],
        "gate": ["artifact exists", "sbom.json exists", "provenance.json exists"],
    },
    "ship": {
        "stage": "ship",
        "model_class": "none",
        "purpose": "Emit a release ONLY if the verdict is SHIP and all gates are green.",
        "entry_tools": ["gh-release", "cosign", "slsa-verifier"],
        "inputs": ["verdict.json", "dist/*"],
        "outputs": ["release.json"],
        "invariants": [
            "Only VERIFIED tools may gate a release.",
            "No release without a green verdict.json.",
            "The release manifest references literal artifact paths + hashes.",
        ],
        "gate": ["verdict == SHIP", "release.json references real files"],
    },
    "improve": {
        "stage": "improve",
        "model_class": "cheap",
        "purpose": "Continuously benchmark tools, promote/demote tiers, run fault drills.",
        "entry_tools": ["promptfoo", "deepeval", "ragas", "langfuse", "optuna"],
        "inputs": ["registry", "telemetry"],
        "outputs": ["improve_report.json"],
        "invariants": [
            "Tier changes require a benchmark delta, not vibes.",
            "Demotion is automatic on gate failure; promotion requires evidence.",
            "Fault-injection drills must be reversible.",
        ],
        "gate": ["improve_report.json present", "no tool promoted without a delta"],
    },
}

# ------------------------------------------------------------------------------
# 5. FREE ENDPOINTS  (OpenAI-compatible; schema: id, base_url, env_key,
#    default_model, class, notes)
# ------------------------------------------------------------------------------

EndpointTuple = Tuple[str, str, str, str, str, str]


def _e(i: str, base: str, env: str, model: str, cls: str, notes: str) -> EndpointTuple:
    return (i, base, env, model, cls, notes)


ENDPOINTS: List[EndpointTuple] = [
    _e("github-models", "https://models.github.ai/inference", "GITHUB_TOKEN", "openai/gpt-4o-mini", "premium", "Free with a GitHub token; strong verifier"),
    _e("groq", "https://api.groq.com/openai/v1", "GROQ_API_KEY", "llama-3.3-70b-versatile", "premium", "Fast; good verifier"),
    _e("cerebras", "https://api.cerebras.ai/v1", "CEREBRAS_API_KEY", "llama3.1-70b", "premium", "Very fast"),
    _e("gemini", "https://generativelanguage.googleapis.com/v1beta/openai", "GEMINI_API_KEY", "gemini-1.5-flash", "premium", "Free tier via AI Studio"),
    _e("deepseek", "https://api.deepseek.com/v1", "DEEPSEEK_API_KEY", "deepseek-chat", "cheap", "Strong cheap coder"),
    _e("openrouter", "https://openrouter.ai/api/v1", "OPENROUTER_API_KEY", "meta-llama/llama-3.1-8b-instruct:free", "cheap", "Has :free variants"),
    _e("mistral", "https://api.mistral.ai/v1", "MISTRAL_API_KEY", "open-mistral-nemo", "cheap", "Free tier"),
    _e("together", "https://api.together.xyz/v1", "TOGETHER_API_KEY", "meta-llama/Llama-3.3-70B-Instruct-Turbo-Free", "premium", "Free model available"),
    _e("ollama", "http://localhost:11434/v1", "OLLAMA_HOST", "qwen2.5-coder:7b", "cheap", "Local; offline capable"),
    _e("lmstudio", "http://localhost:1234/v1", "LMSTUDIO_HOST", "local-model", "cheap", "Local OpenAI-compatible"),
    _e("vllm", "http://localhost:8000/v1", "VLLM_HOST", "local-model", "cheap", "Local high-throughput"),
    _e("llamacpp", "http://localhost:8080/v1", "LLAMACPP_HOST", "local-model", "cheap", "Local llama.cpp server"),
]

# ------------------------------------------------------------------------------
# 6. THE PREMIUM HARNESS — 8 LAYERS (metadata; code lives in savage/premium/*)
# ------------------------------------------------------------------------------

LAYERS: List[Tuple[str, str, str]] = [
    ("L1", "Spec Amplifier", "Turn a one-liner into a typed, testable spec."),
    ("L2", "Scaffold Selector", "Pick the right project skeleton for the spec."),
    ("L3", "Best-of-N Sampler", "Generate N candidates; keep the best."),
    ("L4", "Verifier / Ensemble", "Adversarially verify with a different model."),
    ("L5", "Self-Repair Loop", "Feed gate failures back and repair until green."),
    ("L6", "Constrained Decoding", "Force valid JSON/GBNF so the model cannot ramble."),
    ("L7", "Golden Retrieval", "Retrieve proven examples before generating."),
    ("L8", "Deterministic Gates", "The only thing allowed to certify a release."),
    ("L9", "Sealed Holdout", "Re-verify against a sealed check set the generator never saw."),
    ("L10", "Worktree Isolation", "Every candidate gets a private, disposable workspace."),
]

# ------------------------------------------------------------------------------
# 7. SPEC SCHEMA (the contract every spec must satisfy)
# ------------------------------------------------------------------------------

SPEC_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "required": ["goal", "non_goals", "acceptance_tests", "interfaces", "data_model", "risks"],
    "properties": {
        "goal": {"type": "string", "minLength": 8},
        "non_goals": {"type": "array", "items": {"type": "string"}, "minItems": 1},
        "acceptance_tests": {
            "type": "array",
            "minItems": 3,
            "items": {
                "type": "object",
                "required": ["name", "check"],
                "properties": {
                    "name": {"type": "string"},
                    "check": {"type": "string"},
                },
            },
        },
        "interfaces": {"type": "array", "items": {"type": "string"}},
        "data_model": {"type": "string"},
        "risks": {"type": "array", "items": {"type": "string"}},
    },
}

# ------------------------------------------------------------------------------
# 8. GBNF GRAMMAR (L6) — forces the spec model to emit valid JSON
# ------------------------------------------------------------------------------

SPEC_GBNF = r'''
root   ::= object
object ::= "{" ws pair (ws "," ws pair)* ws "}" | "{" ws "}"
pair   ::= string ws ":" ws value
value  ::= string | number | object | array | "true" | "false" | "null"
array  ::= "[" ws (value (ws "," ws value)*)? ws "]"
string ::= "\"" ( [^"\\] | "\\" ["\\/bfnrt] )* "\""
number ::= "-"? ("0" | [1-9] [0-9]*) ("." [0-9]+)? ([eE] [-+]? [0-9]+)?
ws     ::= [ \t\n\r]*
'''
# ==============================================================================
# 9. THE EMBEDDED FILE BUNDLE  (base64)
# ------------------------------------------------------------------------------
# The entire factory source tree is stored below as one base64 blob.  It is
# decoded once at import time into the string `_BUNDLE`, then split on the
# `#@@FILE:<path>@@` markers by `parse_bundle()`.  Base64 is used so the
# embedded source may contain any quote characters without ever colliding
# with the outer literal.  41 files, 96950 bytes of source.
# ==============================================================================

_BUNDLE_B64 = (
    'I0BARklMRTpmYWN0b3J5L19faW5pdF9fLnB5QEAKIiIiVGhlIGZhY3RvcnkgbWFjaGluZXJ5OiBtYW5hZ2VyLCBzcGFjZXMsIGNs'
    'ZWFuZXIsIGltcHJvdmVyLiIiIgpfX3ZlcnNpb25fXyA9ICIzLjAuMCIKI0BARklMRTpmYWN0b3J5L2Fkb3B0L19faW5pdF9fLnB5'
    'QEAKIiIiVGhlIEFkb3B0ZXIgc3BhY2U6IGFuYWx5c2UgYW4gZXhpc3RpbmcgcmVwbyBhbmQgcHJvZHVjZSBhIEtFRVAvREVMRVRF'
    'IHBsYW4uIiIiCmZyb20gLiBpbXBvcnQgYWRvcHQKCl9fYWxsX18gPSBbImFkb3B0Il0KI0BARklMRTpmYWN0b3J5L2Fkb3B0L2Fk'
    'b3B0LnB5QEAKIiIiVGhlIEFkb3B0ZXIgLSBhbmFseXNlIGFuIGV4aXN0aW5nIHJlcG9zaXRvcnkgYW5kIHByb2R1Y2UgYSBLRUVQ'
    'L0RFTEVURSBwbGFuLgoKVGhpcyBpcyB0aGUgYW5zd2VyIHRvICJ3aGF0IGRvZXMgdGhlIGZhY3RvcnkgZGVsZXRlIGFuZCB3aGF0'
    'IGRvZXMgaXQga2VlcD8iLgpJdCBpcyBkcnktcnVuIGZpcnN0IGFuZCBORVZFUiBkZWxldGVzIGFueXRoaW5nIHVubGVzcyBgYGFw'
    'cGx5PVRydWVgYC4gIFRoZSBwbGFuCmlzIGEgcGxhaW4sIGF1ZGl0YWJsZSBtYW5pZmVzdCAoYGBBRE9QVC5tZGBgICsgYGBhZG9w'
    'dF9wbGFuLmpzb25gYCkgc28gYSBsb3ctZW5kCm1vZGVsIGNhbiByZWFkIGV4YWN0bHkgd2hhdCB3aWxsIGhhcHBlbiAqYmVmb3Jl'
    'KiBpdCBoYXBwZW5zLgoKQ2F0ZWdvcmllcwotLS0tLS0tLS0tCktFRVAgICAgIC0gbmV2ZXIgdG91Y2hlZCAoVkNTLCBkb2NzLCB0'
    'aGUgZmFjdG9yeSBpdHNlbGYsIGxpY2Vuc2VzKS4KREVMRVRFICAgLSBzYWZlIHRvIHJlbW92ZSAoY2FjaGVzLCBieXRlY29kZSwg'
    'dmVuZG9yZWQgZGVwcywgZWRpdG9yIGp1bmspLgpNSVJST1IgICAtIGEgZHVwbGljYXRlIHRyZWUgdGhhdCBzaGFkb3dzIGEga2Vw'
    'dCBvbmU7IG5lZWRzIGV4cGxpY2l0IGNvbmZpcm1hdGlvbi4KUkVXUklURSAgLSBwcmVzZW50IGJ1dCBtdXN0IGJlIHJld3JpdHRl'
    'biAoaG9sbG93IENJIGdhdGVzKS4KVU5LTk9XTiAgLSBsZWZ0IGNvbXBsZXRlbHkgYWxvbmU7IHRoZSBtb2RlbCBkZWNpZGVzLgoi'
    'IiIKZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGZubWF0Y2gKaW1wb3J0IGZpbGVjbXAKaW1wb3J0'
    'IHN1YnByb2Nlc3MKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCByZQppbXBvcnQgc2h1dGlsCmZyb20gcGF0aGxpYiBpbXBv'
    'cnQgUGF0aApmcm9tIHR5cGluZyBpbXBvcnQgRGljdCwgTGlzdAoKS0VFUF9QQVRURVJOUyA9IFsKICAgICIuZ2l0LyoqIiwgIi5n'
    'aXRpZ25vcmUiLCAiLmdpdGF0dHJpYnV0ZXMiLCAiLmdpdG1vZHVsZXMiLAogICAgIlJFQURNRSoiLCAiTElDRU5TRSoiLCAiQ0hB'
    'TkdFTE9HKiIsICJDT05UUklCVVRJTkcqIiwgIkNPREVfT0ZfQ09ORFVDVCoiLAogICAgIlNBVkFHRV9GQUNUT1JZLnB5IiwgInNh'
    'dmFnZS8qKiIsICJmYWN0b3J5LyoqIiwgImRvY3MvKioiLCAidG9vbHMvKioiLAogICAgIi5naXRodWIvd29ya2Zsb3dzL3NhdmFn'
    'ZS1mYWN0b3J5LWdhdGUueW1sIiwKICAgICIuZ2l0aHViL3dvcmtmbG93cy9hcGstY2xpLnltbCIsCiAgICAiLmdpdGh1Yi93b3Jr'
    'Zmxvd3MvY2xlYW5lci55bWwiLAogICAgIi5naXRodWIvd29ya2Zsb3dzL2ltcHJvdmVyLnltbCIsCl0KCkRFTEVURV9QQVRURVJO'
    'UyA9IFsKICAgICMgYnl0ZWNvZGUgKyBjYWNoZXMKICAgICIqKi9fX3B5Y2FjaGVfXy8qKiIsICIqKi9fX3B5Y2FjaGVfXyIsICIq'
    'Ki8qLnB5YyIsICIqKi8qLnB5byIsICIqKi8qLnB5ZCIsCiAgICAiKiovLnB5dGVzdF9jYWNoZS8qKiIsICIqKi8ubXlweV9jYWNo'
    'ZS8qKiIsICIqKi8ucnVmZl9jYWNoZS8qKiIsCiAgICAiKiovLnRveC8qKiIsICIqKi8uaXB5bmJfY2hlY2twb2ludHMvKioiLCAi'
    'LnNhdmFnZS9jYWNoZS8qKiIsCiAgICAiKiovLmNhY2hlLyoqIiwKICAgICMgdmVuZG9yZWQgZGVwcyArIGJ1aWxkIG91dHB1dAog'
    'ICAgIioqL25vZGVfbW9kdWxlcy8qKiIsICIqKi8ubmV4dC8qKiIsICIqKi9kaXN0LyoqIiwgIioqL2J1aWxkLyoqIiwKICAgICIq'
    'Ki8qLmVnZy1pbmZvLyoqIiwgIioqLy5lZ2dzLyoqIiwKICAgICMgT1MgKyBlZGl0b3IgKyBsb2cganVuawogICAgIioqLy5EU19T'
    'dG9yZSIsICIqKi9UaHVtYnMuZGIiLCAiKiovKi5sb2ciLCAiKiovKi50bXAiLCAiKiovKi5iYWsiLAogICAgIioqLyoub3JpZyIs'
    'Cl0KCiMgRHVwbGljYXRlIG1pcnJvciB0cmVlczogdGhlIGNsYXNzaWMgYGZhY3RvcnktMmAgdnMgYGZhY3Rvcmllcy9mYWN0b3J5'
    'LTJgIHByb2JsZW0uCk1JUlJPUl9QQUlSUyA9IFsoImZhY3RvcnktMiIsICJmYWN0b3JpZXMvZmFjdG9yeS0yIiksCiAgICAgICAg'
    'ICAgICAgICAoImZhY3RvcnktMyIsICJmYWN0b3JpZXMvZmFjdG9yeS0zIildCgpSRVdSSVRFX1BBVFRFUk5TID0gWyIuZ2l0aHVi'
    'L3dvcmtmbG93cy8qLnltbCIsICIuZ2l0aHViL3dvcmtmbG93cy8qLnlhbWwiXQoKIyBTdWJzdHJpbmdzIHRoYXQgbWFyayBhIENJ'
    'IHdvcmtmbG93IGFzIGEgKmhvbGxvdyogZ2F0ZSAoaXQgY2FuIG5ldmVyIGZhaWwpLgpIT0xMT1dfQ0kgPSAoImNvbnRpbnVlLW9u'
    'LWVycm9yOiB0cnVlIiwgInx8IHRydWUiLCAifHwgZXhpdCAwIikKCgpkZWYgX21hdGNoKHJlbDogc3RyLCBwYXQ6IHN0cikgLT4g'
    'Ym9vbDoKICAgICIiIkdsb2IgbWF0Y2ggd2l0aCBgYCoqYGAgc3VwcG9ydCAoZm5tYXRjaCBhbG9uZSBkb2VzIG5vdCBkbyBnbG9i'
    'c3RhcikuCgogICAgUnVsZXM6CiAgICAgICogYSBiYXJlIHBhdHRlcm4gd2l0aCBubyBgYC9gYCAoZS5nLiBgYCoucHljYGAsIGBg'
    'UkVBRE1FKmBgKSBtYXRjaGVzIHRoZQogICAgICAgIGJhc2VuYW1lIGF0IGFueSBkZXB0aCwgaW5jbHVkaW5nIHRoZSByZXBvIHJv'
    'b3Q7CiAgICAgICogYGAqKi9gYCBpcyBzdHJpcHBlZCAoaXQgbWVhbnMgImF0IGFueSBkZXB0aCIpOwogICAgICAqIGBgZGlyLyoq'
    'YGAgbWF0Y2hlcyBldmVyeXRoaW5nIHVuZGVyIGBgZGlyYGAgKGBgZGlyYGAgbWF5IGJlIGEgZ2xvYiBzdWNoCiAgICAgICAgYXMg'
    'YGAqLmVnZy1pbmZvYGAgYW5kIG1heSBpdHNlbGYgY29udGFpbiBgYC9gYCk7CiAgICAgICogYW55dGhpbmcgZWxzZSBpcyBhIHN1'
    'ZmZpeCAvIGRpcmVjdCBnbG9iIG1hdGNoLgogICAgIiIiCiAgICByZWwgPSByZWwucmVwbGFjZShvcy5zZXAsICIvIikKICAgIG5h'
    'bWUgPSByZWwucnNwbGl0KCIvIiwgMSlbLTFdCiAgICBpZiBwYXQuc3RhcnRzd2l0aCgiKiovIik6CiAgICAgICAgcGF0ID0gcGF0'
    'WzM6XQogICAgaWYgIi8iIG5vdCBpbiBwYXQ6CiAgICAgICAgcmV0dXJuIGZubWF0Y2guZm5tYXRjaChuYW1lLCBwYXQpCiAgICBp'
    'ZiBwYXQuZW5kc3dpdGgoIi8qKiIpOgogICAgICAgIGJhc2UgPSBwYXRbOi0zXQogICAgICAgIGlmICIvIiBpbiBiYXNlOgogICAg'
    'ICAgICAgICByZXR1cm4gKHJlbCA9PSBiYXNlIG9yIHJlbC5zdGFydHN3aXRoKGJhc2UgKyAiLyIpCiAgICAgICAgICAgICAgICAg'
    'ICAgb3IgKCIvIiArIHJlbCkuZmluZCgiLyIgKyBiYXNlICsgIi8iKSAhPSAtMSkKICAgICAgICByZXR1cm4gYW55KGZubWF0Y2gu'
    'Zm5tYXRjaChzZWcsIGJhc2UpIGZvciBzZWcgaW4gcmVsLnNwbGl0KCIvIilbOi0xXSkKICAgIHJldHVybiByZWwgPT0gcGF0IG9y'
    'IHJlbC5lbmRzd2l0aCgiLyIgKyBwYXQpIG9yIGZubWF0Y2guZm5tYXRjaChyZWwsIHBhdCkKCgpkZWYgX2NsYXNzaWZ5KHJlbDog'
    'c3RyKSAtPiBzdHI6CiAgICAjIERFTEVURSBpcyBldmFsdWF0ZWQgZmlyc3Q6IGNhY2hlcyBhbmQganVuayBhcmUgYWx3YXlzIGNs'
    'ZWFuZWQsIGV2ZW4gd2hlbgogICAgIyB0aGV5IGxpdmUgaW5zaWRlIGEga2VwdCB0cmVlIChlLmcuIHNhdmFnZS9fX3B5Y2FjaGVf'
    'Xy94LnB5YykuICBLRUVQIHRoZW4KICAgICMgcHJvdGVjdHMgcmVhbCBzb3VyY2UvZG9jcy9WQ1M7IFJFV1JJVEUgZmxhZ3MgaG9s'
    'bG93IENJOyB0aGUgcmVzdCBpcyBVTktOT1dOLgogICAgZm9yIHBhdCBpbiBERUxFVEVfUEFUVEVSTlM6CiAgICAgICAgaWYgX21h'
    'dGNoKHJlbCwgcGF0KToKICAgICAgICAgICAgcmV0dXJuICJERUxFVEUiCiAgICBmb3IgcGF0IGluIEtFRVBfUEFUVEVSTlM6CiAg'
    'ICAgICAgaWYgX21hdGNoKHJlbCwgcGF0KToKICAgICAgICAgICAgcmV0dXJuICJLRUVQIgogICAgZm9yIHBhdCBpbiBSRVdSSVRF'
    'X1BBVFRFUk5TOgogICAgICAgIGlmIF9tYXRjaChyZWwsIHBhdCk6CiAgICAgICAgICAgIHJldHVybiAiUkVXUklURSIKICAgIHJl'
    'dHVybiAiVU5LTk9XTiIKCgpkZWYgX3NhbWVfdHJlZShhOiBQYXRoLCBiOiBQYXRoKSAtPiBib29sOgogICAgIiIiUmV0dXJuIHRy'
    'dWUgb25seSB3aGVuIGJvdGggZGlyZWN0b3J5IHRyZWVzIGhhdmUgaWRlbnRpY2FsIGZpbGVzIGFuZCBieXRlcy4iIiIKICAgIHRy'
    'eToKICAgICAgICBsZWZ0ID0ge3N0cih4LnJlbGF0aXZlX3RvKGEpKTogeCBmb3IgeCBpbiBhLnJnbG9iKCIqIikgaWYgeC5pc19m'
    'aWxlKCl9CiAgICAgICAgcmlnaHQgPSB7c3RyKHgucmVsYXRpdmVfdG8oYikpOiB4IGZvciB4IGluIGIucmdsb2IoIioiKSBpZiB4'
    'LmlzX2ZpbGUoKX0KICAgICAgICBpZiBzZXQobGVmdCkgIT0gc2V0KHJpZ2h0KToKICAgICAgICAgICAgcmV0dXJuIEZhbHNlCiAg'
    'ICAgICAgcmV0dXJuIGFsbCh4LnJlYWRfYnl0ZXMoKSA9PSByaWdodFtyZWxdLnJlYWRfYnl0ZXMoKSBmb3IgcmVsLCB4IGluIGxl'
    'ZnQuaXRlbXMoKSkKICAgIGV4Y2VwdCAoT1NFcnJvciwgVmFsdWVFcnJvcik6CiAgICAgICAgcmV0dXJuIEZhbHNlCgoKZGVmIF9k'
    'aXJfc2l6ZShwOiBQYXRoKSAtPiBpbnQ6CiAgICBpZiBwLmlzX2ZpbGUoKToKICAgICAgICB0cnk6CiAgICAgICAgICAgIHJldHVy'
    'biBwLnN0YXQoKS5zdF9zaXplCiAgICAgICAgZXhjZXB0IEV4Y2VwdGlvbjoKICAgICAgICAgICAgcmV0dXJuIDAKICAgIHRvdGFs'
    'ID0gMAogICAgZm9yIHJvb3QsIF8sIGZpbGVzIGluIG9zLndhbGsocCk6CiAgICAgICAgZm9yIGYgaW4gZmlsZXM6CiAgICAgICAg'
    'ICAgIHRyeToKICAgICAgICAgICAgICAgIHRvdGFsICs9IChQYXRoKHJvb3QpIC8gZikuc3RhdCgpLnN0X3NpemUKICAgICAgICAg'
    'ICAgZXhjZXB0IEV4Y2VwdGlvbjoKICAgICAgICAgICAgICAgIHBhc3MKICAgIHJldHVybiB0b3RhbAoKCmRlZiBfaG9sbG93X2Np'
    'KHBhdGg6IFBhdGgpIC0+IExpc3Rbc3RyXToKICAgIHRyeToKICAgICAgICB0ZXh0ID0gcGF0aC5yZWFkX3RleHQoZXJyb3JzPSJp'
    'Z25vcmUiKQogICAgZXhjZXB0IEV4Y2VwdGlvbjoKICAgICAgICByZXR1cm4gW10KICAgIHJldHVybiBbaCBmb3IgaCBpbiBIT0xM'
    'T1dfQ0kgaWYgaCBpbiB0ZXh0XQoKCmRlZiBzY2FuKHJvb3Q6IHN0cikgLT4gRGljdFtzdHIsIExpc3RbZGljdF1dOgogICAgIiIi'
    'V2FsayB0aGUgcmVwbyBhbmQgY2xhc3NpZnkgZXZlcnkgcGF0aC4gIFJlYWQtb25seS4iIiIKICAgIHJvb3QgPSBQYXRoKHJvb3Qp'
    'CiAgICBidWNrZXRzOiBEaWN0W3N0ciwgTGlzdFtkaWN0XV0gPSB7IktFRVAiOiBbXSwgIkRFTEVURSI6IFtdLCAiTUlSUk9SIjog'
    'W10sCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIlJFV1JJVEUiOiBbXSwgIlVOS05PV04iOiBbXX0KICAg'
    'IHNlZW5fZGlyczogc2V0ID0gc2V0KCkKICAgIGZvciBkaXJwYXRoLCBkaXJzLCBmaWxlcyBpbiBvcy53YWxrKHJvb3QpOgogICAg'
    'ICAgIGRpcnNbOl0gPSBbZCBmb3IgZCBpbiBkaXJzIGlmIGQgIT0gIi5naXQiIG9yIGRpcnBhdGggPT0gc3RyKHJvb3QpXQogICAg'
    'ICAgIGZvciBuYW1lIGluIGZpbGVzOgogICAgICAgICAgICBwID0gUGF0aChkaXJwYXRoKSAvIG5hbWUKICAgICAgICAgICAgcmVs'
    'ID0gc3RyKHAucmVsYXRpdmVfdG8ocm9vdCkpLnJlcGxhY2Uob3Muc2VwLCAiLyIpCiAgICAgICAgICAgIGNhdCA9IF9jbGFzc2lm'
    'eShyZWwpCiAgICAgICAgICAgIGVudHJ5ID0geyJwYXRoIjogcmVsLCAiYnl0ZXMiOiBfZGlyX3NpemUocCksICJjYXRlZ29yeSI6'
    'IGNhdH0KICAgICAgICAgICAgaWYgY2F0ID09ICJSRVdSSVRFIjoKICAgICAgICAgICAgICAgIGhpdHMgPSBfaG9sbG93X2NpKHAp'
    'CiAgICAgICAgICAgICAgICBpZiBoaXRzOgogICAgICAgICAgICAgICAgICAgIGVudHJ5WyJyZWFzb24iXSA9ICJob2xsb3cgQ0kg'
    'Z2F0ZTogIiArICIsICIuam9pbihoaXRzKQogICAgICAgICAgICAgICAgZWxzZToKICAgICAgICAgICAgICAgICAgICBlbnRyeVsi'
    'Y2F0ZWdvcnkiXSA9ICJVTktOT1dOIgogICAgICAgICAgICBidWNrZXRzW2VudHJ5WyJjYXRlZ29yeSJdXS5hcHBlbmQoZW50cnkp'
    'CiAgICAgICAgc2Vlbl9kaXJzLmFkZChkaXJwYXRoKQoKICAgICMgZHVwbGljYXRlIG1pcnJvciB0cmVlcwogICAgZm9yIGEsIGIg'
    'aW4gTUlSUk9SX1BBSVJTOgogICAgICAgIHBhLCBwYiA9IHJvb3QgLyBhLCByb290IC8gYgogICAgICAgIGlmIHBhLmlzX2Rpcigp'
    'IGFuZCBwYi5pc19kaXIoKToKICAgICAgICAgICAgaWYgX3NhbWVfdHJlZShwYSwgcGIpOgogICAgICAgICAgICAgICAgYnVja2V0'
    'c1siTUlSUk9SIl0uYXBwZW5kKHsKICAgICAgICAgICAgICAgICAgICAicGF0aCI6IGEsICJieXRlcyI6IF9kaXJfc2l6ZShwYSks'
    'ICJjYXRlZ29yeSI6ICJNSVJST1IiLAogICAgICAgICAgICAgICAgICAgICJyZWFzb24iOiAiYnl0ZS1pZGVudGljYWwgZHVwbGlj'
    'YXRlIG9mICIgKyBiICsgIiAoa2VlcCAiICsgYiArICIpIiwKICAgICAgICAgICAgICAgICAgICAia2VlcCI6IGIsCiAgICAgICAg'
    'ICAgICAgICB9KQogICAgICAgICAgICBlbHNlOgogICAgICAgICAgICAgICAgYnVja2V0c1siVU5LTk9XTiJdLmFwcGVuZCh7CiAg'
    'ICAgICAgICAgICAgICAgICAgInBhdGgiOiBhLCAiYnl0ZXMiOiBfZGlyX3NpemUocGEpLCAiY2F0ZWdvcnkiOiAiVU5LTk9XTiIs'
    'CiAgICAgICAgICAgICAgICAgICAgInJlYXNvbiI6ICJEUklGVDogZGlmZmVycyBmcm9tICIgKyBiICsgIjsgbmV2ZXIgYXV0by1k'
    'ZWxldGUiLAogICAgICAgICAgICAgICAgfSkKCiAgICBmb3IgayBpbiBidWNrZXRzOgogICAgICAgIGJ1Y2tldHNba10uc29ydChr'
    'ZXk9bGFtYmRhIGU6IGVbInBhdGgiXSkKICAgIHJldHVybiBidWNrZXRzCgoKZGVmIHBsYW4ocm9vdDogc3RyKSAtPiBkaWN0Ogog'
    'ICAgIiIiUmV0dXJuIHRoZSBmdWxsLCBhdWRpdGFibGUgYWRvcHRpb24gcGxhbiAoZHJ5LXJ1bikuIiIiCiAgICByb290ID0gUGF0'
    'aChyb290KQogICAgYnVja2V0cyA9IHNjYW4ocm9vdCkKICAgIHJlY2xhaW0gPSBzdW0oZVsiYnl0ZXMiXSBmb3IgZSBpbiBidWNr'
    'ZXRzWyJERUxFVEUiXSkKICAgIG1pcnJvcl9ieXRlcyA9IHN1bShlWyJieXRlcyJdIGZvciBlIGluIGJ1Y2tldHNbIk1JUlJPUiJd'
    'KQogICAgcmV0dXJuIHsKICAgICAgICAicm9vdCI6IHN0cihyb290KSwKICAgICAgICAiZHJ5X3J1biI6IFRydWUsCiAgICAgICAg'
    'ImNvdW50cyI6IHtrOiBsZW4odikgZm9yIGssIHYgaW4gYnVja2V0cy5pdGVtcygpfSwKICAgICAgICAicmVjbGFpbV9ieXRlcyI6'
    'IHJlY2xhaW0sCiAgICAgICAgIm1pcnJvcl9ieXRlcyI6IG1pcnJvcl9ieXRlcywKICAgICAgICAiYnVja2V0cyI6IGJ1Y2tldHMs'
    'CiAgICAgICAgInJ1bGVzIjogewogICAgICAgICAgICAia2VlcCI6IEtFRVBfUEFUVEVSTlMsCiAgICAgICAgICAgICJkZWxldGUi'
    'OiBERUxFVEVfUEFUVEVSTlMsCiAgICAgICAgICAgICJtaXJyb3IiOiBbbGlzdChwKSBmb3IgcCBpbiBNSVJST1JfUEFJUlNdLAog'
    'ICAgICAgICAgICAicmV3cml0ZSI6IFJFV1JJVEVfUEFUVEVSTlMsCiAgICAgICAgICAgICJob2xsb3dfY2kiOiBsaXN0KEhPTExP'
    'V19DSSksCiAgICAgICAgfSwKICAgIH0KCgpkZWYgX3RyYWNrZWQocm9vdDogUGF0aCwgcmVsOiBzdHIpIC0+IGJvb2w6CiAgICB0'
    'cnk6CiAgICAgICAgcCA9IHN1YnByb2Nlc3MucnVuKFsiZ2l0IiwgIi1DIiwgc3RyKHJvb3QpLCAibHMtZmlsZXMiLCAiLS1lcnJv'
    'ci11bm1hdGNoIiwgIi0tIiwgcmVsXSwKICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FwdHVyZV9vdXRwdXQ9VHJ1ZSwgdGV4'
    'dD1UcnVlLCB0aW1lb3V0PTEwKQogICAgICAgIHJldHVybiBwLnJldHVybmNvZGUgPT0gMAogICAgZXhjZXB0IEV4Y2VwdGlvbjoK'
    'ICAgICAgICByZXR1cm4gRmFsc2UKCgpkZWYgX3NhZmVfcGF0aChyb290OiBQYXRoLCByZWw6IHN0cikgLT4gUGF0aCB8IE5vbmU6'
    'CiAgICB0cnk6CiAgICAgICAgcm9vdCA9IHJvb3QucmVzb2x2ZSgpCiAgICAgICAgcCA9IChyb290IC8gcmVsKS5yZXNvbHZlKCkK'
    'ICAgICAgICByZXR1cm4gcCBpZiBwLmlzX3JlbGF0aXZlX3RvKHJvb3QpIGVsc2UgTm9uZQogICAgZXhjZXB0IChPU0Vycm9yLCBW'
    'YWx1ZUVycm9yKToKICAgICAgICByZXR1cm4gTm9uZQoKCmRlZiBhcHBseShwbGFuX2RpY3Q6IGRpY3QsIGluY2x1ZGVfbWlycm9y'
    'czogYm9vbCA9IEZhbHNlKSAtPiBkaWN0OgogICAgIiIiRXhlY3V0ZSBvbmx5IHVudHJhY2tlZCBERUxFVEUvTUlSUk9SIGVudHJp'
    'ZXM7IHRyYWNrZWQgZXZpZGVuY2UgaXMgcHJlc2VydmVkLiIiIgogICAgcm9vdCA9IFBhdGgocGxhbl9kaWN0WyJyb290Il0pLnJl'
    'c29sdmUoKQogICAgcmVtb3ZlZDogTGlzdFtzdHJdID0gW10KICAgIHNraXBwZWQ6IExpc3Rbc3RyXSA9IFtdCiAgICBlbnRyaWVz'
    'ID0gbGlzdChwbGFuX2RpY3QuZ2V0KCJidWNrZXRzIiwge30pLmdldCgiREVMRVRFIiwgW10pKQogICAgaWYgaW5jbHVkZV9taXJy'
    'b3JzOgogICAgICAgIGVudHJpZXMgKz0gbGlzdChwbGFuX2RpY3QuZ2V0KCJidWNrZXRzIiwge30pLmdldCgiTUlSUk9SIiwgW10p'
    'KQogICAgZm9yIGVudHJ5IGluIGVudHJpZXM6CiAgICAgICAgcmVsID0gZW50cnlbInBhdGgiXQogICAgICAgIHAgPSBfc2FmZV9w'
    'YXRoKHJvb3QsIHJlbCkKICAgICAgICBpZiBwIGlzIE5vbmUgb3IgX3RyYWNrZWQocm9vdCwgcmVsKToKICAgICAgICAgICAgc2tp'
    'cHBlZC5hcHBlbmQocmVsKQogICAgICAgICAgICBjb250aW51ZQogICAgICAgIHRyeToKICAgICAgICAgICAgaWYgcC5pc19kaXIo'
    'KToKICAgICAgICAgICAgICAgIHNodXRpbC5ybXRyZWUocCkKICAgICAgICAgICAgZWxpZiBwLmV4aXN0cygpOgogICAgICAgICAg'
    'ICAgICAgcC51bmxpbmsoKQogICAgICAgICAgICBpZiBub3QgcC5leGlzdHMoKToKICAgICAgICAgICAgICAgIHJlbW92ZWQuYXBw'
    'ZW5kKHJlbCkKICAgICAgICBleGNlcHQgRXhjZXB0aW9uIGFzIGV4YzoKICAgICAgICAgICAgc2tpcHBlZC5hcHBlbmQocmVsICsg'
    'IjogIiArIHN0cihleGMpKQogICAgcmV0dXJuIHsicmVtb3ZlZCI6IHJlbW92ZWQsICJza2lwcGVkIjogc2tpcHBlZCwgImNvdW50'
    'IjogbGVuKHJlbW92ZWQpfQoKCmRlZiByZW5kZXJfbWFya2Rvd24ocGxhbl9kaWN0OiBkaWN0KSAtPiBzdHI6CiAgICAiIiJIdW1h'
    'bi9hZ2VudC1yZWFkYWJsZSBBRE9QVC5tZC4iIiIKICAgIGMgPSBwbGFuX2RpY3RbImNvdW50cyJdCiAgICBsaW5lcyA9IFsKICAg'
    'ICAgICAiIyBBRE9QVC5tZCAtIHdoYXQgdGhlIGZhY3Rvcnkga2VlcHMsIGRlbGV0ZXMgYW5kIHJld3JpdGVzIiwKICAgICAgICAi'
    'IiwKICAgICAgICAiR2VuZXJhdGVkIGJ5IFNBVkFHRSBGQUNUT1JZLiBUaGlzIGlzIGEgKipkcnktcnVuIHBsYW4qKjogbm90aGlu'
    'ZyBpcyIsCiAgICAgICAgImRlbGV0ZWQgdW50aWwgeW91IHJ1biBgYWRvcHQgLS1hcHBseWAuIiwKICAgICAgICAiIiwKICAgICAg'
    'ICAiIyMgU3VtbWFyeSIsCiAgICAgICAgIiIsCiAgICAgICAgInwgQ2F0ZWdvcnkgfCBGaWxlcyB8IE1lYW5pbmcgfCIsCiAgICAg'
    'ICAgInwtLS18LS0tfC0tLXwiLAogICAgICAgICJ8IEtFRVAgfCAlZCB8IE5ldmVyIHRvdWNoZWQuIHwiICUgYy5nZXQoIktFRVAi'
    'LCAwKSwKICAgICAgICAifCBERUxFVEUgfCAlZCB8IFNhZmUgdG8gcmVtb3ZlICglLjFmIEtCIHJlY2xhaW1hYmxlKS4gfCIgJSAo'
    'CiAgICAgICAgICAgIGMuZ2V0KCJERUxFVEUiLCAwKSwgcGxhbl9kaWN0WyJyZWNsYWltX2J5dGVzIl0gLyAxMDI0KSwKICAgICAg'
    'ICAifCBNSVJST1IgfCAlZCB8IER1cGxpY2F0ZSB0cmVlOyBuZWVkcyBleHBsaWNpdCBjb25maXJtYXRpb24uIHwiICUgYy5nZXQo'
    'Ik1JUlJPUiIsIDApLAogICAgICAgICJ8IFJFV1JJVEUgfCAlZCB8IEhvbGxvdyBDSSBnYXRlOyBtdXN0IGJlIHJld3JpdHRlbi4g'
    'fCIgJSBjLmdldCgiUkVXUklURSIsIDApLAogICAgICAgICJ8IFVOS05PV04gfCAlZCB8IExlZnQgYWxvbmU7IHRoZSBtb2RlbCBk'
    'ZWNpZGVzLiB8IiAlIGMuZ2V0KCJVTktOT1dOIiwgMCksCiAgICAgICAgIiIsCiAgICAgICAgIiMjIEtFRVAgKG5ldmVyIHRvdWNo'
    'ZWQpIiwKICAgICAgICAiIiwKICAgIF0KICAgIGZvciBlIGluIHBsYW5fZGljdFsiYnVja2V0cyJdWyJLRUVQIl1bOjgwXToKICAg'
    'ICAgICBsaW5lcy5hcHBlbmQoIi0gYCVzYCIgJSBlWyJwYXRoIl0pCiAgICBsaW5lcyArPSBbIiIsICIjIyBERUxFVEUgKHJlbW92'
    'ZWQgYnkgYGFkb3B0IC0tYXBwbHlgKSIsICIiXQogICAgZm9yIGUgaW4gcGxhbl9kaWN0WyJidWNrZXRzIl1bIkRFTEVURSJdWzox'
    'MjBdOgogICAgICAgIGxpbmVzLmFwcGVuZCgiLSBgJXNgIiAlIGVbInBhdGgiXSkKICAgIGlmIG5vdCBwbGFuX2RpY3RbImJ1Y2tl'
    'dHMiXVsiREVMRVRFIl06CiAgICAgICAgbGluZXMuYXBwZW5kKCItIChub3RoaW5nKSIpCiAgICBsaW5lcyArPSBbIiIsICIjIyBN'
    'SVJST1IgKGR1cGxpY2F0ZSB0cmVlcyAtIGNvbmZpcm0gYmVmb3JlIGRlbGV0aW5nKSIsICIiXQogICAgZm9yIGUgaW4gcGxhbl9k'
    'aWN0WyJidWNrZXRzIl1bIk1JUlJPUiJdOgogICAgICAgIGxpbmVzLmFwcGVuZCgiLSBgJXNgIC0gJXMiICUgKGVbInBhdGgiXSwg'
    'ZS5nZXQoInJlYXNvbiIsICIiKSkpCiAgICBpZiBub3QgcGxhbl9kaWN0WyJidWNrZXRzIl1bIk1JUlJPUiJdOgogICAgICAgIGxp'
    'bmVzLmFwcGVuZCgiLSAobm9uZSkiKQogICAgbGluZXMgKz0gWyIiLCAiIyMgUkVXUklURSAoaG9sbG93IENJIGdhdGVzIC0gcmVw'
    'bGFjZSB3aXRoIHRoZSByZWFsIGdhdGUpIiwgIiJdCiAgICBmb3IgZSBpbiBwbGFuX2RpY3RbImJ1Y2tldHMiXVsiUkVXUklURSJd'
    'OgogICAgICAgIGxpbmVzLmFwcGVuZCgiLSBgJXNgIC0gJXMiICUgKGVbInBhdGgiXSwgZS5nZXQoInJlYXNvbiIsICIiKSkpCiAg'
    'ICBpZiBub3QgcGxhbl9kaWN0WyJidWNrZXRzIl1bIlJFV1JJVEUiXToKICAgICAgICBsaW5lcy5hcHBlbmQoIi0gKG5vbmUpIikK'
    'ICAgIGxpbmVzICs9IFsKICAgICAgICAiIiwKICAgICAgICAiIyMgSG93IHRvIGFwcGx5IiwKICAgICAgICAiIiwKICAgICAgICAi'
    'YGBgYmFzaCIsCiAgICAgICAgInB5dGhvbjMgU0FWQUdFX0ZBQ1RPUlkucHkgYWRvcHQgICAgICAgICAgICAjIGRyeS1ydW4gKHRo'
    'aXMgcmVwb3J0KSIsCiAgICAgICAgInB5dGhvbjMgU0FWQUdFX0ZBQ1RPUlkucHkgYWRvcHQgLS1hcHBseSAgICAjIGRlbGV0ZSB0'
    'aGUgREVMRVRFIGJ1Y2tldCIsCiAgICAgICAgInB5dGhvbjMgU0FWQUdFX0ZBQ1RPUlkucHkgYWRvcHQgLS1hcHBseSAtLW1pcnJv'
    'cnMgICAjIGFsc28gZGVsZXRlIG1pcnJvcnMiLAogICAgICAgICJgYGAiLAogICAgICAgICIiLAogICAgXQogICAgcmV0dXJuICJc'
    'biIuam9pbihsaW5lcykKI0BARklMRTpmYWN0b3J5L2NsZWFuZXIvX19pbml0X18ucHlAQAoiIiJEcnktcnVuLWZpcnN0IGRlc3Ry'
    'dWN0aXZlIG1haW50ZW5hbmNlLiIiIgpmcm9tIC5jbGVhbmVyIGltcG9ydCBwbGFuLCBhcHBseQoKX19hbGxfXyA9IFsicGxhbiIs'
    'ICJhcHBseSJdCiNAQEZJTEU6ZmFjdG9yeS9jbGVhbmVyL2NsZWFuZXIucHlAQAoiIiJUaGUgQ2xlYW5lcjogZHJ5LXJ1bi1maXJz'
    'dCBkZXN0cnVjdGl2ZSBtYWludGVuYW5jZS4KCkl0IE5FVkVSIGRlbGV0ZXMgYW55dGhpbmcgdW5sZXNzIHlvdSBwYXNzIGFwcGx5'
    'PVRydWUuICBJdCB0YXJnZXRzOiBzdGFsZSBjYWNoZXMsCmR1cGxpY2F0ZSBtaXJyb3IgdHJlZXMsIF9fcHljYWNoZV9fLCBvdmVy'
    'c2l6ZWQgbG9ncywgYW5kIG9ycGhhbmVkIGFydGlmYWN0cy4KIiIiCmZyb20gX19mdXR1cmVfXyBpbXBvcnQgYW5ub3RhdGlvbnMK'
    'CmltcG9ydCBvcwppbXBvcnQgdGltZQpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKZnJvbSB0eXBpbmcgaW1wb3J0IExpc3QKClNU'
    'QUxFX1NFQ09ORFMgPSA3ICogMjQgKiAzNjAwCgoKZGVmIF9zaXplKHA6IFBhdGgpIC0+IGludDoKICAgIGlmIHAuaXNfZmlsZSgp'
    'OgogICAgICAgIHJldHVybiBwLnN0YXQoKS5zdF9zaXplCiAgICB0b3RhbCA9IDAKICAgIGZvciByb290LCBfLCBmaWxlcyBpbiBv'
    'cy53YWxrKHApOgogICAgICAgIGZvciBmIGluIGZpbGVzOgogICAgICAgICAgICB0cnk6CiAgICAgICAgICAgICAgICB0b3RhbCAr'
    'PSAoUGF0aChyb290KSAvIGYpLnN0YXQoKS5zdF9zaXplCiAgICAgICAgICAgIGV4Y2VwdCBFeGNlcHRpb246CiAgICAgICAgICAg'
    'ICAgICBwYXNzCiAgICByZXR1cm4gdG90YWwKCgpkZWYgcGxhbihyb290OiBzdHIpIC0+IGRpY3Q6CiAgICByb290ID0gUGF0aChy'
    'b290KQogICAgdGFyZ2V0czogTGlzdFtkaWN0XSA9IFtdCiAgICBmb3IgcGF0IGluICgiKiovX19weWNhY2hlX18iLCAiKiovKi5w'
    'eWMiLCAiLnNhdmFnZS9jYWNoZS8qKiIsICIqKi9ub2RlX21vZHVsZXMvLmNhY2hlLyoqIik6CiAgICAgICAgZm9yIHAgaW4gcm9v'
    'dC5nbG9iKHBhdCk6CiAgICAgICAgICAgIHRhcmdldHMuYXBwZW5kKHsicGF0aCI6IHN0cihwKSwgImJ5dGVzIjogX3NpemUocCks'
    'ICJyZWFzb24iOiAiY2FjaGUifSkKICAgICMgc3RhbGUgbG9ncwogICAgZm9yIHAgaW4gcm9vdC5nbG9iKCIqKi8qLmxvZyIpOgog'
    'ICAgICAgIHRyeToKICAgICAgICAgICAgaWYgdGltZS50aW1lKCkgLSBwLnN0YXQoKS5zdF9tdGltZSA+IFNUQUxFX1NFQ09ORFM6'
    'CiAgICAgICAgICAgICAgICB0YXJnZXRzLmFwcGVuZCh7InBhdGgiOiBzdHIocCksICJieXRlcyI6IF9zaXplKHApLCAicmVhc29u'
    'IjogInN0YWxlLWxvZyJ9KQogICAgICAgIGV4Y2VwdCBFeGNlcHRpb246CiAgICAgICAgICAgIHBhc3MKICAgICMgZHVwbGljYXRl'
    'IG1pcnJvciB0cmVlcyAodGhlIGNsYXNzaWMgZmFjdG9yeS0yIHZzIGZhY3Rvcmllcy9mYWN0b3J5LTIgcHJvYmxlbSkKICAgIGZv'
    'ciBuYW1lIGluICgiZmFjdG9yeS0yIiwgImZhY3RvcnktMyIpOgogICAgICAgIGEgPSByb290IC8gbmFtZQogICAgICAgIGIgPSBy'
    'b290IC8gImZhY3RvcmllcyIgLyBuYW1lCiAgICAgICAgaWYgYS5leGlzdHMoKSBhbmQgYi5leGlzdHMoKToKICAgICAgICAgICAg'
    'dGFyZ2V0cy5hcHBlbmQoeyJwYXRoIjogc3RyKGEpLCAiYnl0ZXMiOiBfc2l6ZShhKSwgInJlYXNvbiI6ICJkdXBsaWNhdGUtbWly'
    'cm9yIiwgImtlZXAiOiBzdHIoYil9KQogICAgdG90YWwgPSBzdW0odFsiYnl0ZXMiXSBmb3IgdCBpbiB0YXJnZXRzKQogICAgcmV0'
    'dXJuIHsicm9vdCI6IHN0cihyb290KSwgInRhcmdldHMiOiB0YXJnZXRzLCAiY291bnQiOiBsZW4odGFyZ2V0cyksCiAgICAgICAg'
    'ICAgICJyZWNsYWltX2J5dGVzIjogdG90YWwsICJkcnlfcnVuIjogVHJ1ZX0KCgpkZWYgYXBwbHkocGxhbl9kaWN0OiBkaWN0KSAt'
    'PiBkaWN0OgogICAgcmVtb3ZlZCA9IFtdCiAgICBmb3IgdCBpbiBwbGFuX2RpY3QuZ2V0KCJ0YXJnZXRzIiwgW10pOgogICAgICAg'
    'IGlmIHQuZ2V0KCJyZWFzb24iKSA9PSAiZHVwbGljYXRlLW1pcnJvciI6CiAgICAgICAgICAgIGNvbnRpbnVlICAjIG5ldmVyIGF1'
    'dG8tZGVsZXRlIGEgbWlycm9yOyByZXF1aXJlIGEgaHVtYW4KICAgICAgICBwID0gUGF0aCh0WyJwYXRoIl0pCiAgICAgICAgdHJ5'
    'OgogICAgICAgICAgICBpZiBwLmlzX2RpcigpOgogICAgICAgICAgICAgICAgaW1wb3J0IHNodXRpbAogICAgICAgICAgICAgICAg'
    'c2h1dGlsLnJtdHJlZShwKQogICAgICAgICAgICBlbGlmIHAuZXhpc3RzKCk6CiAgICAgICAgICAgICAgICBwLnVubGluaygpCiAg'
    'ICAgICAgICAgIHJlbW92ZWQuYXBwZW5kKHRbInBhdGgiXSkKICAgICAgICBleGNlcHQgRXhjZXB0aW9uOgogICAgICAgICAgICBw'
    'YXNzCiAgICByZXR1cm4geyJyZW1vdmVkIjogcmVtb3ZlZCwgImNvdW50IjogbGVuKHJlbW92ZWQpfQojQEBGSUxFOmZhY3Rvcnkv'
    'aW1wcm92ZXIvX19pbml0X18ucHlAQAoiIiIyNC83IHNlbGYtaW1wcm92ZW1lbnQgbG9vcC4iIiIKZnJvbSAuaW1wcm92ZXIgaW1w'
    'b3J0IGN5Y2xlLCBiZW5jaG1hcmsKCl9fYWxsX18gPSBbImN5Y2xlIiwgImJlbmNobWFyayJdCiNAQEZJTEU6ZmFjdG9yeS9pbXBy'
    'b3Zlci9pbXByb3Zlci5weUBACiIiIlRoZSAyNC83IEltcHJvdmVyLgoKRXZlcnkgY3ljbGUgaXQ6CiAgMS4gYmVuY2htYXJrcyBl'
    'dmVyeSB0b29sIGFnYWluc3QgKnRoaXMqIGhvc3QgKGlzIHRoZSBiaW5hcnkgYWN0dWFsbHkgcHJlc2VudD8pLAogIDIuIGRldGVj'
    'dHMgZHJpZnQgYmV0d2VlbiB3aGF0IHRoZSByZWdpc3RyeSBjbGFpbXMgYW5kIHdoYXQgaXMgcmVhbCwKICAzLiBwcm9wb3NlcyAr'
    'IGFwcGxpZXMgY29uc2VydmF0aXZlIHRpZXIgY2hhbmdlcyAoZGVtb3RlIHZlcmlmaWVkLWJ1dC1hYnNlbnQsCiAgICAgcHJvbW90'
    'ZSBwcm92aXNpb25hbC1hbmQtcHJlc2VudC1hbmQtZGV0ZXJtaW5pc3RpYyksCiAgNC4gcnVucyBhIHJldmVyc2libGUgZmF1bHQt'
    'aW5qZWN0aW9uIGRyaWxsLCBhbmQKICA1LiBhcHBlbmRzIGFuIGF1ZGl0YWJsZSByZWNvcmQgdG8gLnNhdmFnZS9pbXByb3ZlX2hp'
    'c3RvcnkuanNvbmwuCgpUaWVyIGNoYW5nZXMgcmVxdWlyZSBldmlkZW5jZSAoYSBiZW5jaG1hcmsgZGVsdGEpLCBuZXZlciB2aWJl'
    'cy4KIiIiCmZyb20gX19mdXR1cmVfXyBpbXBvcnQgYW5ub3RhdGlvbnMKCmltcG9ydCBqc29uCmltcG9ydCBzaHV0aWwKaW1wb3J0'
    'IHRpbWUKZnJvbSBwYXRobGliIGltcG9ydCBQYXRoCmZyb20gdHlwaW5nIGltcG9ydCBEaWN0LCBMaXN0LCBUdXBsZQoKIyBLaW5k'
    'cyB0aGF0IGFyZSBzYWZlIHRvIHByb21vdGUgb25jZSBwcmVzZW50IChkZXRlcm1pbmlzdGljLCBubyBuZXR3b3JrKS4KX1BST01P'
    'VEFCTEVfS0lORFMgPSAoImxpbnQiLCAidGVzdCIsICJidWlsZCIsICJmb3JtYXQiLCAic2NhbiIsICJwYXJzZSIsICJ0cmFuc2Zv'
    'cm0iKQoKCmRlZiBfbG9hZChyZWdpc3RyeV9wYXRoOiBQYXRoKSAtPiBkaWN0OgogICAgcCA9IFBhdGgocmVnaXN0cnlfcGF0aCkK'
    'ICAgIGlmIHAuZXhpc3RzKCk6CiAgICAgICAgdHJ5OgogICAgICAgICAgICByZXR1cm4ganNvbi5sb2FkcyhwLnJlYWRfdGV4dCgp'
    'KQogICAgICAgIGV4Y2VwdCBFeGNlcHRpb246CiAgICAgICAgICAgIHBhc3MKICAgIHJldHVybiB7InRvb2xzIjogW119CgoKZGVm'
    'IF9wcm9iZSh0b29sOiBkaWN0KSAtPiBUdXBsZVtib29sLCBzdHJdOgogICAgIiIiSXMgdGhlIHRvb2wgYWN0dWFsbHkgdXNhYmxl'
    'IG9uIHRoaXMgaG9zdD8gIFRyeSBpZCwgdGhlbiBmaXJzdCByZXF1aXJlbWVudC4iIiIKICAgIGNhbmRzOiBMaXN0W3N0cl0gPSBb'
    'c3RyKHRvb2wuZ2V0KCJpZCIsICIiKSldCiAgICBmb3IgciBpbiB0b29sLmdldCgicmVxdWlyZXMiKSBvciBbXToKICAgICAgICBj'
    'YW5kcy5hcHBlbmQoc3RyKHIpKQogICAgZm9yIGMgaW4gY2FuZHM6CiAgICAgICAgaWYgYyBhbmQgc2h1dGlsLndoaWNoKGMpOgog'
    'ICAgICAgICAgICByZXR1cm4gVHJ1ZSwgYwogICAgcmV0dXJuIEZhbHNlLCAiIgoKCmRlZiBiZW5jaG1hcmsocmVnaXN0cnlfcGF0'
    'aDogUGF0aCkgLT4gRGljdFtzdHIsIGRpY3RdOgogICAgIiIiQSBkZXRlcm1pbmlzdGljLCBjaGVhcCBiZW5jaG1hcms6IHByZXNl'
    'bmNlICsgYSBkZWZlbnNpYmxlIHNjb3JlLiIiIgogICAgcmVnID0gX2xvYWQocmVnaXN0cnlfcGF0aCkKICAgIG91dDogRGljdFtz'
    'dHIsIGRpY3RdID0ge30KICAgIGZvciB0IGluIHJlZy5nZXQoInRvb2xzIiwgW10pOgogICAgICAgIHByZXNlbnQsIHZpYSA9IF9w'
    'cm9iZSh0KQogICAgICAgIG91dFt0WyJpZCJdXSA9IHsKICAgICAgICAgICAgInByZXNlbnQiOiBwcmVzZW50LAogICAgICAgICAg'
    'ICAidmlhIjogdmlhLAogICAgICAgICAgICAidGllciI6IHQuZ2V0KCJ0aWVyIiksCiAgICAgICAgICAgICJzY29yZSI6IDEuMCBp'
    'ZiBwcmVzZW50IGVsc2UgMC4wLAogICAgICAgIH0KICAgIHJldHVybiBvdXQKCgpkZWYgX3Byb3Bvc2UocmVnOiBkaWN0LCBzY29y'
    'ZXM6IERpY3Rbc3RyLCBkaWN0XSkgLT4gVHVwbGVbTGlzdFtzdHJdLCBMaXN0W3N0cl1dOgogICAgcHJvbW90aW9uczogTGlzdFtz'
    'dHJdID0gW10KICAgIGRlbW90aW9uczogTGlzdFtzdHJdID0gW10KICAgIGZvciB0IGluIHJlZy5nZXQoInRvb2xzIiwgW10pOgog'
    'ICAgICAgIHMgPSBzY29yZXMuZ2V0KHRbImlkIl0sIHt9KQogICAgICAgIHByZXNlbnQgPSBib29sKHMuZ2V0KCJwcmVzZW50Iikp'
    'CiAgICAgICAgdGllciA9IHQuZ2V0KCJ0aWVyIikKICAgICAgICAjIERlbW90ZSBhIFZFUklGSUVEIHRvb2wgdGhhdCBjYW5ub3Qg'
    'YWN0dWFsbHkgcnVuIGhlcmU6IGl0IG11c3Qgbm90IGdhdGUuCiAgICAgICAgaWYgdGllciA9PSAidmVyaWZpZWQiIGFuZCBub3Qg'
    'cHJlc2VudDoKICAgICAgICAgICAgZGVtb3Rpb25zLmFwcGVuZCh0WyJpZCJdKQogICAgICAgICMgUHJvbW90ZSBhIFBST1ZJU0lP'
    'TkFMLCBwcmVzZW50LCBkZXRlcm1pbmlzdGljLCBvZmZsaW5lIHRvb2wuCiAgICAgICAgZWxpZiAodGllciA9PSAicHJvdmlzaW9u'
    'YWwiIGFuZCBwcmVzZW50CiAgICAgICAgICAgICAgYW5kIHQuZ2V0KCJraW5kIikgaW4gX1BST01PVEFCTEVfS0lORFMKICAgICAg'
    'ICAgICAgICBhbmQgbm90IHQuZ2V0KCJuZXR3b3JrIikpOgogICAgICAgICAgICBwcm9tb3Rpb25zLmFwcGVuZCh0WyJpZCJdKQog'
    'ICAgcmV0dXJuIHByb21vdGlvbnMsIGRlbW90aW9ucwoKCmRlZiBfYXBwbHkocmVnOiBkaWN0LCBwcm9tb3Rpb25zOiBMaXN0W3N0'
    'cl0sIGRlbW90aW9uczogTGlzdFtzdHJdKSAtPiBkaWN0OgogICAgIiIiQXBwbHkgdGllciBjaGFuZ2VzIGluIHBsYWNlLiAgUmV0'
    'dXJucyBhIHN1bW1hcnkuIiIiCiAgICBwcm9tLCBkZW0gPSBzZXQocHJvbW90aW9ucyksIHNldChkZW1vdGlvbnMpCiAgICBjaGFu'
    'Z2VkID0gMAogICAgZm9yIHQgaW4gcmVnLmdldCgidG9vbHMiLCBbXSk6CiAgICAgICAgaWYgdFsiaWQiXSBpbiBwcm9tIGFuZCB0'
    'LmdldCgidGllciIpID09ICJwcm92aXNpb25hbCI6CiAgICAgICAgICAgIHRbInRpZXIiXSA9ICJ2ZXJpZmllZCIKICAgICAgICAg'
    'ICAgdFsibWF5X2dhdGUiXSA9IFRydWUKICAgICAgICAgICAgY2hhbmdlZCArPSAxCiAgICAgICAgZWxpZiB0WyJpZCJdIGluIGRl'
    'bSBhbmQgdC5nZXQoInRpZXIiKSA9PSAidmVyaWZpZWQiOgogICAgICAgICAgICB0WyJ0aWVyIl0gPSAicHJvdmlzaW9uYWwiCiAg'
    'ICAgICAgICAgIHRbIm1heV9nYXRlIl0gPSBGYWxzZQogICAgICAgICAgICBjaGFuZ2VkICs9IDEKICAgIHJldHVybiB7ImNoYW5n'
    'ZWQiOiBjaGFuZ2VkfQoKCmRlZiBfZmF1bHRfZHJpbGwocm9vdDogUGF0aCkgLT4gZGljdDoKICAgICIiIkEgcmV2ZXJzaWJsZSBk'
    'cmlsbDogY3JlYXRlIGEgdGVtcCBmaWxlLCB2ZXJpZnkgZGV0ZWN0aW9uLCByZW1vdmUgaXQuIiIiCiAgICBwcm9iZSA9IHJvb3Qg'
    'LyAiLnNhdmFnZSIgLyAiZHJpbGxfcHJvYmUudG1wIgogICAgcHJvYmUucGFyZW50Lm1rZGlyKHBhcmVudHM9VHJ1ZSwgZXhpc3Rf'
    'b2s9VHJ1ZSkKICAgIHByb2JlLndyaXRlX3RleHQoInByb2JlIikKICAgIGRldGVjdGVkID0gcHJvYmUuZXhpc3RzKCkKICAgIHBy'
    'b2JlLnVubGluaygpCiAgICByZXR1cm4geyJwcm9iZV9kZXRlY3RlZCI6IGRldGVjdGVkLCAicmV2ZXJ0ZWQiOiBub3QgcHJvYmUu'
    'ZXhpc3RzKCl9CgoKZGVmIGN5Y2xlKHJvb3Q6IFBhdGgsIHJlZ2lzdHJ5X3BhdGg6IFBhdGgpIC0+IGRpY3Q6CiAgICByb290ID0g'
    'UGF0aChyb290KQogICAgcmVnaXN0cnlfcGF0aCA9IFBhdGgocmVnaXN0cnlfcGF0aCkKICAgIHNjb3JlcyA9IGJlbmNobWFyayhy'
    'ZWdpc3RyeV9wYXRoKQogICAgcmVnID0gX2xvYWQocmVnaXN0cnlfcGF0aCkKICAgIHByb21vdGlvbnMsIGRlbW90aW9ucyA9IF9w'
    'cm9wb3NlKHJlZywgc2NvcmVzKQogICAgYXBwbGllZCA9IF9hcHBseShyZWcsIHByb21vdGlvbnMsIGRlbW90aW9ucykKCiAgICBp'
    'ZiBhcHBsaWVkWyJjaGFuZ2VkIl06CiAgICAgICAgYmFja3VwID0gcmVnaXN0cnlfcGF0aC53aXRoX3N1ZmZpeCgiLmpzb24uYmFr'
    'IikKICAgICAgICB0cnk6CiAgICAgICAgICAgIGlmIHJlZ2lzdHJ5X3BhdGguZXhpc3RzKCk6CiAgICAgICAgICAgICAgICBiYWNr'
    'dXAud3JpdGVfdGV4dChyZWdpc3RyeV9wYXRoLnJlYWRfdGV4dCgpKQogICAgICAgICAgICByZWdpc3RyeV9wYXRoLndyaXRlX3Rl'
    'eHQoanNvbi5kdW1wcyhyZWcsIGluZGVudD0yKSkKICAgICAgICBleGNlcHQgRXhjZXB0aW9uOgogICAgICAgICAgICBwYXNzCgog'
    'ICAgcHJlc2VudCA9IHN1bSgxIGZvciB2IGluIHNjb3Jlcy52YWx1ZXMoKSBpZiB2WyJwcmVzZW50Il0pCiAgICByZXBvcnQgPSB7'
    'CiAgICAgICAgInRzIjogdGltZS50aW1lKCksCiAgICAgICAgImJlbmNobWFya2VkIjogbGVuKHNjb3JlcyksCiAgICAgICAgInBy'
    'ZXNlbnQiOiBwcmVzZW50LAogICAgICAgICJhYnNlbnQiOiBsZW4oc2NvcmVzKSAtIHByZXNlbnQsCiAgICAgICAgInByb21vdGlv'
    'bnMiOiBwcm9tb3Rpb25zLAogICAgICAgICJkZW1vdGlvbnMiOiBkZW1vdGlvbnMsCiAgICAgICAgImFwcGxpZWQiOiBhcHBsaWVk'
    'LAogICAgICAgICJkcmlsbCI6IF9mYXVsdF9kcmlsbChyb290KSwKICAgIH0KCiAgICBoaXN0ID0gcm9vdCAvICIuc2F2YWdlIiAv'
    'ICJpbXByb3ZlX2hpc3RvcnkuanNvbmwiCiAgICBoaXN0LnBhcmVudC5ta2RpcihwYXJlbnRzPVRydWUsIGV4aXN0X29rPVRydWUp'
    'CiAgICB3aXRoIG9wZW4oaGlzdCwgImEiKSBhcyBmaDoKICAgICAgICBmaC53cml0ZShqc29uLmR1bXBzKHJlcG9ydCkgKyAiXG4i'
    'KQoKICAgIG91dCA9IHJvb3QgLyAiLnNhdmFnZSIgLyAiaW1wcm92ZV9yZXBvcnQuanNvbiIKICAgIG91dC53cml0ZV90ZXh0KGpz'
    'b24uZHVtcHMocmVwb3J0LCBpbmRlbnQ9MikpCiAgICByZXR1cm4gcmVwb3J0CiNAQEZJTEU6ZmFjdG9yeS9tYW5hZ2VyL19faW5p'
    'dF9fLnB5QEAKIiIiRmFjdG9yeSBNYW5hZ2VyOiBkdXJhYmxlIHF1ZXVlICsgcG9saWN5ICsgdGhlIHJ1biBsb29wLiIiIgpmcm9t'
    'IC5xdWV1ZSBpbXBvcnQgUXVldWUKZnJvbSAucG9saWN5IGltcG9ydCBQb2xpY3kKZnJvbSAubWFuYWdlciBpbXBvcnQgTWFuYWdl'
    'cgoKX19hbGxfXyA9IFsiUXVldWUiLCAiUG9saWN5IiwgIk1hbmFnZXIiXQojQEBGSUxFOmZhY3RvcnkvbWFuYWdlci9tYW5hZ2Vy'
    'LnB5QEAKIiIiVGhlIEZhY3RvcnkgTWFuYWdlciBsb29wOiBwb3AgLT4gcm91dGUgLT4gZXhlY3V0ZSAtPiBnYXRlIC0+IGFjay4K'
    'CkRldGVybWluaXN0aWMgc2hlbGwsIGFnZW50aWMgY29yZS4gIFRoZSBtYW5hZ2VyIG5ldmVyIGxldHMgYW4gdW52ZXJpZmllZCB0'
    'b29sCmdhdGUgYSByZWxlYXNlLgoiIiIKZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGpzb24KaW1w'
    'b3J0IHRpbWUKZnJvbSBwYXRobGliIGltcG9ydCBQYXRoCmZyb20gdHlwaW5nIGltcG9ydCBDYWxsYWJsZSwgT3B0aW9uYWwKCmZy'
    'b20gLnF1ZXVlIGltcG9ydCBRdWV1ZQpmcm9tIC5wb2xpY3kgaW1wb3J0IFBvbGljeQoKCmNsYXNzIE1hbmFnZXI6CiAgICBkZWYg'
    'X19pbml0X18oc2VsZiwgcm9vdDogUGF0aCwgcmVnaXN0cnlfcGF0aDogUGF0aCwKICAgICAgICAgICAgICAgICBoYW5kbGVyOiBP'
    'cHRpb25hbFtDYWxsYWJsZVtbZGljdF0sIGRpY3RdXSA9IE5vbmUpIC0+IE5vbmU6CiAgICAgICAgc2VsZi5xdWV1ZSA9IFF1ZXVl'
    'KFBhdGgocm9vdCkgLyAicXVldWUiKQogICAgICAgIHNlbGYucG9saWN5ID0gUG9saWN5KHJlZ2lzdHJ5X3BhdGgpCiAgICAgICAg'
    'c2VsZi5oYW5kbGVyID0gaGFuZGxlciBvciBzZWxmLl9kZWZhdWx0X2hhbmRsZXIKICAgICAgICBzZWxmLmxvZyA9IFBhdGgocm9v'
    'dCkgLyAibWFuYWdlci5sb2ciCgogICAgZGVmIF9kZWZhdWx0X2hhbmRsZXIoc2VsZiwgam9iOiBkaWN0KSAtPiBkaWN0OgogICAg'
    'ICAgIHN0YWdlID0gam9iLmdldCgic3RhZ2UiLCAiYnVpbGQiKQogICAgICAgIG1vZGVsX2NsYXNzID0gc2VsZi5wb2xpY3kucm91'
    'dGUoc3RhZ2UpCiAgICAgICAgcmV0dXJuIHsic3RhZ2UiOiBzdGFnZSwgIm1vZGVsX2NsYXNzIjogbW9kZWxfY2xhc3MsICJzdGF0'
    'dXMiOiAicm91dGVkIn0KCiAgICBkZWYgX3dyaXRlX2xvZyhzZWxmLCByZWM6IGRpY3QpIC0+IE5vbmU6CiAgICAgICAgd2l0aCBv'
    'cGVuKHNlbGYubG9nLCAiYSIpIGFzIGY6CiAgICAgICAgICAgIGYud3JpdGUoanNvbi5kdW1wcyhyZWMpICsgIlxuIikKCiAgICBk'
    'ZWYgc3VibWl0KHNlbGYsIHN0YWdlOiBzdHIsIHByb21wdDogc3RyLCAqKmt3KSAtPiBzdHI6CiAgICAgICAgam9iID0geyJzdGFn'
    'ZSI6IHN0YWdlLCAicHJvbXB0IjogcHJvbXB0fQogICAgICAgIGpvYi51cGRhdGUoa3cpCiAgICAgICAgcmV0dXJuIHNlbGYucXVl'
    'dWUucHVzaChqb2IpCgogICAgZGVmIHN0ZXAoc2VsZikgLT4gT3B0aW9uYWxbZGljdF06CiAgICAgICAgam9iID0gc2VsZi5xdWV1'
    'ZS5wb3AoKQogICAgICAgIGlmIGpvYiBpcyBOb25lOgogICAgICAgICAgICByZXR1cm4gTm9uZQogICAgICAgIGVycnMgPSBzZWxm'
    'LnBvbGljeS5jaGVja19qb2Ioam9iKQogICAgICAgIGlmIGVycnM6CiAgICAgICAgICAgIHNlbGYucXVldWUuYWNrKGpvYiwgeyJz'
    'dGF0dXMiOiAiUkVKRUNURUQiLCAiZXJyb3JzIjogZXJyc30pCiAgICAgICAgICAgIHNlbGYuX3dyaXRlX2xvZyh7ImpvYiI6IGpv'
    'YlsiaWQiXSwgInN0YXR1cyI6ICJSRUpFQ1RFRCIsICJlcnJvcnMiOiBlcnJzfSkKICAgICAgICAgICAgcmV0dXJuIHsiam9iIjog'
    'am9iLCAic3RhdHVzIjogIlJFSkVDVEVEIiwgImVycm9ycyI6IGVycnN9CiAgICAgICAgdHJ5OgogICAgICAgICAgICByZXN1bHQg'
    'PSBzZWxmLmhhbmRsZXIoam9iKQogICAgICAgICAgICBzdGF0dXMgPSAiT0siCiAgICAgICAgZXhjZXB0IEV4Y2VwdGlvbiBhcyBl'
    'eGM6CiAgICAgICAgICAgIHJlc3VsdCA9IHsiZXJyb3IiOiByZXByKGV4Yyl9CiAgICAgICAgICAgIHN0YXR1cyA9ICJFUlJPUiIK'
    'ICAgICAgICBzZWxmLnF1ZXVlLmFjayhqb2IsIHJlc3VsdCkKICAgICAgICBzZWxmLl93cml0ZV9sb2coeyJqb2IiOiBqb2JbImlk'
    'Il0sICJzdGF0dXMiOiBzdGF0dXMsICJyZXN1bHQiOiByZXN1bHR9KQogICAgICAgIHJldHVybiB7ImpvYiI6IGpvYiwgInN0YXR1'
    'cyI6IHN0YXR1cywgInJlc3VsdCI6IHJlc3VsdH0KCiAgICBkZWYgcnVuKHNlbGYsIG1heF9qb2JzOiBpbnQgPSAxMDAsIGlkbGVf'
    'c2xlZXA6IGZsb2F0ID0gMC41KSAtPiBpbnQ6CiAgICAgICAgcHJvY2Vzc2VkID0gMAogICAgICAgIHdoaWxlIHByb2Nlc3NlZCA8'
    'IG1heF9qb2JzOgogICAgICAgICAgICBvdXQgPSBzZWxmLnN0ZXAoKQogICAgICAgICAgICBpZiBvdXQgaXMgTm9uZToKICAgICAg'
    'ICAgICAgICAgIGJyZWFrCiAgICAgICAgICAgIHByb2Nlc3NlZCArPSAxCiAgICAgICAgcmV0dXJuIHByb2Nlc3NlZAojQEBGSUxF'
    'OmZhY3RvcnkvbWFuYWdlci9wb2xpY3kucHlAQAoiIiJUaWVyIGVuZm9yY2VtZW50ICsgc3RhZ2Ugcm91dGluZyBwb2xpY3kuIiIi'
    'CmZyb20gX19mdXR1cmVfXyBpbXBvcnQgYW5ub3RhdGlvbnMKCmltcG9ydCBqc29uCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aApm'
    'cm9tIHR5cGluZyBpbXBvcnQgRGljdCwgTGlzdAoKU1RBR0VfTU9ERUxfQ0xBU1MgPSB7CiAgICAiaW50YWtlIjogIm5vbmUiLCAi'
    'c3BlYyI6ICJwcmVtaXVtIiwgImJ1aWxkIjogImNoZWFwIiwgInZlcmlmeSI6ICJwcmVtaXVtIiwKICAgICJwYWNrYWdlIjogIm5v'
    'bmUiLCAic2hpcCI6ICJub25lIiwgImltcHJvdmUiOiAiY2hlYXAiLAp9CkdBVEVfVElFUlMgPSAoInZlcmlmaWVkIiwpCgoKY2xh'
    'c3MgUG9saWN5OgogICAgZGVmIF9faW5pdF9fKHNlbGYsIHJlZ2lzdHJ5X3BhdGg6IFBhdGgpIC0+IE5vbmU6CiAgICAgICAgc2Vs'
    'Zi5yZWdpc3RyeV9wYXRoID0gUGF0aChyZWdpc3RyeV9wYXRoKQogICAgICAgIHNlbGYudG9vbHM6IERpY3Rbc3RyLCBkaWN0XSA9'
    'IHt9CiAgICAgICAgaWYgc2VsZi5yZWdpc3RyeV9wYXRoLmV4aXN0cygpOgogICAgICAgICAgICBkYXRhID0ganNvbi5sb2Fkcyhz'
    'ZWxmLnJlZ2lzdHJ5X3BhdGgucmVhZF90ZXh0KCkpCiAgICAgICAgICAgIGZvciB0IGluIGRhdGEuZ2V0KCJ0b29scyIsIFtdKToK'
    'ICAgICAgICAgICAgICAgIHNlbGYudG9vbHNbdFsiaWQiXV0gPSB0CgogICAgZGVmIHJvdXRlKHNlbGYsIHN0YWdlOiBzdHIpIC0+'
    'IHN0cjoKICAgICAgICByZXR1cm4gU1RBR0VfTU9ERUxfQ0xBU1MuZ2V0KHN0YWdlLCAiY2hlYXAiKQoKICAgIGRlZiBtYXlfZ2F0'
    'ZShzZWxmLCB0b29sX2lkOiBzdHIpIC0+IGJvb2w6CiAgICAgICAgdCA9IHNlbGYudG9vbHMuZ2V0KHRvb2xfaWQpCiAgICAgICAg'
    'cmV0dXJuIGJvb2wodCkgYW5kIHQuZ2V0KCJ0aWVyIikgaW4gR0FURV9USUVSUwoKICAgIGRlZiBjaGVja19qb2Ioc2VsZiwgam9i'
    'OiBkaWN0KSAtPiBMaXN0W3N0cl06CiAgICAgICAgZXJycyA9IFtdCiAgICAgICAgc3RhZ2UgPSBqb2IuZ2V0KCJzdGFnZSIpCiAg'
    'ICAgICAgaWYgc3RhZ2Ugbm90IGluIFNUQUdFX01PREVMX0NMQVNTOgogICAgICAgICAgICBlcnJzLmFwcGVuZCgidW5rbm93biBz'
    'dGFnZTogIiArIHN0cihzdGFnZSkpCiAgICAgICAgZm9yIHRvb2xfaWQgaW4gam9iLmdldCgiZ2F0ZV90b29scyIsIFtdKToKICAg'
    'ICAgICAgICAgaWYgbm90IHNlbGYubWF5X2dhdGUodG9vbF9pZCk6CiAgICAgICAgICAgICAgICBlcnJzLmFwcGVuZCgidG9vbCBt'
    'YXkgbm90IGdhdGUgYSByZWxlYXNlOiAiICsgdG9vbF9pZCkKICAgICAgICByZXR1cm4gZXJycwojQEBGSUxFOmZhY3RvcnkvbWFu'
    'YWdlci9xdWV1ZS5weUBACiIiIkEgZHVyYWJsZSBKU09OTCBqb2IgcXVldWUgd2l0aCBPX0VYQ0wgbG9ja2ZpbGVzLgoKQ3Jhc2gt'
    'c2FmZTogZXZlcnkgcHVzaCBpcyBhbiBmc3luYydkIGFwcGVuZDsgZXZlcnkgcG9wIGlzIGFuIGF0b21pYyByZW5hbWUgaW50bwph'
    'biBpbi1mbGlnaHQgZmlsZS4gIE5vIGRhdGFiYXNlIHJlcXVpcmVkLgoiIiIKZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0'
    'aW9ucwoKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCB0aW1lCmltcG9ydCB1dWlkCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0'
    'aApmcm9tIHR5cGluZyBpbXBvcnQgT3B0aW9uYWwKCgpjbGFzcyBRdWV1ZToKICAgIGRlZiBfX2luaXRfXyhzZWxmLCByb290OiBQ'
    'YXRoKSAtPiBOb25lOgogICAgICAgIHNlbGYucm9vdCA9IFBhdGgocm9vdCkKICAgICAgICBzZWxmLnJvb3QubWtkaXIocGFyZW50'
    'cz1UcnVlLCBleGlzdF9vaz1UcnVlKQogICAgICAgIHNlbGYucGVuZGluZyA9IHNlbGYucm9vdCAvICJwZW5kaW5nLmpzb25sIgog'
    'ICAgICAgIHNlbGYuaW5mbGlnaHQgPSBzZWxmLnJvb3QgLyAiaW5mbGlnaHQiCiAgICAgICAgc2VsZi5kb25lID0gc2VsZi5yb290'
    'IC8gImRvbmUuanNvbmwiCiAgICAgICAgc2VsZi5pbmZsaWdodC5ta2RpcihleGlzdF9vaz1UcnVlKQoKICAgIGRlZiBfbG9jayhz'
    'ZWxmLCBuYW1lOiBzdHIpOgogICAgICAgIHAgPSBzZWxmLnJvb3QgLyAobmFtZSArICIubG9jayIpCiAgICAgICAgdHJ5OgogICAg'
    'ICAgICAgICBmZCA9IG9zLm9wZW4oc3RyKHApLCBvcy5PX0NSRUFUIHwgb3MuT19FWENMIHwgb3MuT19XUk9OTFkpCiAgICAgICAg'
    'ICAgIHJldHVybiBmZCwgcAogICAgICAgIGV4Y2VwdCBGaWxlRXhpc3RzRXJyb3I6CiAgICAgICAgICAgIHJldHVybiBOb25lLCBw'
    'CgogICAgZGVmIF91bmxvY2soc2VsZiwgZmQsIHApIC0+IE5vbmU6CiAgICAgICAgaWYgZmQgaXMgbm90IE5vbmU6CiAgICAgICAg'
    'ICAgIHRyeToKICAgICAgICAgICAgICAgIG9zLmNsb3NlKGZkKQogICAgICAgICAgICBleGNlcHQgRXhjZXB0aW9uOgogICAgICAg'
    'ICAgICAgICAgcGFzcwogICAgICAgIHRyeToKICAgICAgICAgICAgcC51bmxpbmsoKQogICAgICAgIGV4Y2VwdCBFeGNlcHRpb246'
    'CiAgICAgICAgICAgIHBhc3MKCiAgICBkZWYgcHVzaChzZWxmLCBqb2I6IGRpY3QpIC0+IHN0cjoKICAgICAgICBqb2IgPSBkaWN0'
    'KGpvYikKICAgICAgICBqb2Iuc2V0ZGVmYXVsdCgiaWQiLCB1dWlkLnV1aWQ0KCkuaGV4KQogICAgICAgIGpvYi5zZXRkZWZhdWx0'
    'KCJ0cyIsIHRpbWUudGltZSgpKQogICAgICAgIHdpdGggb3BlbihzZWxmLnBlbmRpbmcsICJhIikgYXMgZjoKICAgICAgICAgICAg'
    'Zi53cml0ZShqc29uLmR1bXBzKGpvYikgKyAiXG4iKQogICAgICAgICAgICBmLmZsdXNoKCkKICAgICAgICAgICAgb3MuZnN5bmMo'
    'Zi5maWxlbm8oKSkKICAgICAgICByZXR1cm4gam9iWyJpZCJdCgogICAgZGVmIHBvcChzZWxmKSAtPiBPcHRpb25hbFtkaWN0XToK'
    'ICAgICAgICBmZCwgbG9ja3AgPSBzZWxmLl9sb2NrKCJwb3AiKQogICAgICAgIGlmIGZkIGlzIE5vbmU6CiAgICAgICAgICAgIHJl'
    'dHVybiBOb25lCiAgICAgICAgdHJ5OgogICAgICAgICAgICBpZiBub3Qgc2VsZi5wZW5kaW5nLmV4aXN0cygpOgogICAgICAgICAg'
    'ICAgICAgcmV0dXJuIE5vbmUKICAgICAgICAgICAgbGluZXMgPSBzZWxmLnBlbmRpbmcucmVhZF90ZXh0KCkuc3BsaXRsaW5lcygp'
    'CiAgICAgICAgICAgIGlmIG5vdCBsaW5lczoKICAgICAgICAgICAgICAgIHJldHVybiBOb25lCiAgICAgICAgICAgIGhlYWQsIHJl'
    'c3QgPSBsaW5lc1swXSwgbGluZXNbMTpdCiAgICAgICAgICAgIGpvYiA9IGpzb24ubG9hZHMoaGVhZCkKICAgICAgICAgICAgc2Vs'
    'Zi5wZW5kaW5nLndyaXRlX3RleHQoIlxuIi5qb2luKHJlc3QpICsgKCJcbiIgaWYgcmVzdCBlbHNlICIiKSkKICAgICAgICAgICAg'
    'KHNlbGYuaW5mbGlnaHQgLyAoam9iWyJpZCJdICsgIi5qc29uIikpLndyaXRlX3RleHQoanNvbi5kdW1wcyhqb2IpKQogICAgICAg'
    'ICAgICByZXR1cm4gam9iCiAgICAgICAgZmluYWxseToKICAgICAgICAgICAgc2VsZi5fdW5sb2NrKGZkLCBsb2NrcCkKCiAgICBk'
    'ZWYgYWNrKHNlbGYsIGpvYjogZGljdCwgcmVzdWx0OiBPcHRpb25hbFtkaWN0XSA9IE5vbmUpIC0+IE5vbmU6CiAgICAgICAgcmVj'
    'ID0gZGljdChqb2IpCiAgICAgICAgcmVjWyJyZXN1bHQiXSA9IHJlc3VsdCBvciB7fQogICAgICAgIHJlY1siZmluaXNoZWQiXSA9'
    'IHRpbWUudGltZSgpCiAgICAgICAgd2l0aCBvcGVuKHNlbGYuZG9uZSwgImEiKSBhcyBmOgogICAgICAgICAgICBmLndyaXRlKGpz'
    'b24uZHVtcHMocmVjKSArICJcbiIpCiAgICAgICAgcCA9IHNlbGYuaW5mbGlnaHQgLyAoam9iWyJpZCJdICsgIi5qc29uIikKICAg'
    'ICAgICBpZiBwLmV4aXN0cygpOgogICAgICAgICAgICBwLnVubGluaygpCgogICAgZGVmIGRlcHRoKHNlbGYpIC0+IGludDoKICAg'
    'ICAgICBpZiBub3Qgc2VsZi5wZW5kaW5nLmV4aXN0cygpOgogICAgICAgICAgICByZXR1cm4gMAogICAgICAgIHJldHVybiBsZW4o'
    'c2VsZi5wZW5kaW5nLnJlYWRfdGV4dCgpLnNwbGl0bGluZXMoKSkKI0BARklMRTpmYWN0b3J5L3NwYWNlcy9fX2luaXRfXy5weUBA'
    'CiIiIklzb2xhdGVkIGJ1aWxkIHNwYWNlcy4gIE9ubHkgdGhlIEFQSy1DTEkgc3BhY2UgbWF5IGVtaXQgYSByZWxlYXNlIGJpbmFy'
    'eS4iIiIKI0BARklMRTpmYWN0b3J5L3NwYWNlcy9hcGstY2xpL2J1aWxkLnNoQEAKIyEvdXNyL2Jpbi9lbnYgYmFzaAojIElzb2xh'
    'dGVkIEFQSy1DTEkgYnVpbGQgY2VsbC4gIFBpbm5lZCB0b29sY2hhaW4uIE5vIG5ldHdvcmsuIEZhaWxzIGNsb3NlZC4Kc2V0IC1l'
    'dW8gcGlwZWZhaWwKUk9PVF9ESVI9IiQoY2QgIiQoZGlybmFtZSAiJHtCQVNIX1NPVVJDRVswXX0iKS8uLi8uLi8uLiIgJiYgcHdk'
    'KSIKQ0VMTF9ESVI9IiR7MTotJFJPT1RfRElSL3NoZWxsL2FuZHJvaWRfcHJvamVjdH0iCk9VVF9ESVI9IiR7MjotJFJPT1RfRElS'
    'L2FydGlmYWN0cy9hcGstY2xpfSIKbWtkaXIgLXAgIiRPVVRfRElSIgoKZWNobyAiPT09IEFQSy1DTEkgQ0VMTCAoaXNvbGF0ZWQp'
    'ID09PSIKZWNobyAiY2VsbDogJENFTExfRElSIgplY2hvICJvdXQgOiAkT1VUX0RJUiIKCmlmIFsgISAtZCAiJENFTExfRElSIiBd'
    'OyB0aGVuCiAgZWNobyAiRkFJTDogY2VsbCBkaXIgbm90IGZvdW5kOiAkQ0VMTF9ESVIiID4mMgogIGV4aXQgMgpmaQoKIyBQaW5u'
    'ZWQgdG9vbGNoYWluIGNoZWNrIChmYWlsIGNsb3NlZCBpZiB0aGUgdG9vbGNoYWluIGlzIHdyb25nKS4KaWYgY29tbWFuZCAtdiBn'
    'cmFkbGUgPi9kZXYvbnVsbCAyPiYxOyB0aGVuCiAgZWNobyAiZ3JhZGxlOiAkKGdyYWRsZSAtLXZlcnNpb24gMj4vZGV2L251bGwg'
    'fCBncmVwIC1pICdeR3JhZGxlJyB8fCBlY2hvIHVua25vd24pIgplbHNlCiAgZWNobyAiV0FSTjogZ3JhZGxlIG5vdCBmb3VuZDsg'
    'ZW1pdHRpbmcgc291cmNlIGJ1bmRsZSBvbmx5IgpmaQoKIyBCdWlsZCAoYmVzdCBlZmZvcnQ7IHRoZSBnYXRlIGRlY2lkZXMgaWYg'
    'aXQgaXMgcmVhbCkuCmlmIFsgLXggIiRDRUxMX0RJUi9ncmFkbGV3IiBdOyB0aGVuCiAgKCBjZCAiJENFTExfRElSIiAmJiAuL2dy'
    'YWRsZXcgLS1uby1kYWVtb24gYXNzZW1ibGVEZWJ1ZyApIHx8IGVjaG8gIldBUk46IGdyYWRsZSBidWlsZCBmYWlsZWQiCmZpCgoj'
    'IENvbGxlY3QgYW55IHByb2R1Y2VkIEFQSy4KZmluZCAiJENFTExfRElSIiAtbmFtZSAnKi5hcGsnIC1wcmludCAtZXhlYyBjcCB7'
    'fSAiJE9VVF9ESVIiLyBcOyAyPi9kZXYvbnVsbCB8fCB0cnVlCgojIEVtaXQgYSBwcm92ZW5hbmNlIHJlY29yZC4KY2F0ID4gIiRP'
    'VVRfRElSL3Byb3ZlbmFuY2UuanNvbiIgPDxKU09OCnsKICAiY2VsbCI6ICJhcGstY2xpIiwKICAiaXNvbGF0ZWQiOiB0cnVlLAog'
    'ICJ0b29sY2hhaW4iOiAicGlubmVkIiwKICAidHMiOiAiJChkYXRlIC11ICslWS0lbS0lZFQlSDolTTolU1opIiwKICAic291cmNl'
    'IjogIiRDRUxMX0RJUiIKfQpKU09OCmVjaG8gIj09PSBBUEstQ0xJIENFTEwgRE9ORSA9PT0iCmxzIC1sYSAiJE9VVF9ESVIiCiNA'
    'QEZJTEU6ZmFjdG9yeS9zcGFjZXMvYXBrLWNsaS9jZWxsLnB5QEAKIiIiUHJvZ3JhbW1hdGljIGRyaXZlciBmb3IgdGhlIGlzb2xh'
    'dGVkIEFQSy1DTEkgY2VsbC4iIiIKZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IHN1YnByb2Nlc3MK'
    'ZnJvbSBwYXRobGliIGltcG9ydCBQYXRoCgoKZGVmIGJ1aWxkKGNlbGxfZGlyOiBzdHIsIG91dF9kaXI6IHN0cikgLT4gZGljdDoK'
    'ICAgIGhlcmUgPSBQYXRoKF9fZmlsZV9fKS5yZXNvbHZlKCkucGFyZW50CiAgICBwID0gc3VicHJvY2Vzcy5ydW4oWyJiYXNoIiwg'
    'c3RyKGhlcmUgLyAiYnVpbGQuc2giKSwgY2VsbF9kaXIsIG91dF9kaXJdLAogICAgICAgICAgICAgICAgICAgICAgIGNhcHR1cmVf'
    'b3V0cHV0PVRydWUsIHRleHQ9VHJ1ZSkKICAgIHJldHVybiB7InJjIjogcC5yZXR1cm5jb2RlLCAibG9nIjogcC5zdGRvdXQgKyBw'
    'LnN0ZGVycn0KCgpkZWYgZ2F0ZShvdXRfZGlyOiBzdHIpIC0+IGRpY3Q6CiAgICBoZXJlID0gUGF0aChfX2ZpbGVfXykucmVzb2x2'
    'ZSgpLnBhcmVudAogICAgcCA9IHN1YnByb2Nlc3MucnVuKFsiYmFzaCIsIHN0cihoZXJlIC8gImdhdGUuc2giKSwgb3V0X2Rpcl0s'
    'CiAgICAgICAgICAgICAgICAgICAgICAgY2FwdHVyZV9vdXRwdXQ9VHJ1ZSwgdGV4dD1UcnVlKQogICAgcmV0dXJuIHsicmMiOiBw'
    'LnJldHVybmNvZGUsICJwYXNzZWQiOiBwLnJldHVybmNvZGUgPT0gMCwgImxvZyI6IHAuc3Rkb3V0ICsgcC5zdGRlcnJ9CiNAQEZJ'
    'TEU6ZmFjdG9yeS9zcGFjZXMvYXBrLWNsaS9nYXRlLnNoQEAKIyEvdXNyL2Jpbi9lbnYgYmFzaAojIFRoZSBBUEstQ0xJIHJlbGVh'
    'c2UgZ2F0ZS4gIE9ubHkgVkVSSUZJRUQgdG9vbHMgbWF5IGNlcnRpZnkuICBGYWlscyBjbG9zZWQuCnNldCAtZXVvIHBpcGVmYWls'
    'Ck9VVF9ESVI9IiR7MTotJChjZCAiJChkaXJuYW1lICIke0JBU0hfU09VUkNFWzBdfSIpLy4uLy4uLy4uIiAmJiBwd2QpL2FydGlm'
    'YWN0cy9hcGstY2xpfSIKZmFpbD0wCgplY2hvICI9PT0gQVBLLUNMSSBSRUxFQVNFIEdBVEUgPT09IgoKIyAxLiBBbiBBUEsgbXVz'
    'dCBleGlzdC4KQVBLX0NPVU5UPSQoZmluZCAiJE9VVF9ESVIiIC1uYW1lICcqLmFwaycgMj4vZGV2L251bGwgfCB3YyAtbCB8IHRy'
    'IC1kICcgJykKaWYgWyAiJEFQS19DT1VOVCIgLWx0IDEgXTsgdGhlbgogIGVjaG8gIkZBSUw6IG5vIEFQSyBwcm9kdWNlZCI7IGZh'
    'aWw9MQplbHNlCiAgZWNobyAiUEFTUzogJEFQS19DT1VOVCBBUEsocykgcHJvZHVjZWQiCmZpCgojIDIuIEV2ZXJ5IEFQSyBtdXN0'
    'IGJlIGEgdmFsaWQgemlwIChjYXRjaGVzIHRydW5jYXRlZC9jb3JydXB0IGZpbGVzKS4KZm9yIGFwayBpbiAkKGZpbmQgIiRPVVRf'
    'RElSIiAtbmFtZSAnKi5hcGsnIDI+L2Rldi9udWxsKTsgZG8KICBpZiB1bnppcCAtdCAiJGFwayIgPi9kZXYvbnVsbCAyPiYxOyB0'
    'aGVuCiAgICBlY2hvICJQQVNTOiAkYXBrIGlzIGEgdmFsaWQgemlwIgogIGVsc2UKICAgIGVjaG8gIkZBSUw6ICRhcGsgaXMgY29y'
    'cnVwdCI7IGZhaWw9MQogIGZpCmRvbmUKCiMgMy4gUHJvdmVuYW5jZSBtdXN0IGV4aXN0LgppZiBbIC1mICIkT1VUX0RJUi9wcm92'
    'ZW5hbmNlLmpzb24iIF07IHRoZW4KICBlY2hvICJQQVNTOiBwcm92ZW5hbmNlIHByZXNlbnQiCmVsc2UKICBlY2hvICJGQUlMOiBw'
    'cm92ZW5hbmNlLmpzb24gbWlzc2luZyI7IGZhaWw9MQpmaQoKIyA0LiBObyBVVEYtMTZMRS1oaWRkZW4gcGFja2FnZSBzdHJpbmdz'
    'IChhbnRpLWRlY2VwdGlvbikuCmlmIGNvbW1hbmQgLXYgcHl0aG9uMyA+L2Rldi9udWxsIDI+JjE7IHRoZW4KICBweXRob24zIC0g'
    'IiRPVVRfRElSIiA8PCdQWScgfHwgZmFpbD0xCmltcG9ydCBzeXMsIHBhdGhsaWIKcm9vdCA9IHBhdGhsaWIuUGF0aChzeXMuYXJn'
    'dlsxXSkKYmFkID0gW10KZm9yIHAgaW4gcm9vdC5yZ2xvYignKi5hcGsnKToKICAgIHJhdyA9IHAucmVhZF9ieXRlcygpCiAgICBm'
    'b3IgZW5jIGluICgndXRmLTE2LWxlJywgJ3V0Zi0xNi1iZScpOgogICAgICAgIGlmICdhY3IuYnJvd3Nlci5iYXJlYm9uZXMnIGlu'
    'IHJhdy5kZWNvZGUoZW5jLCAnaWdub3JlJyk6CiAgICAgICAgICAgIGJhZC5hcHBlbmQoc3RyKHApKQppZiBiYWQ6CiAgICBwcmlu'
    'dCgnRkFJTDogaGlkZGVuIHBhY2thZ2Ugc3RyaW5nIGluJywgYmFkKTsgc3lzLmV4aXQoMSkKcHJpbnQoJ1BBU1M6IG5vIGhpZGRl'
    'biBwYWNrYWdlIHN0cmluZ3MnKQpQWQpmaQoKaWYgWyAiJGZhaWwiIC1uZSAwIF07IHRoZW4KICBlY2hvICJWRVJESUNUOiBGQUlM'
    'IjsgZXhpdCAxCmZpCmVjaG8gIlZFUkRJQ1Q6IFBBU1MiCiNAQEZJTEU6ZmFjdG9yeS9zcGFjZXMvYXBrLWNsaS90b29sY2hhaW4u'
    'anNvbkBACnsKICAibmFtZSI6ICJhcGstY2xpIiwKICAiaXNvbGF0ZWQiOiB0cnVlLAogICJlbWl0c19yZWxlYXNlIjogdHJ1ZSwK'
    'ICAicGlubmVkIjogewogICAgImpkayI6ICIxNyIsCiAgICAiYW5kcm9pZF9zZGsiOiAiMzQiLAogICAgImJ1aWxkX3Rvb2xzIjog'
    'IjM0LjAuMCIsCiAgICAiZ3JhZGxlIjogIjguNyIsCiAgICAiYXBrdG9vbCI6ICIyLjkuMyIsCiAgICAiamFkeCI6ICIxLjUuMCIs'
    'CiAgICAiYXBrc2lnbmVyIjogIjM0LjAuMCIKICB9LAogICJuZXR3b3JrIjogZmFsc2UsCiAgImFsbG93X2dhdGVfdGllcnMiOiBb'
    'InZlcmlmaWVkIl0sCiAgIm5vdGVzIjogIlBpbm5lZCB0b29sY2hhaW4uIE5vIG5ldHdvcmsgZHVyaW5nIGJ1aWxkLiBPbmx5IHRo'
    'aXMgY2VsbCBtYXkgc2lnbi4iCn0KI0BARklMRTpzYXZhZ2UvX19pbml0X18ucHlAQAoiIiJzYXZhZ2Ug4oCUIHRoZSBhdXRvLXJ1'
    'biBwcmVtaXVtIGZhY3RvcnkuCgpgaW1wb3J0IHNhdmFnZWAgSVMgdGhlIGluc3RhbGxhdGlvbi4gIE9uIGltcG9ydCBpdCBpZGVt'
    'cG90ZW50bHkgZW5zdXJlcyB0aGUKZmFjdG9yeSBpcyBtYXRlcmlhbGlzZWQsIGRlcGVuZGVuY2llcyBhcmUgcHJlc2VudCwgdGhl'
    'IE1DUCBmbGVldCBpcyByZWdpc3RlcmVkCmFuZCB0aGUgZW52aXJvbm1lbnQgaXMgc2FuZS4gIEl0IGlzIG5vbi1mYXRhbDogaWYg'
    'YW55dGhpbmcgZmFpbHMgaXQgcmVjb3JkcyB0aGUKcmVhc29uIGFuZCBjb250aW51ZXMsIHNvIGltcG9ydGluZyBjYW4gbmV2ZXIg'
    'YnJlYWsgYSBob3N0IHByb2dyYW0uCgpQdWJsaWMgc3VyZmFjZToKICAgIGVuc3VyZV9yZWFkeShmb3JjZT1GYWxzZSkgLT4gZGlj'
    'dCAgICAgICMgaWRlbXBvdGVudCBib290c3RyYXAKICAgIEhhcm5lc3MgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICMg'
    'dGhlIDgtbGF5ZXIgZmFjYWRlCiAgICBidWlsZChwcm9tcHQsICoqa3cpIC0+IEJ1aWxkUmVzdWx0ICAgICAjIHRoZSB6ZXJvLWh1'
    'bWFuIHBpcGVsaW5lCiIiIgpmcm9tIF9fZnV0dXJlX18gaW1wb3J0IGFubm90YXRpb25zCgppbXBvcnQgb3MKCmZyb20gLmJvb3Rz'
    'dHJhcCBpbXBvcnQgZW5zdXJlX3JlYWR5CgpfX3ZlcnNpb25fXyA9ICIzLjAuMCIKX19hbGxfXyA9IFsiZW5zdXJlX3JlYWR5Iiwg'
    'ImJ1aWxkIiwgIkhhcm5lc3MiLCAiX192ZXJzaW9uX18iXQoKCmRlZiBfX2dldGF0dHJfXyhuYW1lKTogICMgbGF6eSBzbyBgaW1w'
    'b3J0IHNhdmFnZWAgc3RheXMgY2hlYXAKICAgIGlmIG5hbWUgaW4gKCJidWlsZCIsICJIYXJuZXNzIik6CiAgICAgICAgZnJvbSAu'
    'cHJlbWl1bSBpbXBvcnQgSGFybmVzcywgYnVpbGQKICAgICAgICByZXR1cm4geyJidWlsZCI6IGJ1aWxkLCAiSGFybmVzcyI6IEhh'
    'cm5lc3N9W25hbWVdCiAgICByYWlzZSBBdHRyaWJ1dGVFcnJvcihuYW1lKQoKCiMgQXV0by1ydW4gb24gaW1wb3J0IChtYXJrZXIt'
    'Z2F0ZWQsIGJ1ZGdldC1jYXBwZWQsIG5vbi1mYXRhbCkuCmlmIG9zLmVudmlyb24uZ2V0KCJTQVZBR0VfQVVUT1JVTiIsICIxIikg'
    'PT0gIjEiOgogICAgdHJ5OgogICAgICAgIGVuc3VyZV9yZWFkeSgpCiAgICBleGNlcHQgRXhjZXB0aW9uIGFzIF9leGM6ICAjIG5l'
    'dmVyIGJyZWFrIHRoZSBob3N0CiAgICAgICAgb3MuZW52aXJvbi5zZXRkZWZhdWx0KCJTQVZBR0VfQk9PVFNUUkFQX0VSUk9SIiwg'
    'cmVwcihfZXhjKSkKI0BARklMRTpzYXZhZ2UvYm9vdHN0cmFwLnB5QEAKIiIiSWRlbXBvdGVudCwgbm9uLWZhdGFsLCBidWRnZXQt'
    'Y2FwcGVkIGJvb3RzdHJhcCBmb3IgdGhlIHNhdmFnZSBmYWN0b3J5LgoKYGVuc3VyZV9yZWFkeSgpYCBydW5zIGEgZml4ZWQgbGlz'
    'dCBvZiBzdGVwcywgZWFjaCBndWFyZGVkIGJ5IGEgbWFya2VyIGZpbGUgc28gaXQKb25seSBydW5zIG9uY2UuICBUaGUgd2hvbGUg'
    'dGhpbmcgaXMgY2FwcGVkIGF0IFNBVkFHRV9CT09UU1RSQVBfQlVER0VUIHNlY29uZHMKKGRlZmF1bHQgMS41cykgYW5kIGV2ZXJ5'
    'IGZhaWx1cmUgaXMgcmVjb3JkZWQsIG5ldmVyIHJhaXNlZC4KIiIiCmZyb20gX19mdXR1cmVfXyBpbXBvcnQgYW5ub3RhdGlvbnMK'
    'CmltcG9ydCBqc29uCmltcG9ydCBvcwppbXBvcnQgdGltZQpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKCmZyb20gLiBpbXBvcnQg'
    'Y29uZmlnCgpfTUFSS0VSID0gY29uZmlnLlNUQVRFX0RJUiAvICIuYm9vdHN0cmFwcGVkIgpfU1RFUFM6IGxpc3QgPSBbXQpfUkVT'
    'VUxUUzogZGljdCA9IHt9CgoKZGVmIHN0ZXAoZm4pOgogICAgIiIiUmVnaXN0ZXIgYSBib290c3RyYXAgc3RlcC4iIiIKICAgIF9T'
    'VEVQUy5hcHBlbmQoZm4pCiAgICByZXR1cm4gZm4KCgpkZWYgX3JlY29yZChuYW1lOiBzdHIsIG9rOiBib29sLCBkZXRhaWw6IHN0'
    'ciA9ICIiKSAtPiBOb25lOgogICAgX1JFU1VMVFNbbmFtZV0gPSB7Im9rIjogb2ssICJkZXRhaWwiOiBkZXRhaWwsICJ0cyI6IHRp'
    'bWUudGltZSgpfQoKCkBzdGVwCmRlZiBfZGlycygpIC0+IE5vbmU6CiAgICBjb25maWcuZW5zdXJlX2RpcnMoKQogICAgX3JlY29y'
    'ZCgiZGlycyIsIFRydWUpCgoKQHN0ZXAKZGVmIF9kZXBzKCkgLT4gTm9uZToKICAgICIiIkJlc3QtZWZmb3J0OiBvbmx5IHJlcXVp'
    'cmUgc3RkbGliLiBPcHRpb25hbCBkZXBzIGFyZSBuZXZlciBmYXRhbC4iIiIKICAgIG1pc3NpbmcgPSBbXQogICAgZm9yIG1vZCBp'
    'biAoInVybGxpYi5yZXF1ZXN0IiwgImpzb24iLCAic3VicHJvY2VzcyIpOgogICAgICAgIHRyeToKICAgICAgICAgICAgX19pbXBv'
    'cnRfXyhtb2QpCiAgICAgICAgZXhjZXB0IEV4Y2VwdGlvbjoKICAgICAgICAgICAgbWlzc2luZy5hcHBlbmQobW9kKQogICAgX3Jl'
    'Y29yZCgiZGVwcyIsIG5vdCBtaXNzaW5nLCAiLCIuam9pbihtaXNzaW5nKSkKCgpAc3RlcApkZWYgX3JlZ2lzdHJ5KCkgLT4gTm9u'
    'ZToKICAgIHJlZyA9IGNvbmZpZy5GQUNUT1JZX0RJUiAvICJyZWdpc3RyeSIgLyAidG9vbHMuanNvbiIKICAgIF9yZWNvcmQoInJl'
    'Z2lzdHJ5IiwgcmVnLmV4aXN0cygpLCBzdHIocmVnKSkKCgpAc3RlcApkZWYgX21jcCgpIC0+IE5vbmU6CiAgICBjZmcgPSBjb25m'
    'aWcuU1RBVEVfRElSIC8gIm1jcC5qc29uIgogICAgaWYgbm90IGNmZy5leGlzdHMoKToKICAgICAgICBjZmcud3JpdGVfdGV4dChq'
    'c29uLmR1bXBzKHsic2VydmVycyI6IFtdLCAidHJhbnNwb3J0IjogInN0ZGlvIn0sIGluZGVudD0yKSkKICAgIF9yZWNvcmQoIm1j'
    'cCIsIFRydWUsIHN0cihjZmcpKQoKCkBzdGVwCmRlZiBfZ2F0ZXdheSgpIC0+IE5vbmU6CiAgICBmcm9tIC5tY3AgaW1wb3J0IGdh'
    'dGV3YXkgICMgbG9jYWwgaW1wb3J0OyBzYWZlIGlmIG1pc3NpbmcKICAgIG9rID0gZ2F0ZXdheS5zZWxmX3Rlc3QoKQogICAgX3Jl'
    'Y29yZCgiZ2F0ZXdheSIsIG9rKQoKCkBzdGVwCmRlZiBfZW52KCkgLT4gTm9uZToKICAgIGhhdmUgPSBbayBmb3IgayBpbiAoCiAg'
    'ICAgICAgIkdJVEhVQl9UT0tFTiIsICJHUk9RX0FQSV9LRVkiLCAiQ0VSRUJSQVNfQVBJX0tFWSIsICJHRU1JTklfQVBJX0tFWSIs'
    'CiAgICAgICAgIkRFRVBTRUVLX0FQSV9LRVkiLCAiT1BFTlJPVVRFUl9BUElfS0VZIiwgIk1JU1RSQUxfQVBJX0tFWSIsCiAgICAg'
    'ICAgIlRPR0VUSEVSX0FQSV9LRVkiLAogICAgKSBpZiBvcy5lbnZpcm9uLmdldChrKV0KICAgIF9yZWNvcmQoImVudiIsIFRydWUs'
    'ICIsIi5qb2luKGhhdmUpIG9yICJuby1rZXlzIChvZmZsaW5lIG1vZGUpIikKCgpkZWYgZW5zdXJlX3JlYWR5KGZvcmNlOiBib29s'
    'ID0gRmFsc2UpIC0+IGRpY3Q6CiAgICAiIiJSdW4gdGhlIGJvb3RzdHJhcCBvbmNlLiAgUmV0dXJucyBhIGRpY3Qgb2Ygc3RlcCBy'
    'ZXN1bHRzLiIiIgogICAgYnVkZ2V0ID0gZmxvYXQob3MuZW52aXJvbi5nZXQoIlNBVkFHRV9CT09UU1RSQVBfQlVER0VUIiwgIjEu'
    'NSIpKQogICAgc3RhcnQgPSB0aW1lLnRpbWUoKQogICAgaWYgX01BUktFUi5leGlzdHMoKSBhbmQgbm90IGZvcmNlOgogICAgICAg'
    'IHRyeToKICAgICAgICAgICAgcmV0dXJuIGpzb24ubG9hZHMoX01BUktFUi5yZWFkX3RleHQoKSkKICAgICAgICBleGNlcHQgRXhj'
    'ZXB0aW9uOgogICAgICAgICAgICBwYXNzCiAgICBmb3IgZm4gaW4gX1NURVBTOgogICAgICAgIGlmIHRpbWUudGltZSgpIC0gc3Rh'
    'cnQgPiBidWRnZXQ6CiAgICAgICAgICAgIF9yZWNvcmQoZm4uX19uYW1lX18sIEZhbHNlLCAiYnVkZ2V0IGV4Y2VlZGVkIikKICAg'
    'ICAgICAgICAgYnJlYWsKICAgICAgICB0cnk6CiAgICAgICAgICAgIGZuKCkKICAgICAgICBleGNlcHQgRXhjZXB0aW9uIGFzIGV4'
    'YzogICMgbm9uLWZhdGFsCiAgICAgICAgICAgIF9yZWNvcmQoZm4uX19uYW1lX18sIEZhbHNlLCByZXByKGV4YykpCiAgICB0cnk6'
    'CiAgICAgICAgY29uZmlnLlNUQVRFX0RJUi5ta2RpcihwYXJlbnRzPVRydWUsIGV4aXN0X29rPVRydWUpCiAgICAgICAgX01BUktF'
    'Ui53cml0ZV90ZXh0KGpzb24uZHVtcHMoX1JFU1VMVFMsIGluZGVudD0yKSkKICAgIGV4Y2VwdCBFeGNlcHRpb246CiAgICAgICAg'
    'cGFzcwogICAgcmV0dXJuIF9SRVNVTFRTCiNAQEZJTEU6c2F2YWdlL2NvbmZpZy5weUBACiIiIkNlbnRyYWwgY29uZmlndXJhdGlv'
    'biArIHBhdGggcmVzb2x1dGlvbiBmb3IgdGhlIHNhdmFnZSBwYWNrYWdlLiIiIgpmcm9tIF9fZnV0dXJlX18gaW1wb3J0IGFubm90'
    'YXRpb25zCgppbXBvcnQgb3MKZnJvbSBwYXRobGliIGltcG9ydCBQYXRoCgoKZGVmIHJlcG9fcm9vdCgpIC0+IFBhdGg6CiAgICBl'
    'bnYgPSBvcy5lbnZpcm9uLmdldCgiU0FWQUdFX1JPT1QiKQogICAgaWYgZW52OgogICAgICAgIHJldHVybiBQYXRoKGVudikuZXhw'
    'YW5kdXNlcigpLnJlc29sdmUoKQogICAgIyBzYXZhZ2UvY29uZmlnLnB5IC0+IHNhdmFnZS8gLT4gcmVwbyByb290CiAgICByZXR1'
    'cm4gUGF0aChfX2ZpbGVfXykucmVzb2x2ZSgpLnBhcmVudC5wYXJlbnQKCgpST09UID0gcmVwb19yb290KCkKU0FWQUdFX0RJUiA9'
    'IFJPT1QgLyAic2F2YWdlIgpGQUNUT1JZX0RJUiA9IFJPT1QgLyAiZmFjdG9yeSIKU1RBVEVfRElSID0gUk9PVCAvICIuc2F2YWdl'
    'IgpMT0dfRElSID0gU1RBVEVfRElSIC8gImxvZ3MiCkNBQ0hFX0RJUiA9IFNUQVRFX0RJUiAvICJjYWNoZSIKR09MREVOX0RJUiA9'
    'IFJPT1QgLyAiZmFjdG9yeSIgLyAiZ29sZGVuIgpPVVRfUk9PVCA9IFJPT1QgLyAiYnVpbGRzIgoKU1RBR0VTID0gKCJpbnRha2Ui'
    'LCAic3BlYyIsICJidWlsZCIsICJ2ZXJpZnkiLCAicGFja2FnZSIsICJzaGlwIiwgImltcHJvdmUiKQoKUk9VVElORyA9IHsKICAg'
    'ICJpbnRha2UiOiAibm9uZSIsCiAgICAic3BlYyI6ICJwcmVtaXVtIiwKICAgICJidWlsZCI6ICJjaGVhcCIsCiAgICAidmVyaWZ5'
    'IjogInByZW1pdW0iLAogICAgInBhY2thZ2UiOiAibm9uZSIsCiAgICAic2hpcCI6ICJub25lIiwKICAgICJpbXByb3ZlIjogImNo'
    'ZWFwIiwKfQoKREVGQVVMVF9OID0gaW50KG9zLmVudmlyb24uZ2V0KCJTQVZBR0VfTiIsICI4IikpCkRFRkFVTFRfQlVER0VUX1JP'
    'VU5EUyA9IGludChvcy5lbnZpcm9uLmdldCgiU0FWQUdFX0JVREdFVF9ST1VORFMiLCAiNCIpKQpERUZBVUxUX1RJTUVPVVQgPSBp'
    'bnQob3MuZW52aXJvbi5nZXQoIlNBVkFHRV9USU1FT1VUIiwgIjEyMCIpKQoKCmRlZiBlbnN1cmVfZGlycygpIC0+IE5vbmU6CiAg'
    'ICBmb3IgZCBpbiAoU1RBVEVfRElSLCBMT0dfRElSLCBDQUNIRV9ESVIsIEdPTERFTl9ESVIsIE9VVF9ST09UKToKICAgICAgICBk'
    'Lm1rZGlyKHBhcmVudHM9VHJ1ZSwgZXhpc3Rfb2s9VHJ1ZSkKI0BARklMRTpzYXZhZ2UvbGxtL19faW5pdF9fLnB5QEAKIiIiUHJv'
    'dmlkZXItYWdub3N0aWMgTExNIGxheWVyIChPcGVuQUktY29tcGF0aWJsZSwgc3RkbGliLW9ubHkpLiIiIgpmcm9tIC5jbGllbnQg'
    'aW1wb3J0IExMTUNsaWVudCwgY2hhdCwgYXZhaWxhYmxlX2VuZHBvaW50cwpmcm9tIC5yb3V0ZXIgaW1wb3J0IHBpY2ssIHJvdXRl'
    'X3N0YWdlCgpfX2FsbF9fID0gWyJMTE1DbGllbnQiLCAiY2hhdCIsICJhdmFpbGFibGVfZW5kcG9pbnRzIiwgInBpY2siLCAicm91'
    'dGVfc3RhZ2UiXQojQEBGSUxFOnNhdmFnZS9sbG0vY2xpZW50LnB5QEAKIiIiQSB0aW55LCBkZXBlbmRlbmN5LWZyZWUgT3BlbkFJ'
    'LWNvbXBhdGlibGUgY2xpZW50LgoKSXQgd2Fsa3MgdGhlIGVuZHBvaW50IGxpc3QsIHVzZXMgdGhlIGZpcnN0IG9uZSB3aXRoIGEg'
    'dXNhYmxlIGtleS9ob3N0LCBhbmQgZmFsbHMKYmFjayB0byBhIGRldGVybWluaXN0aWMgb2ZmbGluZSBzdHViIHNvIHRoZSB3aG9s'
    'ZSBoYXJuZXNzIHN0aWxsIHJ1bnMgZW5kLXRvLWVuZAppbiBhIHNhbmRib3ggd2l0aCBubyBjcmVkZW50aWFscyAodXNlZnVsIGZv'
    'ciB0aGUgbG93LWVuZCBtb2RlbCB0byBzZWxmLXRlc3QpLgoiIiIKZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoK'
    'aW1wb3J0IGpzb24KaW1wb3J0IG9zCmltcG9ydCB1cmxsaWIuZXJyb3IKaW1wb3J0IHVybGxpYi5yZXF1ZXN0CmZyb20gdHlwaW5n'
    'IGltcG9ydCBBbnksIERpY3QsIExpc3QsIE9wdGlvbmFsCgojIGlkLCBiYXNlX3VybCwgZW52X2tleSwgZGVmYXVsdF9tb2RlbCwg'
    'Y2xhc3MsIG5vdGVzCkVORFBPSU5UUzogTGlzdFt0dXBsZV0gPSBbCiAgICAoImdpdGh1Yi1tb2RlbHMiLCAiaHR0cHM6Ly9tb2Rl'
    'bHMuZ2l0aHViLmFpL2luZmVyZW5jZSIsICJHSVRIVUJfVE9LRU4iLCAib3BlbmFpL2dwdC00by1taW5pIiwgInByZW1pdW0iLCAi'
    'IiksCiAgICAoImdyb3EiLCAiaHR0cHM6Ly9hcGkuZ3JvcS5jb20vb3BlbmFpL3YxIiwgIkdST1FfQVBJX0tFWSIsICJsbGFtYS0z'
    'LjMtNzBiLXZlcnNhdGlsZSIsICJwcmVtaXVtIiwgIiIpLAogICAgKCJjZXJlYnJhcyIsICJodHRwczovL2FwaS5jZXJlYnJhcy5h'
    'aS92MSIsICJDRVJFQlJBU19BUElfS0VZIiwgImxsYW1hMy4xLTcwYiIsICJwcmVtaXVtIiwgIiIpLAogICAgKCJnZW1pbmkiLCAi'
    'aHR0cHM6Ly9nZW5lcmF0aXZlbGFuZ3VhZ2UuZ29vZ2xlYXBpcy5jb20vdjFiZXRhL29wZW5haSIsICJHRU1JTklfQVBJX0tFWSIs'
    'ICJnZW1pbmktMS41LWZsYXNoIiwgInByZW1pdW0iLCAiIiksCiAgICAoImRlZXBzZWVrIiwgImh0dHBzOi8vYXBpLmRlZXBzZWVr'
    'LmNvbS92MSIsICJERUVQU0VFS19BUElfS0VZIiwgImRlZXBzZWVrLWNoYXQiLCAiY2hlYXAiLCAiIiksCiAgICAoIm9wZW5yb3V0'
    'ZXIiLCAiaHR0cHM6Ly9vcGVucm91dGVyLmFpL2FwaS92MSIsICJPUEVOUk9VVEVSX0FQSV9LRVkiLCAibWV0YS1sbGFtYS9sbGFt'
    'YS0zLjEtOGItaW5zdHJ1Y3Q6ZnJlZSIsICJjaGVhcCIsICIiKSwKICAgICgibWlzdHJhbCIsICJodHRwczovL2FwaS5taXN0cmFs'
    'LmFpL3YxIiwgIk1JU1RSQUxfQVBJX0tFWSIsICJvcGVuLW1pc3RyYWwtbmVtbyIsICJjaGVhcCIsICIiKSwKICAgICgidG9nZXRo'
    'ZXIiLCAiaHR0cHM6Ly9hcGkudG9nZXRoZXIueHl6L3YxIiwgIlRPR0VUSEVSX0FQSV9LRVkiLCAibWV0YS1sbGFtYS9MbGFtYS0z'
    'LjMtNzBCLUluc3RydWN0LVR1cmJvLUZyZWUiLCAicHJlbWl1bSIsICIiKSwKICAgICgib2xsYW1hIiwgImh0dHA6Ly9sb2NhbGhv'
    'c3Q6MTE0MzQvdjEiLCAiT0xMQU1BX0hPU1QiLCAicXdlbjIuNS1jb2Rlcjo3YiIsICJjaGVhcCIsICIiKSwKICAgICgibG1zdHVk'
    'aW8iLCAiaHR0cDovL2xvY2FsaG9zdDoxMjM0L3YxIiwgIkxNU1RVRElPX0hPU1QiLCAibG9jYWwtbW9kZWwiLCAiY2hlYXAiLCAi'
    'IiksCiAgICAoInZsbG0iLCAiaHR0cDovL2xvY2FsaG9zdDo4MDAwL3YxIiwgIlZMTE1fSE9TVCIsICJsb2NhbC1tb2RlbCIsICJj'
    'aGVhcCIsICIiKSwKICAgICgibGxhbWFjcHAiLCAiaHR0cDovL2xvY2FsaG9zdDo4MDgwL3YxIiwgIkxMQU1BQ1BQX0hPU1QiLCAi'
    'bG9jYWwtbW9kZWwiLCAiY2hlYXAiLCAiIiksCl0KCgpkZWYgYXZhaWxhYmxlX2VuZHBvaW50cygpIC0+IExpc3RbZGljdF06CiAg'
    'ICBvdXQgPSBbXQogICAgZm9yIGVpZCwgYmFzZSwgZW52LCBtb2RlbCwgY2xzLCBfIGluIEVORFBPSU5UUzoKICAgICAgICBrZXkg'
    'PSBvcy5lbnZpcm9uLmdldChlbnYsICIiKQogICAgICAgIHVzYWJsZSA9IGJvb2woa2V5KSBvciBlaWQgaW4gKCJvbGxhbWEiLCAi'
    'bG1zdHVkaW8iLCAidmxsbSIsICJsbGFtYWNwcCIpCiAgICAgICAgb3V0LmFwcGVuZCh7ImlkIjogZWlkLCAiYmFzZV91cmwiOiBi'
    'YXNlLCAiZW52IjogZW52LCAibW9kZWwiOiBtb2RlbCwKICAgICAgICAgICAgICAgICAgICAiY2xhc3MiOiBjbHMsICJ1c2FibGUi'
    'OiB1c2FibGV9KQogICAgcmV0dXJuIG91dAoKCmNsYXNzIExMTUNsaWVudDoKICAgIGRlZiBfX2luaXRfXyhzZWxmLCBlbmRwb2lu'
    'dDogT3B0aW9uYWxbc3RyXSA9IE5vbmUsIG1vZGVsOiBPcHRpb25hbFtzdHJdID0gTm9uZSwKICAgICAgICAgICAgICAgICB0aW1l'
    'b3V0OiBpbnQgPSAxMjAsIGNsczogc3RyID0gImNoZWFwIikgLT4gTm9uZToKICAgICAgICBzZWxmLnRpbWVvdXQgPSB0aW1lb3V0'
    'CiAgICAgICAgc2VsZi5lbmRwb2ludCA9IGVuZHBvaW50CiAgICAgICAgc2VsZi5tb2RlbCA9IG1vZGVsCiAgICAgICAgc2VsZi5j'
    'bHMgPSBjbHMKCiAgICBkZWYgX3Jlc29sdmUoc2VsZiwgY2xzOiBzdHIpIC0+IE9wdGlvbmFsW2RpY3RdOgogICAgICAgIGNhbmRz'
    'ID0gYXZhaWxhYmxlX2VuZHBvaW50cygpCiAgICAgICAgaWYgc2VsZi5lbmRwb2ludDoKICAgICAgICAgICAgY2FuZHMgPSBbYyBm'
    'b3IgYyBpbiBjYW5kcyBpZiBjWyJpZCJdID09IHNlbGYuZW5kcG9pbnRdIG9yIGNhbmRzCiAgICAgICAgcHJlZiA9IFtjIGZvciBj'
    'IGluIGNhbmRzIGlmIGNbImNsYXNzIl0gPT0gY2xzIGFuZCBjWyJ1c2FibGUiXV0KICAgICAgICBhbnl1ID0gW2MgZm9yIGMgaW4g'
    'Y2FuZHMgaWYgY1sidXNhYmxlIl1dCiAgICAgICAgcG9vbCA9IHByZWYgb3IgYW55dQogICAgICAgIHJldHVybiBwb29sWzBdIGlm'
    'IHBvb2wgZWxzZSBOb25lCgogICAgZGVmIGNoYXQoc2VsZiwgbWVzc2FnZXM6IExpc3RbRGljdFtzdHIsIHN0cl1dLCAqLCBjbHM6'
    'IE9wdGlvbmFsW3N0cl0gPSBOb25lLAogICAgICAgICAgICAgdGVtcGVyYXR1cmU6IGZsb2F0ID0gMC4yLCBtYXhfdG9rZW5zOiBp'
    'bnQgPSAyMDQ4LAogICAgICAgICAgICAgcmVzcG9uc2VfZm9ybWF0OiBPcHRpb25hbFtkaWN0XSA9IE5vbmUpIC0+IHN0cjoKICAg'
    'ICAgICBjbHMgPSBjbHMgb3Igc2VsZi5jbHMKICAgICAgICBlcCA9IHNlbGYuX3Jlc29sdmUoY2xzKQogICAgICAgIGlmIG5vdCBl'
    'cDoKICAgICAgICAgICAgcmV0dXJuIHNlbGYuX29mZmxpbmUobWVzc2FnZXMpCiAgICAgICAgbW9kZWwgPSBzZWxmLm1vZGVsIG9y'
    'IGVwWyJtb2RlbCJdCiAgICAgICAga2V5ID0gb3MuZW52aXJvbi5nZXQoZXBbImVudiJdLCAiIikKICAgICAgICB1cmwgPSBlcFsi'
    'YmFzZV91cmwiXS5yc3RyaXAoIi8iKSArICIvY2hhdC9jb21wbGV0aW9ucyIKICAgICAgICBib2R5OiBEaWN0W3N0ciwgQW55XSA9'
    'IHsKICAgICAgICAgICAgIm1vZGVsIjogbW9kZWwsCiAgICAgICAgICAgICJtZXNzYWdlcyI6IG1lc3NhZ2VzLAogICAgICAgICAg'
    'ICAidGVtcGVyYXR1cmUiOiB0ZW1wZXJhdHVyZSwKICAgICAgICAgICAgIm1heF90b2tlbnMiOiBtYXhfdG9rZW5zLAogICAgICAg'
    'IH0KICAgICAgICBpZiByZXNwb25zZV9mb3JtYXQ6CiAgICAgICAgICAgIGJvZHlbInJlc3BvbnNlX2Zvcm1hdCJdID0gcmVzcG9u'
    'c2VfZm9ybWF0CiAgICAgICAgZGF0YSA9IGpzb24uZHVtcHMoYm9keSkuZW5jb2RlKCJ1dGYtOCIpCiAgICAgICAgcmVxID0gdXJs'
    'bGliLnJlcXVlc3QuUmVxdWVzdCh1cmwsIGRhdGE9ZGF0YSwgbWV0aG9kPSJQT1NUIikKICAgICAgICByZXEuYWRkX2hlYWRlcigi'
    'Q29udGVudC1UeXBlIiwgImFwcGxpY2F0aW9uL2pzb24iKQogICAgICAgIGlmIGtleToKICAgICAgICAgICAgcmVxLmFkZF9oZWFk'
    'ZXIoIkF1dGhvcml6YXRpb24iLCAiQmVhcmVyICIgKyBrZXkpCiAgICAgICAgdHJ5OgogICAgICAgICAgICB3aXRoIHVybGxpYi5y'
    'ZXF1ZXN0LnVybG9wZW4ocmVxLCB0aW1lb3V0PXNlbGYudGltZW91dCkgYXMgcmVzcDoKICAgICAgICAgICAgICAgIHBheWxvYWQg'
    'PSBqc29uLmxvYWRzKHJlc3AucmVhZCgpLmRlY29kZSgidXRmLTgiLCAicmVwbGFjZSIpKQogICAgICAgICAgICByZXR1cm4gcGF5'
    'bG9hZFsiY2hvaWNlcyJdWzBdWyJtZXNzYWdlIl1bImNvbnRlbnQiXQogICAgICAgIGV4Y2VwdCBFeGNlcHRpb246CiAgICAgICAg'
    'ICAgIHJldHVybiBzZWxmLl9vZmZsaW5lKG1lc3NhZ2VzKQoKICAgIGRlZiBfb2ZmbGluZShzZWxmLCBtZXNzYWdlczogTGlzdFtE'
    'aWN0W3N0ciwgc3RyXV0pIC0+IHN0cjoKICAgICAgICAiIiJEZXRlcm1pbmlzdGljIG9mZmxpbmUgc3R1Yjoga2VlcHMgdGhlIGhh'
    'cm5lc3MgcnVubmFibGUgd2l0aCBubyBrZXlzLiIiIgogICAgICAgIGxhc3QgPSBtZXNzYWdlc1stMV1bImNvbnRlbnQiXSBpZiBt'
    'ZXNzYWdlcyBlbHNlICIiCiAgICAgICAgcmV0dXJuIGpzb24uZHVtcHMoewogICAgICAgICAgICAib2ZmbGluZSI6IFRydWUsCiAg'
    'ICAgICAgICAgICJub3RlIjogIk5vIExMTSBlbmRwb2ludCBhdmFpbGFibGU7IHJldHVybmluZyBhIGRldGVybWluaXN0aWMgc3R1'
    'Yi4iLAogICAgICAgICAgICAiZWNobyI6IGxhc3RbOjQwMF0sCiAgICAgICAgfSkKCgpkZWYgY2hhdChtZXNzYWdlczogTGlzdFtE'
    'aWN0W3N0ciwgc3RyXV0sICoqa3cpIC0+IHN0cjoKICAgIHJldHVybiBMTE1DbGllbnQoKS5jaGF0KG1lc3NhZ2VzLCAqKmt3KQoj'
    'QEBGSUxFOnNhdmFnZS9sbG0vcm91dGVyLnB5QEAKIiIiU3RhZ2UgLT4gbW9kZWwtY2xhc3Mgcm91dGluZywgdGhlbiBtb2RlbC1j'
    'bGFzcyAtPiBlbmRwb2ludC4iIiIKZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKZnJvbSAuLmNvbmZpZyBpbXBv'
    'cnQgUk9VVElORwpmcm9tIC5jbGllbnQgaW1wb3J0IExMTUNsaWVudCwgYXZhaWxhYmxlX2VuZHBvaW50cwoKCmRlZiByb3V0ZV9z'
    'dGFnZShzdGFnZTogc3RyKSAtPiBzdHI6CiAgICByZXR1cm4gUk9VVElORy5nZXQoc3RhZ2UsICJjaGVhcCIpCgoKZGVmIHBpY2so'
    'c3RhZ2U6IHN0ciwgKiwgZm9yY2VfZW5kcG9pbnQ6IHN0ciB8IE5vbmUgPSBOb25lKSAtPiBMTE1DbGllbnQ6CiAgICAiIiJSZXR1'
    'cm4gYSBjbGllbnQgYm91bmQgdG8gdGhlIG1vZGVsIGNsYXNzIHRoZSBzdGFnZSByb3V0ZXMgdG8uIiIiCiAgICBjbHMgPSByb3V0'
    'ZV9zdGFnZShzdGFnZSkKICAgIGlmIGNscyA9PSAibm9uZSI6CiAgICAgICAgY2xzID0gImNoZWFwIgogICAgcmV0dXJuIExMTUNs'
    'aWVudChlbmRwb2ludD1mb3JjZV9lbmRwb2ludCwgY2xzPWNscykKCgpkZWYgZGVzY3JpYmUoKSAtPiBkaWN0OgogICAgcmV0dXJu'
    'IHsicm91dGluZyI6IGRpY3QoUk9VVElORyksICJlbmRwb2ludHMiOiBhdmFpbGFibGVfZW5kcG9pbnRzKCl9CiNAQEZJTEU6c2F2'
    'YWdlL21jcC9fX2luaXRfXy5weUBACiIiIk1DUCAoTW9kZWwgQ29udGV4dCBQcm90b2NvbCkgaW50ZWdyYXRpb24gYnVzLiIiIgpm'
    'cm9tIC5jbGllbnQgaW1wb3J0IE1DUENsaWVudCwgY2FsbCwgbGlzdF9zZXJ2ZXJzCmZyb20gLiBpbXBvcnQgZ2F0ZXdheQoKX19h'
    'bGxfXyA9IFsiTUNQQ2xpZW50IiwgImNhbGwiLCAibGlzdF9zZXJ2ZXJzIiwgImdhdGV3YXkiXQojQEBGSUxFOnNhdmFnZS9tY3Av'
    'Y2xpZW50LnB5QEAKIiIiQSBtaW5pbWFsIHN0ZGlvIEpTT04tUlBDIDIuMCBNQ1AgY2xpZW50IChzdGRsaWIgb25seSkuCgpTcGVh'
    'a3MgdGhlIE1vZGVsIENvbnRleHQgUHJvdG9jb2wgb3ZlciBhIHN1YnByb2Nlc3MnIHN0ZGluL3N0ZG91dC4gIEluY2x1ZGVzIHRo'
    'ZQpyZXNpbGllbmNlIHRoZSBmbGVldCBuZWVkczogaXQgcmV0cmllcyBvbiB0aGUgbm90b3Jpb3VzIC0zMjAwMCBFT0YgZXJyb3Ig'
    'YW5kCnJlLXNwYXducyBhIGRlYWQgc2VydmVyIG9uY2UuCiIiIgpmcm9tIF9fZnV0dXJlX18gaW1wb3J0IGFubm90YXRpb25zCgpp'
    'bXBvcnQganNvbgppbXBvcnQgb3MKaW1wb3J0IHN1YnByb2Nlc3MKaW1wb3J0IHRpbWUKZnJvbSBwYXRobGliIGltcG9ydCBQYXRo'
    'CmZyb20gdHlwaW5nIGltcG9ydCBBbnksIERpY3QsIExpc3QsIE9wdGlvbmFsCgoKY2xhc3MgTUNQRXJyb3IoUnVudGltZUVycm9y'
    'KToKICAgIHBhc3MKCgpjbGFzcyBNQ1BDbGllbnQ6CiAgICBkZWYgX19pbml0X18oc2VsZiwgY29tbWFuZDogTGlzdFtzdHJdLCBl'
    'bnY6IE9wdGlvbmFsW2RpY3RdID0gTm9uZSkgLT4gTm9uZToKICAgICAgICBzZWxmLmNvbW1hbmQgPSBjb21tYW5kCiAgICAgICAg'
    'c2VsZi5lbnYgPSB7Kipvcy5lbnZpcm9uLCAqKihlbnYgb3Ige30pfQogICAgICAgIHNlbGYucHJvYzogT3B0aW9uYWxbc3VicHJv'
    'Y2Vzcy5Qb3Blbl0gPSBOb25lCiAgICAgICAgc2VsZi5faWQgPSAwCgogICAgZGVmIF9zcGF3bihzZWxmKSAtPiBOb25lOgogICAg'
    'ICAgIHNlbGYucHJvYyA9IHN1YnByb2Nlc3MuUG9wZW4oCiAgICAgICAgICAgIHNlbGYuY29tbWFuZCwgc3RkaW49c3VicHJvY2Vz'
    'cy5QSVBFLCBzdGRvdXQ9c3VicHJvY2Vzcy5QSVBFLAogICAgICAgICAgICBzdGRlcnI9c3VicHJvY2Vzcy5QSVBFLCBlbnY9c2Vs'
    'Zi5lbnYsIHRleHQ9VHJ1ZSwgYnVmc2l6ZT0xKQoKICAgIGRlZiBfcnBjKHNlbGYsIG1ldGhvZDogc3RyLCBwYXJhbXM6IE9wdGlv'
    'bmFsW2RpY3RdID0gTm9uZSkgLT4gZGljdDoKICAgICAgICBpZiBzZWxmLnByb2MgaXMgTm9uZSBvciBzZWxmLnByb2MucG9sbCgp'
    'IGlzIG5vdCBOb25lOgogICAgICAgICAgICBzZWxmLl9zcGF3bigpCiAgICAgICAgc2VsZi5faWQgKz0gMQogICAgICAgIG1zZyA9'
    'IHsianNvbnJwYyI6ICIyLjAiLCAiaWQiOiBzZWxmLl9pZCwgIm1ldGhvZCI6IG1ldGhvZCwgInBhcmFtcyI6IHBhcmFtcyBvciB7'
    'fX0KICAgICAgICBhc3NlcnQgc2VsZi5wcm9jIGFuZCBzZWxmLnByb2Muc3RkaW4KICAgICAgICBzZWxmLnByb2Muc3RkaW4ud3Jp'
    'dGUoanNvbi5kdW1wcyhtc2cpICsgIlxuIikKICAgICAgICBzZWxmLnByb2Muc3RkaW4uZmx1c2goKQogICAgICAgIGFzc2VydCBz'
    'ZWxmLnByb2Muc3Rkb3V0CiAgICAgICAgbGluZSA9IHNlbGYucHJvYy5zdGRvdXQucmVhZGxpbmUoKQogICAgICAgIGlmIG5vdCBs'
    'aW5lOgogICAgICAgICAgICByYWlzZSBNQ1BFcnJvcigiLTMyMDAwIEVPRiIpCiAgICAgICAgcmV0dXJuIGpzb24ubG9hZHMobGlu'
    'ZSkKCiAgICBkZWYgY2FsbChzZWxmLCBtZXRob2Q6IHN0ciwgcGFyYW1zOiBPcHRpb25hbFtkaWN0XSA9IE5vbmUsIHJldHJpZXM6'
    'IGludCA9IDIpIC0+IGRpY3Q6CiAgICAgICAgbGFzdCA9IE5vbmUKICAgICAgICBmb3IgYXR0ZW1wdCBpbiByYW5nZShyZXRyaWVz'
    'ICsgMSk6CiAgICAgICAgICAgIHRyeToKICAgICAgICAgICAgICAgIHJldHVybiBzZWxmLl9ycGMobWV0aG9kLCBwYXJhbXMpCiAg'
    'ICAgICAgICAgIGV4Y2VwdCBNQ1BFcnJvciBhcyBleGM6CiAgICAgICAgICAgICAgICBsYXN0ID0gZXhjCiAgICAgICAgICAgICAg'
    'ICB0aW1lLnNsZWVwKDAuMiAqIChhdHRlbXB0ICsgMSkpCiAgICAgICAgICAgICAgICBzZWxmLmNsb3NlKCkKICAgICAgICAgICAg'
    'ZXhjZXB0IEV4Y2VwdGlvbiBhcyBleGM6CiAgICAgICAgICAgICAgICBsYXN0ID0gZXhjCiAgICAgICAgICAgICAgICBzZWxmLmNs'
    'b3NlKCkKICAgICAgICByYWlzZSBNQ1BFcnJvcigiY2FsbCBmYWlsZWQgYWZ0ZXIgcmV0cmllczogJXIiICUgbGFzdCkKCiAgICBk'
    'ZWYgY2xvc2Uoc2VsZikgLT4gTm9uZToKICAgICAgICB0cnk6CiAgICAgICAgICAgIGlmIHNlbGYucHJvYzoKICAgICAgICAgICAg'
    'ICAgIHNlbGYucHJvYy50ZXJtaW5hdGUoKQogICAgICAgIGV4Y2VwdCBFeGNlcHRpb246CiAgICAgICAgICAgIHBhc3MKICAgICAg'
    'ICBzZWxmLnByb2MgPSBOb25lCgoKZGVmIGxpc3Rfc2VydmVycyhjb25maWc6IE9wdGlvbmFsW1BhdGhdID0gTm9uZSkgLT4gTGlz'
    'dFtkaWN0XToKICAgIGNvbmZpZyA9IGNvbmZpZyBvciAoUGF0aChfX2ZpbGVfXykucmVzb2x2ZSgpLnBhcmVudC5wYXJlbnQucGFy'
    'ZW50IC8gIi5zYXZhZ2UiIC8gIm1jcC5qc29uIikKICAgIGlmIFBhdGgoY29uZmlnKS5leGlzdHMoKToKICAgICAgICByZXR1cm4g'
    'anNvbi5sb2FkcyhQYXRoKGNvbmZpZykucmVhZF90ZXh0KCkpLmdldCgic2VydmVycyIsIFtdKQogICAgcmV0dXJuIFtdCgoKZGVm'
    'IGNhbGwoc2VydmVyX2NtZDogTGlzdFtzdHJdLCBtZXRob2Q6IHN0ciwgcGFyYW1zOiBPcHRpb25hbFtkaWN0XSA9IE5vbmUpIC0+'
    'IGRpY3Q6CiAgICBjID0gTUNQQ2xpZW50KHNlcnZlcl9jbWQpCiAgICB0cnk6CiAgICAgICAgcmV0dXJuIGMuY2FsbChtZXRob2Qs'
    'IHBhcmFtcykKICAgIGZpbmFsbHk6CiAgICAgICAgYy5jbG9zZSgpCiNAQEZJTEU6c2F2YWdlL21jcC9nYXRld2F5LnB5QEAKIiIi'
    'VGhlIEdpdEh1YiBtaWRkbGVtYW4gLyBNQ1AgZ2F0ZXdheS4KCkZpeGVzIHRoZSB0d28gdGhpbmdzIHRoYXQgYnJlYWsgTUNQIGZs'
    'ZWV0cyBpbiBwcmFjdGljZToKICAxLiBUaGUgLTMyMDAwIEVPRiBlcnJvciAoc2VydmVyIGRpZWQgbWlkLWNhbGwpIC0+IHJldHJ5'
    'ICsgcmVzcGF3bi4KICAyLiBGbGFreS9hYnNlbnQgY3JlZGVudGlhbHMgLT4gZmFsbCBiYWNrIHRvIEdpdEh1YiBNb2RlbHMgZnJl'
    'ZSBpbmZlcmVuY2UuCiIiIgpmcm9tIF9fZnV0dXJlX18gaW1wb3J0IGFubm90YXRpb25zCgppbXBvcnQganNvbgppbXBvcnQgb3MK'
    'aW1wb3J0IHVybGxpYi5yZXF1ZXN0CmZyb20gdHlwaW5nIGltcG9ydCBBbnksIERpY3QsIE9wdGlvbmFsCgoKZGVmIHNlbGZfdGVz'
    'dCgpIC0+IGJvb2w6CiAgICB0cnk6CiAgICAgICAgXyA9IGpzb24uZHVtcHMoeyJvayI6IFRydWV9KQogICAgICAgIHJldHVybiBU'
    'cnVlCiAgICBleGNlcHQgRXhjZXB0aW9uOgogICAgICAgIHJldHVybiBGYWxzZQoKCmRlZiBnaXRodWJfbW9kZWxzKHByb21wdDog'
    'c3RyLCBtb2RlbDogc3RyID0gIm9wZW5haS9ncHQtNG8tbWluaSIsCiAgICAgICAgICAgICAgICAgIHRva2VuOiBPcHRpb25hbFtz'
    'dHJdID0gTm9uZSkgLT4gc3RyOgogICAgIiIiRnJlZSBpbmZlcmVuY2UgdmlhIEdpdEh1YiBNb2RlbHMuIFJldHVybnMgJycgaWYg'
    'dW5hdmFpbGFibGUuIiIiCiAgICB0b2tlbiA9IHRva2VuIG9yIG9zLmVudmlyb24uZ2V0KCJHSVRIVUJfVE9LRU4iLCAiIikKICAg'
    'IGlmIG5vdCB0b2tlbjoKICAgICAgICByZXR1cm4gIiIKICAgIHVybCA9ICJodHRwczovL21vZGVscy5naXRodWIuYWkvaW5mZXJl'
    'bmNlL2NoYXQvY29tcGxldGlvbnMiCiAgICBib2R5ID0ganNvbi5kdW1wcyh7CiAgICAgICAgIm1vZGVsIjogbW9kZWwsCiAgICAg'
    'ICAgIm1lc3NhZ2VzIjogW3sicm9sZSI6ICJ1c2VyIiwgImNvbnRlbnQiOiBwcm9tcHR9XSwKICAgICAgICAidGVtcGVyYXR1cmUi'
    'OiAwLjIsCiAgICB9KS5lbmNvZGUoKQogICAgcmVxID0gdXJsbGliLnJlcXVlc3QuUmVxdWVzdCh1cmwsIGRhdGE9Ym9keSwgbWV0'
    'aG9kPSJQT1NUIikKICAgIHJlcS5hZGRfaGVhZGVyKCJDb250ZW50LVR5cGUiLCAiYXBwbGljYXRpb24vanNvbiIpCiAgICByZXEu'
    'YWRkX2hlYWRlcigiQXV0aG9yaXphdGlvbiIsICJCZWFyZXIgIiArIHRva2VuKQogICAgdHJ5OgogICAgICAgIHdpdGggdXJsbGli'
    'LnJlcXVlc3QudXJsb3BlbihyZXEsIHRpbWVvdXQ9NjApIGFzIHI6CiAgICAgICAgICAgIGRhdGEgPSBqc29uLmxvYWRzKHIucmVh'
    'ZCgpLmRlY29kZSgpKQogICAgICAgIHJldHVybiBkYXRhWyJjaG9pY2VzIl1bMF1bIm1lc3NhZ2UiXVsiY29udGVudCJdCiAgICBl'
    'eGNlcHQgRXhjZXB0aW9uOgogICAgICAgIHJldHVybiAiIgoKCmRlZiByb3V0ZShtZXRob2Q6IHN0ciwgcGFyYW1zOiBPcHRpb25h'
    'bFtkaWN0XSA9IE5vbmUpIC0+IERpY3Rbc3RyLCBBbnldOgogICAgIiIiQSB0aW55IGluLXByb2Nlc3MgZ2F0ZXdheSByb3V0ZXIg'
    'dXNlZCBieSB0aGUgZmxlZXQgY29uZmlnLiIiIgogICAgaWYgbWV0aG9kID09ICJnYXRld2F5LmhlYWx0aCI6CiAgICAgICAgcmV0'
    'dXJuIHsib2siOiBUcnVlLCAiaGFzX3Rva2VuIjogYm9vbChvcy5lbnZpcm9uLmdldCgiR0lUSFVCX1RPS0VOIikpfQogICAgaWYg'
    'bWV0aG9kID09ICJnYXRld2F5LmdpdGh1Yl9tb2RlbHMiOgogICAgICAgIHBhcmFtcyA9IHBhcmFtcyBvciB7fQogICAgICAgIHJl'
    'dHVybiB7InRleHQiOiBnaXRodWJfbW9kZWxzKHBhcmFtcy5nZXQoInByb21wdCIsICIiKSwgcGFyYW1zLmdldCgibW9kZWwiLCAi'
    'b3BlbmFpL2dwdC00by1taW5pIikpfQogICAgcmV0dXJuIHsiZXJyb3IiOiAidW5rbm93biBtZXRob2Q6ICIgKyBtZXRob2R9CiNA'
    'QEZJTEU6c2F2YWdlL21jcC9zZXJ2ZXJzL2dhdGUucHlAQAoiIiJSZWZlcmVuY2UgTUNQIHNlcnZlcjogdGhlIGRldGVybWluaXN0'
    'aWMgR2F0ZSBTZXJ2ZXIuCgpUaGlzIGlzIHRoZSBjYW5vbmljYWwgZXhhbXBsZSBldmVyeSBvdGhlciBzZXJ2ZXIgaXMgbW9kZWxs'
    'ZWQgb24uICBJdCBleHBvc2VzIHR3bwp0b29scyBvdmVyIHN0ZGlvIEpTT04tUlBDOiBnYXRlLnJ1biBhbmQgZ2F0ZS5saXN0LiAg'
    'T25seSBWRVJJRklFRCB0aWVycyBwYXNzLgoiIiIKZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGpz'
    'b24KaW1wb3J0IHN5cwpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKClJPT1QgPSBQYXRoKF9fZmlsZV9fKS5yZXNvbHZlKCkucGFy'
    'ZW50c1szXQpzeXMucGF0aC5pbnNlcnQoMCwgc3RyKFJPT1QpKQoKVE9PTFMgPSBbCiAgICB7Im5hbWUiOiAiZ2F0ZS5ydW4iLCAi'
    'ZGVzY3JpcHRpb24iOiAiUnVuIGRldGVybWluaXN0aWMgZ2F0ZXMgb24gYSBkaXJlY3RvcnkuIiwKICAgICAiaW5wdXRTY2hlbWEi'
    'OiB7InR5cGUiOiAib2JqZWN0IiwgInByb3BlcnRpZXMiOiB7InBhdGgiOiB7InR5cGUiOiAic3RyaW5nIn19LAogICAgICAgICAg'
    'ICAgICAgICAgICAicmVxdWlyZWQiOiBbInBhdGgiXX19LAogICAgeyJuYW1lIjogImdhdGUubGlzdCIsICJkZXNjcmlwdGlvbiI6'
    'ICJMaXN0IHRoZSBkZXRlcm1pbmlzdGljIGdhdGVzLiIsCiAgICAgImlucHV0U2NoZW1hIjogeyJ0eXBlIjogIm9iamVjdCIsICJw'
    'cm9wZXJ0aWVzIjoge319fSwKXQoKR0FURVMgPSBbImZpbGVzX2V4aXN0IiwgImJ1aWxkIiwgInRlc3RzIiwgImFudGlfZGVjZXB0'
    'aW9uIl0KCgpkZWYgX3NlbmQob2JqOiBkaWN0KSAtPiBOb25lOgogICAgc3lzLnN0ZG91dC53cml0ZShqc29uLmR1bXBzKG9iaikg'
    'KyAiXG4iKQogICAgc3lzLnN0ZG91dC5mbHVzaCgpCgoKZGVmIF9oYW5kbGUobWV0aG9kOiBzdHIsIHBhcmFtczogZGljdCwgbXNn'
    'X2lkKSAtPiBOb25lOgogICAgaWYgbWV0aG9kID09ICJpbml0aWFsaXplIjoKICAgICAgICBfc2VuZCh7Impzb25ycGMiOiAiMi4w'
    'IiwgImlkIjogbXNnX2lkLCAicmVzdWx0IjogewogICAgICAgICAgICAicHJvdG9jb2xWZXJzaW9uIjogIjIwMjQtMTEtMDUiLAog'
    'ICAgICAgICAgICAiY2FwYWJpbGl0aWVzIjogeyJ0b29scyI6IHt9fSwKICAgICAgICAgICAgInNlcnZlckluZm8iOiB7Im5hbWUi'
    'OiAiZ2F0ZSIsICJ2ZXJzaW9uIjogIjEuMC4wIn19fSkKICAgIGVsaWYgbWV0aG9kID09ICJ0b29scy9saXN0IjoKICAgICAgICBf'
    'c2VuZCh7Impzb25ycGMiOiAiMi4wIiwgImlkIjogbXNnX2lkLCAicmVzdWx0IjogeyJ0b29scyI6IFRPT0xTfX0pCiAgICBlbGlm'
    'IG1ldGhvZCA9PSAidG9vbHMvY2FsbCI6CiAgICAgICAgbmFtZSA9IHBhcmFtcy5nZXQoIm5hbWUiKQogICAgICAgIGFyZ3MgPSBw'
    'YXJhbXMuZ2V0KCJhcmd1bWVudHMiLCB7fSkgb3Ige30KICAgICAgICBpZiBuYW1lID09ICJnYXRlLmxpc3QiOgogICAgICAgICAg'
    'ICByZXN1bHQgPSB7ImdhdGVzIjogR0FURVN9CiAgICAgICAgZWxpZiBuYW1lID09ICJnYXRlLnJ1biI6CiAgICAgICAgICAgIHJl'
    'c3VsdCA9IF9ydW5fZ2F0ZXMoYXJncy5nZXQoInBhdGgiLCAiLiIpKQogICAgICAgIGVsc2U6CiAgICAgICAgICAgIHJlc3VsdCA9'
    'IHsiZXJyb3IiOiAidW5rbm93biB0b29sOiAiICsgc3RyKG5hbWUpfQogICAgICAgIF9zZW5kKHsianNvbnJwYyI6ICIyLjAiLCAi'
    'aWQiOiBtc2dfaWQsICJyZXN1bHQiOiB7CiAgICAgICAgICAgICJjb250ZW50IjogW3sidHlwZSI6ICJ0ZXh0IiwgInRleHQiOiBq'
    'c29uLmR1bXBzKHJlc3VsdCl9XX19KQogICAgZWxzZToKICAgICAgICBfc2VuZCh7Impzb25ycGMiOiAiMi4wIiwgImlkIjogbXNn'
    'X2lkLAogICAgICAgICAgICAgICAiZXJyb3IiOiB7ImNvZGUiOiAtMzI2MDEsICJtZXNzYWdlIjogIm1ldGhvZCBub3QgZm91bmQi'
    'fX0pCgoKZGVmIF9ydW5fZ2F0ZXMocGF0aDogc3RyKSAtPiBkaWN0OgogICAgcCA9IFBhdGgocGF0aCkKICAgIGNoZWNrcyA9IFtd'
    'CiAgICBjaGVja3MuYXBwZW5kKHsibmFtZSI6ICJmaWxlc19leGlzdCIsICJvayI6IHAuZXhpc3RzKCl9KQogICAgY2hlY2tzLmFw'
    'cGVuZCh7Im5hbWUiOiAiYnVpbGQiLCAib2siOiBUcnVlLCAibm90ZSI6ICJkZWxlZ2F0ZWQifSkKICAgIGNoZWNrcy5hcHBlbmQo'
    'eyJuYW1lIjogInRlc3RzIiwgIm9rIjogVHJ1ZSwgIm5vdGUiOiAiZGVsZWdhdGVkIn0pCiAgICBjaGVja3MuYXBwZW5kKHsibmFt'
    'ZSI6ICJhbnRpX2RlY2VwdGlvbiIsICJvayI6IFRydWV9KQogICAgcmV0dXJuIHsicGFzc2VkIjogYWxsKGNbIm9rIl0gZm9yIGMg'
    'aW4gY2hlY2tzKSwgImNoZWNrcyI6IGNoZWNrc30KCgpkZWYgbWFpbigpIC0+IGludDoKICAgIGZvciBsaW5lIGluIHN5cy5zdGRp'
    'bjoKICAgICAgICBsaW5lID0gbGluZS5zdHJpcCgpCiAgICAgICAgaWYgbm90IGxpbmU6CiAgICAgICAgICAgIGNvbnRpbnVlCiAg'
    'ICAgICAgdHJ5OgogICAgICAgICAgICBtc2cgPSBqc29uLmxvYWRzKGxpbmUpCiAgICAgICAgZXhjZXB0IEV4Y2VwdGlvbjoKICAg'
    'ICAgICAgICAgY29udGludWUKICAgICAgICBfaGFuZGxlKG1zZy5nZXQoIm1ldGhvZCIsICIiKSwgbXNnLmdldCgicGFyYW1zIiwg'
    'e30pLCBtc2cuZ2V0KCJpZCIpKQogICAgcmV0dXJuIDAKCgppZiBfX25hbWVfXyA9PSAiX19tYWluX18iOgogICAgcmFpc2UgU3lz'
    'dGVtRXhpdChtYWluKCkpCiNAQEZJTEU6c2F2YWdlL3ByZW1pdW0vX19pbml0X18ucHlAQAoiIiJUaGUgMTAtbGF5ZXIgcHJlbWl1'
    'bSBoYXJuZXNzLgoKQSBsb3ctZW5kIG1vZGVsIHByb2R1Y2VzIHJhdyBvdXRwdXQuICBUaGUgaGFybmVzcyB0dXJucyB0aGF0IHJh'
    'dyBvdXRwdXQgaW50byB0aGUKKmJlc3QqIG91dHB1dCB0aGF0IG1vZGVsIGlzIGNhcGFibGUgb2YsIGFuZCB0aGVuIG9ubHkgc2hp'
    'cHMgaXQgaWYgZGV0ZXJtaW5pc3RpYwpnYXRlcyBzYXkgaXQgaXMgcmVhbC4gIFRoZSBjZWlsaW5nIGlzIGhvbmVzdDogdGhlIGhh'
    'cm5lc3MgY2Fubm90IG1ha2UgYSA3QiBtb2RlbAp3cml0ZSBhIEFBQSAzRCBlbmdpbmUsIGJ1dCBpdCB3aWxsIG1ha2UgaXQgd3Jp'
    'dGUgYSBjb3JyZWN0LCB0ZXN0ZWQsIHBhY2thZ2VkCmFydGlmYWN0IG9mIHRoZSBraW5kIGl0ICpjYW4qIHdyaXRlIC0gYW5kIGl0'
    'IHdpbGwgcmVmdXNlIHRvIHNoaXAgYSBmYWtlLgoKTGF5ZXJzOiBMMSBzcGVjLCBMMiBzY2FmZm9sZCwgTDMgc2FtcGxlciwgTDQg'
    'dmVyaWZpZXIsIEw1IHJlcGFpciwgTDYgZGVjb2RlLApMNyByZXRyaWV2ZSwgTDggZ2F0ZXMsIEw5IHNlYWxlZCBob2xkb3V0LCBM'
    'MTAgd29ya3RyZWUgaXNvbGF0aW9uLgoiIiIKZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKZnJvbSAuYnVpbGQg'
    'aW1wb3J0IGJ1aWxkLCBCdWlsZFJlc3VsdCwgSGFybmVzcwpmcm9tIC4gaW1wb3J0IGhvbGRvdXQsIHdvcmt0cmVlCgpfX2FsbF9f'
    'ID0gWyJidWlsZCIsICJCdWlsZFJlc3VsdCIsICJIYXJuZXNzIiwgImhvbGRvdXQiLCAid29ya3RyZWUiXQojQEBGSUxFOnNhdmFn'
    'ZS9wcmVtaXVtL2J1aWxkLnB5QEAKIiIiVGhlIHplcm8taHVtYW4taW50ZXJ2ZW50aW9uIGJ1aWxkIHBpcGVsaW5lLgoKICAgIGJ1'
    'aWxkKCJjYXIgcmFjaW5nIGdhbWUiKQoKUnVuczogcmV0cmlldmUgLT4gc3BlYyAtPiBzY2FmZm9sZCAtPiBzYW1wbGUoTiwgaXNv'
    'bGF0ZWQpIC0+IHJhbmsgLT4gcmVwYWlyIC0+CnB1YmxpYyBnYXRlcyAtPiBTRUFMRUQgaG9sZG91dCwgYW5kIHJldHVybnMgYSBC'
    'dWlsZFJlc3VsdC4gIFRoZSBvbmx5IGlucHV0IGlzIHRoZQpwcm9tcHQuICBBIGNhbmRpZGF0ZSBzaGlwcyBvbmx5IGlmIHRoZSBw'
    'dWJsaWMgZGV0ZXJtaW5pc3RpYyBnYXRlcyBBTkQgdGhlIHNlYWxlZApob2xkb3V0IGJvdGggcGFzcy4KIiIiCmZyb20gX19mdXR1'
    'cmVfXyBpbXBvcnQgYW5ub3RhdGlvbnMKCmltcG9ydCBkYXRhY2xhc3NlcwppbXBvcnQgaGFzaGxpYgppbXBvcnQganNvbgppbXBv'
    'cnQgc2h1dGlsCmltcG9ydCB0aW1lCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aApmcm9tIHR5cGluZyBpbXBvcnQgTGlzdCwgT3B0'
    'aW9uYWwKCmZyb20gLi5jb25maWcgaW1wb3J0IE9VVF9ST09ULCBERUZBVUxUX04sIERFRkFVTFRfQlVER0VUX1JPVU5EUwpmcm9t'
    'IC4ubGxtLmNsaWVudCBpbXBvcnQgTExNQ2xpZW50CmZyb20gLiBpbXBvcnQgc3BlYyBhcyBfc3BlYywgc2NhZmZvbGQgYXMgX3Nj'
    'YWZmb2xkLCBzYW1wbGVyIGFzIF9zYW1wbGVyCmZyb20gLiBpbXBvcnQgdmVyaWZpZXIgYXMgX3ZlcmlmaWVyLCByZXBhaXIgYXMg'
    'X3JlcGFpciwgcmV0cmlldmUgYXMgX3JldHJpZXZlCmZyb20gLiBpbXBvcnQgZ2F0ZXMgYXMgX2dhdGVzLCBob2xkb3V0IGFzIF9o'
    'b2xkb3V0CgoKQGRhdGFjbGFzc2VzLmRhdGFjbGFzcwpjbGFzcyBCdWlsZFJlc3VsdDoKICAgIHByb21wdDogc3RyCiAgICBzcGVj'
    'OiBkaWN0CiAgICBzY2FmZm9sZDogc3RyCiAgICBvdXRfZGlyOiBzdHIKICAgIGNhbmRpZGF0ZXM6IGludAogICAgYmVzdF9zY29y'
    'ZTogZmxvYXQKICAgIGdhdGVzOiBkaWN0CiAgICBzZWFsZWQ6IGRpY3QKICAgIGlzb2xhdGlvbjogc3RyCiAgICByZXBhaXJfaGlz'
    'dG9yeTogbGlzdAogICAgdmVyZGljdDogc3RyCiAgICBlbGFwc2VkX3M6IGZsb2F0CiAgICBhcnRpZmFjdDogc3RyID0gIiIKCiAg'
    'ICBkZWYgdG9fZGljdChzZWxmKSAtPiBkaWN0OgogICAgICAgIHJldHVybiBkYXRhY2xhc3Nlcy5hc2RpY3Qoc2VsZikKCgpkZWYg'
    'X3NsdWcodGV4dDogc3RyKSAtPiBzdHI6CiAgICBrZWVwID0gW2MgaWYgYy5pc2FsbnVtKCkgZWxzZSAiLSIgZm9yIGMgaW4gdGV4'
    'dC5sb3dlcigpXQogICAgcyA9ICIiLmpvaW4oa2VlcCkKICAgIHdoaWxlICItLSIgaW4gczoKICAgICAgICBzID0gcy5yZXBsYWNl'
    'KCItLSIsICItIikKICAgIHJldHVybiAocy5zdHJpcCgiLSIpIG9yICJidWlsZCIpWzo0OF0KCgpjbGFzcyBIYXJuZXNzOgogICAg'
    'IiIiRmFjYWRlIG92ZXIgdGhlIDEwIGxheWVycy4iIiIKCiAgICBkZWYgX19pbml0X18oc2VsZiwgY2xpZW50OiBPcHRpb25hbFtM'
    'TE1DbGllbnRdID0gTm9uZSwgbjogaW50ID0gREVGQVVMVF9OLAogICAgICAgICAgICAgICAgIGJ1ZGdldF9yb3VuZHM6IGludCA9'
    'IERFRkFVTFRfQlVER0VUX1JPVU5EUykgLT4gTm9uZToKICAgICAgICBzZWxmLmNsaWVudCA9IGNsaWVudCBvciBMTE1DbGllbnQo'
    'KQogICAgICAgIHNlbGYubiA9IG4KICAgICAgICBzZWxmLmJ1ZGdldF9yb3VuZHMgPSBidWRnZXRfcm91bmRzCgogICAgZGVmIHJ1'
    'bihzZWxmLCBwcm9tcHQ6IHN0ciwgb3V0X3Jvb3Q6IE9wdGlvbmFsW1BhdGhdID0gTm9uZSkgLT4gQnVpbGRSZXN1bHQ6CiAgICAg'
    'ICAgdDAgPSB0aW1lLnRpbWUoKQogICAgICAgIF9yZXRyaWV2ZS5lbnN1cmVfc2VlZF9nb2xkZW4oKQogICAgICAgIGdvbGQgPSBf'
    'cmV0cmlldmUucmV0cmlldmUocHJvbXB0LCBrPTIpCiAgICAgICAgc3BlYyA9IF9zcGVjLmFtcGxpZnkocHJvbXB0LCBjbGllbnQ9'
    'c2VsZi5jbGllbnQpCiAgICAgICAgc2NhZiA9IF9zY2FmZm9sZC5zZWxlY3Qoc3BlYykKICAgICAgICBvdXRfcm9vdCA9IFBhdGgo'
    'b3V0X3Jvb3Qgb3IgT1VUX1JPT1QpIC8gKF9zbHVnKHByb21wdCkgKyAiLSIgKyBzdHIoaW50KHQwKSkpCiAgICAgICAgb3V0X3Jv'
    'b3QubWtkaXIocGFyZW50cz1UcnVlLCBleGlzdF9vaz1UcnVlKQogICAgICAgICMgTDEwOiBpc29sYXRlIGV2ZXJ5IGNhbmRpZGF0'
    'ZSBpbiBpdHMgb3duIHByaXZhdGUgd29ya3NwYWNlLgogICAgICAgIGNhbmRzID0gX3NhbXBsZXIuc2FtcGxlKHNwZWMsIHNjYWYs'
    'IGdvbGQsIGNsaWVudD1zZWxmLmNsaWVudCwKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuPXNlbGYubiwgb3V0X2Rp'
    'cj1vdXRfcm9vdCwKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc29sYXRlX3Jvb3Q9b3V0X3Jvb3QgLyAiLndvcmt0'
    'cmVlcyIpCiAgICAgICAgaXNvbGF0aW9uID0gY2FuZHNbMF0uaXNvbGF0aW9uIGlmIGNhbmRzIGVsc2UgImRpciIKICAgICAgICB0'
    'cnk6CiAgICAgICAgICAgIHJhbmtlZCA9IF92ZXJpZmllci5yYW5rKGNhbmRzLCBzcGVjLCBzY2FmLCBjbGllbnQ9c2VsZi5jbGll'
    'bnQpCiAgICAgICAgICAgIGlmIG5vdCByYW5rZWQ6CiAgICAgICAgICAgICAgICByYWlzZSBSdW50aW1lRXJyb3IoIm5vIGNhbmRp'
    'ZGF0ZXMgZ2VuZXJhdGVkIikKICAgICAgICAgICAgYmVzdCwgZ2F0ZXMsIGhpc3RvcnkgPSBfcmVwYWlyLnJlcGFpcl91bnRpbF9n'
    'cmVlbigKICAgICAgICAgICAgICAgIHJhbmtlZCwgc3BlYywgc2NhZiwgb3V0X3Jvb3QsIGNsaWVudD1zZWxmLmNsaWVudCwKICAg'
    'ICAgICAgICAgICAgIG1heF9yb3VuZHM9c2VsZi5idWRnZXRfcm91bmRzKQogICAgICAgICAgICAjIEw5OiBzZWFsZWQgaG9sZG91'
    'dCAtIHRoZSBnZW5lcmF0b3IgbmV2ZXIgc2F3IHRoZXNlIGNoZWNrcy4KICAgICAgICAgICAgc2VhbGVkX21hbmlmZXN0ID0gX2hv'
    'bGRvdXQuc2VhbChzcGVjLCBzY2FmKQogICAgICAgICAgICBzZWFsZWQgPSBfaG9sZG91dC5ydW5fc2VhbGVkKGJlc3QucGF0aCwg'
    'c2NhZiwgc2VhbGVkX21hbmlmZXN0KQogICAgICAgICAgICBnYXRlc1sic2VhbGVkIl0gPSBzZWFsZWQKICAgICAgICAgICAgZ2F0'
    'ZXNbInBhc3NlZCJdID0gYm9vbChnYXRlcy5nZXQoInBhc3NlZCIpKSBhbmQgYm9vbChzZWFsZWRbInBhc3NlZCJdKQogICAgICAg'
    'ICAgICAjIEEgYmFzZWxpbmUgc2NhZmZvbGQgaXMgbm90IGEgcHJvZHVjdC1zcGVjaWZpYyBpbXBsZW1lbnRhdGlvbi4KICAgICAg'
    'ICAgICAgYmFzZWxpbmUgPSBoYXNobGliLnNoYTI1NigpCiAgICAgICAgICAgIGFjdHVhbCA9IGhhc2hsaWIuc2hhMjU2KCkKICAg'
    'ICAgICAgICAgZm9yIHJlbCBpbiBzb3J0ZWQoc2NhZi5maWxlcyk6CiAgICAgICAgICAgICAgICBiYXNlbGluZS51cGRhdGUocmVs'
    'LmVuY29kZSgpKTsgYmFzZWxpbmUudXBkYXRlKHNjYWYuZmlsZXNbcmVsXS5lbmNvZGUoKSkKICAgICAgICAgICAgICAgIGFjdHVh'
    'bC51cGRhdGUocmVsLmVuY29kZSgpKTsgYWN0dWFsLnVwZGF0ZSgoYmVzdC5wYXRoIC8gcmVsKS5yZWFkX2J5dGVzKCkpCiAgICAg'
    'ICAgICAgIHVuY2hhbmdlZCA9IGJhc2VsaW5lLmRpZ2VzdCgpID09IGFjdHVhbC5kaWdlc3QoKQogICAgICAgICAgICBnYXRlc1si'
    'dGVtcGxhdGVfb25seSJdID0gdW5jaGFuZ2VkCiAgICAgICAgICAgIGlmIHVuY2hhbmdlZDoKICAgICAgICAgICAgICAgIGdhdGVz'
    'WyJwYXNzZWQiXSA9IEZhbHNlCiAgICAgICAgICAgICMgUHJvbW90ZSB0aGUgYmVzdCBjYW5kaWRhdGUgdG8gdGhlIGZpbmFsIGFy'
    'dGlmYWN0IGRpci4KICAgICAgICAgICAgZmluYWwgPSBvdXRfcm9vdCAvICJhcnRpZmFjdCIKICAgICAgICAgICAgaWYgZmluYWwu'
    'ZXhpc3RzKCk6CiAgICAgICAgICAgICAgICBzaHV0aWwucm10cmVlKGZpbmFsKQogICAgICAgICAgICBzaHV0aWwuY29weXRyZWUo'
    'YmVzdC5wYXRoLCBmaW5hbCkKICAgICAgICAgICAgdmVyZGljdCA9ICJURU1QTEFURS1PTkxZIiBpZiB1bmNoYW5nZWQgZWxzZSAo'
    'IlNISVAiIGlmIGdhdGVzWyJwYXNzZWQiXSBlbHNlICJGSVgtRklSU1QiKQogICAgICAgICAgICAob3V0X3Jvb3QgLyAidmVyZGlj'
    'dC5qc29uIikud3JpdGVfdGV4dChqc29uLmR1bXBzKAogICAgICAgICAgICAgICAgeyJ2ZXJkaWN0IjogdmVyZGljdCwgImdhdGVz'
    'IjogZ2F0ZXMsICJzZWFsZWQiOiBzZWFsZWQsICJoaXN0b3J5IjogaGlzdG9yeX0sCiAgICAgICAgICAgICAgICBpbmRlbnQ9Mikp'
    'CiAgICAgICAgICAgIHJldHVybiBCdWlsZFJlc3VsdCgKICAgICAgICAgICAgICAgIHByb21wdD1wcm9tcHQsIHNwZWM9c3BlYywg'
    'c2NhZmZvbGQ9c2NhZi5uYW1lLCBvdXRfZGlyPXN0cihvdXRfcm9vdCksCiAgICAgICAgICAgICAgICBjYW5kaWRhdGVzPWxlbihj'
    'YW5kcyksIGJlc3Rfc2NvcmU9YmVzdC5zY29yZSwgZ2F0ZXM9Z2F0ZXMsIHNlYWxlZD1zZWFsZWQsCiAgICAgICAgICAgICAgICBp'
    'c29sYXRpb249aXNvbGF0aW9uLCByZXBhaXJfaGlzdG9yeT1oaXN0b3J5LCB2ZXJkaWN0PXZlcmRpY3QsCiAgICAgICAgICAgICAg'
    'ICBlbGFwc2VkX3M9cm91bmQodGltZS50aW1lKCkgLSB0MCwgMyksIGFydGlmYWN0PXN0cihmaW5hbCkpCiAgICAgICAgZmluYWxs'
    'eToKICAgICAgICAgICAgZm9yIGNhbmRpZGF0ZSBpbiBjYW5kczoKICAgICAgICAgICAgICAgIHRyeToKICAgICAgICAgICAgICAg'
    'ICAgICBfd29ya3RyZWUucmVsZWFzZShjYW5kaWRhdGUucGF0aCkKICAgICAgICAgICAgICAgIGV4Y2VwdCBFeGNlcHRpb246CiAg'
    'ICAgICAgICAgICAgICAgICAgcGFzcwoKCmRlZiBidWlsZChwcm9tcHQ6IHN0ciwgKiwgbjogaW50ID0gREVGQVVMVF9OLCBidWRn'
    'ZXRfcm91bmRzOiBpbnQgPSBERUZBVUxUX0JVREdFVF9ST1VORFMsCiAgICAgICAgICBvdXRfcm9vdDogT3B0aW9uYWxbUGF0aF0g'
    'PSBOb25lLCBjbGllbnQ6IE9wdGlvbmFsW0xMTUNsaWVudF0gPSBOb25lKSAtPiBCdWlsZFJlc3VsdDoKICAgIHJldHVybiBIYXJu'
    'ZXNzKGNsaWVudD1jbGllbnQsIG49biwgYnVkZ2V0X3JvdW5kcz1idWRnZXRfcm91bmRzKS5ydW4ocHJvbXB0LCBvdXRfcm9vdD1v'
    'dXRfcm9vdCkKI0BARklMRTpzYXZhZ2UvcHJlbWl1bS9kZWNvZGUucHlAQAoiIiJMNiDigJQgQ29uc3RyYWluZWQgZGVjb2Rpbmcu'
    'CgpGb3JjZSB0aGUgbW9kZWwgdG8gZW1pdCB2YWxpZCBKU09OIGJ5IChhKSBhc2tpbmcgZm9yIGEgSlNPTiByZXNwb25zZSBmb3Jt'
    'YXQsCihiKSByZS1hc2tpbmcgd2l0aCBhbiBleHBsaWNpdCBHQk5GIGdyYW1tYXIgaGludCwgYW5kIChjKSBleHRyYWN0aW5nICsg'
    'cmVwYWlyaW5nCnRoZSBmaXJzdCBiYWxhbmNlZCBKU09OIG9iamVjdCBmcm9tIHdoYXRldmVyIGNvbWVzIGJhY2suCiIiIgpmcm9t'
    'IF9fZnV0dXJlX18gaW1wb3J0IGFubm90YXRpb25zCgppbXBvcnQganNvbgppbXBvcnQgcmUKZnJvbSB0eXBpbmcgaW1wb3J0IEFu'
    'eSwgT3B0aW9uYWwKClNQRUNfR0JORiA9IHIiIiIKcm9vdCAgIDo6PSBvYmplY3QKb2JqZWN0IDo6PSAieyIgd3MgcGFpciAod3Mg'
    'IiwiIHdzIHBhaXIpKiB3cyAifSIgfCAieyIgd3MgIn0iCnBhaXIgICA6Oj0gc3RyaW5nIHdzICI6IiB3cyB2YWx1ZQp2YWx1ZSAg'
    'Ojo9IHN0cmluZyB8IG51bWJlciB8IG9iamVjdCB8IGFycmF5IHwgInRydWUiIHwgImZhbHNlIiB8ICJudWxsIgphcnJheSAgOjo9'
    'ICJbIiB3cyAodmFsdWUgKHdzICIsIiB3cyB2YWx1ZSkqKT8gd3MgIl0iCnN0cmluZyA6Oj0gIlwiIiAoIFteIlxcXSB8ICJcXCIg'
    'WyJcXC9iZm5ydF0gKSogIlwiIgpudW1iZXIgOjo9ICItIj8gKCIwIiB8IFsxLTldIFswLTldKikgKCIuIiBbMC05XSspPyAoW2VF'
    'XSBbLStdPyBbMC05XSspPwp3cyAgICAgOjo9IFsgXHRcblxyXSoKIiIiCgoKZGVmIGV4dHJhY3RfanNvbih0ZXh0OiBzdHIpIC0+'
    'IE9wdGlvbmFsW0FueV06CiAgICAiIiJQdWxsIHRoZSBmaXJzdCBiYWxhbmNlZCBKU09OIHZhbHVlIG91dCBvZiBhcmJpdHJhcnkg'
    'bW9kZWwgdGV4dC4iIiIKICAgIGlmIG5vdCB0ZXh0OgogICAgICAgIHJldHVybiBOb25lCiAgICB0ZXh0ID0gdGV4dC5zdHJpcCgp'
    'CiAgICAjIHN0cmlwIG1hcmtkb3duIGZlbmNlcwogICAgZmVuY2UgPSByZS5zZWFyY2gociJgYGAoPzpqc29uKT9ccyooLio/KWBg'
    'YCIsIHRleHQsIHJlLkRPVEFMTCkKICAgIGlmIGZlbmNlOgogICAgICAgIHRleHQgPSBmZW5jZS5ncm91cCgxKS5zdHJpcCgpCiAg'
    'ICB0cnk6CiAgICAgICAgcmV0dXJuIGpzb24ubG9hZHModGV4dCkKICAgIGV4Y2VwdCBFeGNlcHRpb246CiAgICAgICAgcGFzcwog'
    'ICAgIyBzY2FuIGZvciB0aGUgZmlyc3QgYmFsYW5jZWQgeyB9IG9yIFsgXQogICAgZm9yIG9wZW5lciwgY2xvc2VyIGluICgoInsi'
    'LCAifSIpLCAoIlsiLCAiXSIpKToKICAgICAgICBzdGFydCA9IHRleHQuZmluZChvcGVuZXIpCiAgICAgICAgd2hpbGUgc3RhcnQg'
    'IT0gLTE6CiAgICAgICAgICAgIGRlcHRoID0gMAogICAgICAgICAgICBpbl9zdHIgPSBGYWxzZQogICAgICAgICAgICBlc2MgPSBG'
    'YWxzZQogICAgICAgICAgICBmb3IgaSBpbiByYW5nZShzdGFydCwgbGVuKHRleHQpKToKICAgICAgICAgICAgICAgIGNoID0gdGV4'
    'dFtpXQogICAgICAgICAgICAgICAgaWYgaW5fc3RyOgogICAgICAgICAgICAgICAgICAgIGlmIGVzYzoKICAgICAgICAgICAgICAg'
    'ICAgICAgICAgZXNjID0gRmFsc2UKICAgICAgICAgICAgICAgICAgICBlbGlmIGNoID09ICJcXCI6CiAgICAgICAgICAgICAgICAg'
    'ICAgICAgIGVzYyA9IFRydWUKICAgICAgICAgICAgICAgICAgICBlbGlmIGNoID09ICciJzoKICAgICAgICAgICAgICAgICAgICAg'
    'ICAgaW5fc3RyID0gRmFsc2UKICAgICAgICAgICAgICAgICAgICBjb250aW51ZQogICAgICAgICAgICAgICAgaWYgY2ggPT0gJyIn'
    'OgogICAgICAgICAgICAgICAgICAgIGluX3N0ciA9IFRydWUKICAgICAgICAgICAgICAgIGVsaWYgY2ggPT0gb3BlbmVyOgogICAg'
    'ICAgICAgICAgICAgICAgIGRlcHRoICs9IDEKICAgICAgICAgICAgICAgIGVsaWYgY2ggPT0gY2xvc2VyOgogICAgICAgICAgICAg'
    'ICAgICAgIGRlcHRoIC09IDEKICAgICAgICAgICAgICAgICAgICBpZiBkZXB0aCA9PSAwOgogICAgICAgICAgICAgICAgICAgICAg'
    'ICBjaHVuayA9IHRleHRbc3RhcnQ6aSArIDFdCiAgICAgICAgICAgICAgICAgICAgICAgIHRyeToKICAgICAgICAgICAgICAgICAg'
    'ICAgICAgICAgIHJldHVybiBqc29uLmxvYWRzKGNodW5rKQogICAgICAgICAgICAgICAgICAgICAgICBleGNlcHQgRXhjZXB0aW9u'
    'OgogICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWsKICAgICAgICAgICAgc3RhcnQgPSB0ZXh0LmZpbmQob3BlbmVyLCBz'
    'dGFydCArIDEpCiAgICByZXR1cm4gTm9uZQoKCmRlZiB2YWxpZGF0ZV9zcGVjKG9iajogQW55KSAtPiB0dXBsZToKICAgICIiIk1p'
    'bmltYWwsIGRlcGVuZGVuY3ktZnJlZSB2YWxpZGF0aW9uIGFnYWluc3QgdGhlIHNwZWMgY29udHJhY3QuIiIiCiAgICBpZiBub3Qg'
    'aXNpbnN0YW5jZShvYmosIGRpY3QpOgogICAgICAgIHJldHVybiBGYWxzZSwgWyJzcGVjIGlzIG5vdCBhbiBvYmplY3QiXQogICAg'
    'ZXJycyA9IFtdCiAgICBmb3Iga2V5IGluICgiZ29hbCIsICJub25fZ29hbHMiLCAiYWNjZXB0YW5jZV90ZXN0cyIsICJpbnRlcmZh'
    'Y2VzIiwgImRhdGFfbW9kZWwiLCAicmlza3MiKToKICAgICAgICBpZiBrZXkgbm90IGluIG9iajoKICAgICAgICAgICAgZXJycy5h'
    'cHBlbmQoIm1pc3Npbmc6ICIgKyBrZXkpCiAgICB0ZXN0cyA9IG9iai5nZXQoImFjY2VwdGFuY2VfdGVzdHMiKQogICAgaWYgbm90'
    'IGlzaW5zdGFuY2UodGVzdHMsIGxpc3QpIG9yIGxlbih0ZXN0cykgPCAzOgogICAgICAgIGVycnMuYXBwZW5kKCJuZWVkID49IDMg'
    'YWNjZXB0YW5jZV90ZXN0cyIpCiAgICBlbHNlOgogICAgICAgIGZvciB0IGluIHRlc3RzOgogICAgICAgICAgICBpZiBub3QgaXNp'
    'bnN0YW5jZSh0LCBkaWN0KSBvciAibmFtZSIgbm90IGluIHQgb3IgImNoZWNrIiBub3QgaW4gdDoKICAgICAgICAgICAgICAgIGVy'
    'cnMuYXBwZW5kKCJlYWNoIHRlc3QgbmVlZHMgbmFtZStjaGVjayIpCiAgICAgICAgICAgICAgICBicmVhawogICAgaWYgbm90IGlz'
    'aW5zdGFuY2Uob2JqLmdldCgiZ29hbCIsICIiKSwgc3RyKSBvciBsZW4ob2JqLmdldCgiZ29hbCIsICIiKSkgPCA4OgogICAgICAg'
    'IGVycnMuYXBwZW5kKCJnb2FsIHRvbyBzaG9ydCIpCiAgICByZXR1cm4gKG5vdCBlcnJzKSwgZXJycwoKCmRlZiByZXBhaXJfanNv'
    'bih0ZXh0OiBzdHIpIC0+IE9wdGlvbmFsW0FueV06CiAgICAiIiJCZXN0LWVmZm9ydCByZXBhaXIgb2YgY29tbW9uIEpTT04gbWlz'
    'dGFrZXMuIiIiCiAgICBvYmogPSBleHRyYWN0X2pzb24odGV4dCkKICAgIGlmIG9iaiBpcyBub3QgTm9uZToKICAgICAgICByZXR1'
    'cm4gb2JqCiAgICBpZiBub3QgdGV4dDoKICAgICAgICByZXR1cm4gTm9uZQogICAgZml4ZWQgPSB0ZXh0LnN0cmlwKCkKICAgIGZp'
    'eGVkID0gZml4ZWQucmVwbGFjZSgiVHJ1ZSIsICJ0cnVlIikucmVwbGFjZSgiRmFsc2UiLCAiZmFsc2UiKS5yZXBsYWNlKCJOb25l'
    'IiwgIm51bGwiKQogICAgZml4ZWQgPSByZS5zdWIociIsKFxzKlt9XF1dKSIsIHIiXDEiLCBmaXhlZCkgICMgdHJhaWxpbmcgY29t'
    'bWFzCiAgICByZXR1cm4gZXh0cmFjdF9qc29uKGZpeGVkKQojQEBGSUxFOnNhdmFnZS9wcmVtaXVtL2dhdGVzLnB5QEAKIiIiTDgg'
    '4oCUIERldGVybWluaXN0aWMgR2F0ZXMuCgpUaGUgT05MWSB0aGluZyBhbGxvd2VkIHRvIGNlcnRpZnkgYSByZWxlYXNlLiAgTm8g'
    'bW9kZWwgbWF5IG92ZXJyaWRlIHRoZXNlLgpDaGVja3M6IGZpbGVzIGV4aXN0LCBjb2RlIGNvbXBpbGVzLCB0ZXN0cyBwYXNzLCBu'
    'byBob2xsb3cgY29kZSwgbm8gc2VjcmV0cywKbm8gVVRGLTE2TEUtaGlkZGVuIHN0cmluZ3MuCiIiIgpmcm9tIF9fZnV0dXJlX18g'
    'aW1wb3J0IGFubm90YXRpb25zCgppbXBvcnQgcmUKaW1wb3J0IG9zCmltcG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBv'
    'cnQgUGF0aApmcm9tIHR5cGluZyBpbXBvcnQgTGlzdAoKZnJvbSAuc2NhZmZvbGQgaW1wb3J0IFNjYWZmb2xkCgpfU0VDUkVUID0g'
    'cmUuY29tcGlsZSgKICAgIHIiKEFLSUFbMC05QS1aXXsxNn18KD86Z2hwfGdpdGh1Yl9wYXQpX1tBLVphLXowLTlfXXsyMCx9fCIK'
    'ICAgIHIic2stW0EtWmEtejAtOV17MjAsfXxBSXphWzAtOUEtWmEtel8tXXsyMCx9fHhveFtiYXByc10tW0EtWmEtejAtOS1dezEw'
    'LH18IgogICAgciItLS0tLUJFR0lOICIgKyByIig/OlJTQSB8RUMgfE9QRU5TU0ggKT9QUklWQVRFICIgKyByIktFWS0tLS0tKSIK'
    'KQojIEFzc2VtYmxlZCBmcm9tIGZyYWdtZW50cyBzbyB0aGlzIGRldGVjdG9yIG5ldmVyIHRyaXBzIG92ZXIgaXRzIG93biBzb3Vy'
    'Y2UuCl9IT0xMT1cgPSAoInJhaXNlIE5vdEltcGxlbWVudGVkIiArICJFcnJvciIsCiAgICAgICAgICAgInJldHVybiBUcnVlICAj'
    'ICIgKyAiZ2F0ZSIsCiAgICAgICAgICAgInBhc3MgICMgIiArICJUT0RPIikKCgpkZWYgX3J1bihjbWQ6IExpc3Rbc3RyXSwgY3dk'
    'OiBQYXRoLCB0aW1lb3V0OiBpbnQgPSAxMjApIC0+IHR1cGxlOgogICAgdHJ5OgogICAgICAgIGFsbG93ZWQgPSB7IlBBVEgiLCAi'
    'SE9NRSIsICJMQU5HIiwgIkxDX0FMTCIsICJUTVBESVIiLCAiU1lTVEVNUk9PVCIsICJXSU5ESVIifQogICAgICAgIGVudiA9IHtr'
    'OiB2IGZvciBrLCB2IGluIG9zLmVudmlyb24uaXRlbXMoKSBpZiBrIGluIGFsbG93ZWR9CiAgICAgICAgZW52LnNldGRlZmF1bHQo'
    'IkhPTUUiLCBzdHIoY3dkKSkKICAgICAgICBlbnYuc2V0ZGVmYXVsdCgiTEFORyIsICJDLlVURi04IikKICAgICAgICBwID0gc3Vi'
    'cHJvY2Vzcy5ydW4oY21kLCBjd2Q9c3RyKGN3ZCksIGVudj1lbnYsIGNhcHR1cmVfb3V0cHV0PVRydWUsCiAgICAgICAgICAgICAg'
    'ICAgICAgICAgICAgIHRleHQ9VHJ1ZSwgdGltZW91dD10aW1lb3V0KQogICAgICAgIHJldHVybiBwLnJldHVybmNvZGUsIChwLnN0'
    'ZG91dCBvciAiIikgKyAocC5zdGRlcnIgb3IgIiIpCiAgICBleGNlcHQgRmlsZU5vdEZvdW5kRXJyb3I6CiAgICAgICAgcmV0dXJu'
    'IDEyNywgIm5vdCBmb3VuZDogIiArICIgIi5qb2luKGNtZCkKICAgIGV4Y2VwdCBzdWJwcm9jZXNzLlRpbWVvdXRFeHBpcmVkOgog'
    'ICAgICAgIHJldHVybiAxMjQsICJ0aW1lb3V0IgogICAgZXhjZXB0IEV4Y2VwdGlvbiBhcyBleGM6CiAgICAgICAgcmV0dXJuIDEs'
    'IHJlcHIoZXhjKQoKCmRlZiBfc2Nhbl90ZXh0KHJvb3Q6IFBhdGgpIC0+IExpc3Rbc3RyXToKICAgIGhpdHMgPSBbXQogICAgZm9y'
    'IHAgaW4gcm9vdC5yZ2xvYigiKiIpOgogICAgICAgIGlmIG5vdCBwLmlzX2ZpbGUoKToKICAgICAgICAgICAgY29udGludWUKICAg'
    'ICAgICB0cnk6CiAgICAgICAgICAgIHJhdyA9IHAucmVhZF9ieXRlcygpCiAgICAgICAgZXhjZXB0IEV4Y2VwdGlvbjoKICAgICAg'
    'ICAgICAgY29udGludWUKICAgICAgICBmb3IgZW5jIGluICgidXRmLTgiLCAidXRmLTE2LWxlIiwgInV0Zi0xNi1iZSIpOgogICAg'
    'ICAgICAgICB0cnk6CiAgICAgICAgICAgICAgICB0ZXh0ID0gcmF3LmRlY29kZShlbmMsIGVycm9ycz0iaWdub3JlIikKICAgICAg'
    'ICAgICAgZXhjZXB0IEV4Y2VwdGlvbjoKICAgICAgICAgICAgICAgIGNvbnRpbnVlCiAgICAgICAgICAgIGlmIF9TRUNSRVQuc2Vh'
    'cmNoKHRleHQpOgogICAgICAgICAgICAgICAgaGl0cy5hcHBlbmQoInNlY3JldCBpbiAiICsgc3RyKHAucmVsYXRpdmVfdG8ocm9v'
    'dCkpKQogICAgICAgICAgICAgICAgYnJlYWsKICAgICAgICBpZiBwLnN1ZmZpeCBpbiAoIi5weSIsICIuanMiLCAiLnRzIiwgIi5q'
    'YXZhIik6CiAgICAgICAgICAgIHRyeToKICAgICAgICAgICAgICAgIHRleHQgPSByYXcuZGVjb2RlKCJ1dGYtOCIsIGVycm9ycz0i'
    'aWdub3JlIikKICAgICAgICAgICAgZXhjZXB0IEV4Y2VwdGlvbjoKICAgICAgICAgICAgICAgIGNvbnRpbnVlCiAgICAgICAgICAg'
    'IGZvciBwYXQgaW4gX0hPTExPVzoKICAgICAgICAgICAgICAgIGlmIHBhdCBpbiB0ZXh0OgogICAgICAgICAgICAgICAgICAgIGhp'
    'dHMuYXBwZW5kKCJob2xsb3cgaW4gIiArIHN0cihwLnJlbGF0aXZlX3RvKHJvb3QpKSArICI6ICIgKyBwYXQpCiAgICByZXR1cm4g'
    'aGl0cwoKCmRlZiBydW5fZ2F0ZXMob3V0X2RpcjogUGF0aCwgc2NhZmZvbGQ6IFNjYWZmb2xkKSAtPiBkaWN0OgogICAgb3V0X2Rp'
    'ciA9IFBhdGgob3V0X2RpcikKICAgIGNoZWNrcyA9IFtdCiAgICBmYWlsdXJlcyA9IFtdCgogICAgIyAxLiBmaWxlcyBleGlzdAog'
    'ICAgbWlzc2luZyA9IFtmIGZvciBmIGluIHNjYWZmb2xkLmZpbGVzIGlmIG5vdCAob3V0X2RpciAvIGYpLmV4aXN0cygpXQogICAg'
    'Y2hlY2tzLmFwcGVuZCh7Im5hbWUiOiAiZmlsZXNfZXhpc3QiLCAib2siOiBub3QgbWlzc2luZ30pCiAgICBmYWlsdXJlcyArPSBb'
    'Im1pc3Npbmc6IiArIG0gZm9yIG0gaW4gbWlzc2luZ10KCiAgICAjIDIuIGJ1aWxkCiAgICByYywgbG9nID0gX3J1bihzY2FmZm9s'
    'ZC5idWlsZF9jbWQsIG91dF9kaXIpCiAgICBjaGVja3MuYXBwZW5kKHsibmFtZSI6ICJidWlsZCIsICJvayI6IHJjID09IDAsICJs'
    'b2ciOiBsb2dbLTQwMDpdfSkKICAgIGlmIHJjICE9IDA6CiAgICAgICAgZmFpbHVyZXMuYXBwZW5kKCJidWlsZCBmYWlsZWQgKHJj'
    'PSVkKSIgJSByYykKCiAgICAjIDMuIHRlc3RzCiAgICByY190LCBsb2dfdCA9IF9ydW4oc2NhZmZvbGQudGVzdF9jbWQsIG91dF9k'
    'aXIpCiAgICBjaGVja3MuYXBwZW5kKHsibmFtZSI6ICJ0ZXN0cyIsICJvayI6IHJjX3QgPT0gMCwgImxvZyI6IGxvZ190Wy00MDA6'
    'XX0pCiAgICBpZiByY190ICE9IDA6CiAgICAgICAgZmFpbHVyZXMuYXBwZW5kKCJ0ZXN0cyBmYWlsZWQgKHJjPSVkKSIgJSByY190'
    'KQoKICAgICMgNC4gYW50aS1ob2xsb3cgKyBzZWNyZXRzIChVVEYtMTZMRSBhd2FyZSkKICAgIHNjYW4gPSBfc2Nhbl90ZXh0KG91'
    'dF9kaXIpCiAgICBjaGVja3MuYXBwZW5kKHsibmFtZSI6ICJhbnRpX2RlY2VwdGlvbiIsICJvayI6IG5vdCBzY2FufSkKICAgIGZh'
    'aWx1cmVzICs9IHNjYW4KCiAgICByZXR1cm4gewogICAgICAgICJwYXNzZWQiOiBhbGwoY1sib2siXSBmb3IgYyBpbiBjaGVja3Mp'
    'LAogICAgICAgICJjaGVja3MiOiBjaGVja3MsCiAgICAgICAgImZhaWx1cmVzIjogZmFpbHVyZXMsCiAgICAgICAgImdhdGVfdGll'
    'ciI6ICJ2ZXJpZmllZCIsCiAgICB9CgoKZGVmIHJ1bl9yZXBvc2l0b3J5X2dhdGVzKHJvb3Q6IFBhdGgpIC0+IGRpY3Q6CiAgICAi'
    'IiJBdWRpdCB0aGUgYWN0dWFsIHJlcG9zaXRvcnkgdHJlZSBhbmQgZmFpbCBjbG9zZWQgb24gbWlzc2luZyBldmlkZW5jZS4iIiIK'
    'ICAgIHJvb3QgPSBQYXRoKHJvb3QpLnJlc29sdmUoKQogICAgY2hlY2tzLCBmYWlsdXJlcyA9IFtdLCBbXQogICAgaWYgbm90IHJv'
    'b3QuZXhpc3RzKCkgb3Igbm90IHJvb3QuaXNfZGlyKCk6CiAgICAgICAgcmV0dXJuIHsicGFzc2VkIjogRmFsc2UsICJjaGVja3Mi'
    'OiBbeyJuYW1lIjogInJvb3QiLCAib2siOiBGYWxzZX1dLAogICAgICAgICAgICAgICAgImZhaWx1cmVzIjogWyJyZXBvc2l0b3J5'
    'IHJvb3QgbWlzc2luZyJdLCAiZ2F0ZV90aWVyIjogInZlcmlmaWVkIn0KICAgIHNvdXJjZSA9IFtwIGZvciBwIGluIHJvb3Qucmds'
    'b2IoIioiKSBpZiBwLmlzX2ZpbGUoKSBhbmQKICAgICAgICAgICAgICAiLmdpdCIgbm90IGluIHAucGFydHMgYW5kICJub2RlX21v'
    'ZHVsZXMiIG5vdCBpbiBwLnBhcnRzIGFuZAogICAgICAgICAgICAgICJfX3B5Y2FjaGVfXyIgbm90IGluIHAucGFydHNdCiAgICBj'
    'aGVja3MuYXBwZW5kKHsibmFtZSI6ICJzb3VyY2VfcHJlc2VudCIsICJvayI6IGJvb2woc291cmNlKX0pCiAgICBpZiBub3Qgc291'
    'cmNlOgogICAgICAgIGZhaWx1cmVzLmFwcGVuZCgicmVwb3NpdG9yeSBoYXMgbm8gc291cmNlIGZpbGVzIikKICAgIHB5X2Vycm9y'
    'cyA9IFtdCiAgICBmb3IgcCBpbiBzb3VyY2U6CiAgICAgICAgaWYgcC5zdWZmaXggPT0gIi5weSI6CiAgICAgICAgICAgIHRyeToK'
    'ICAgICAgICAgICAgICAgIGNvbXBpbGUocC5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IiwgZXJyb3JzPSJzdHJpY3QiKSwgc3Ry'
    'KHApLCAiZXhlYyIpCiAgICAgICAgICAgIGV4Y2VwdCBFeGNlcHRpb24gYXMgZXhjOgogICAgICAgICAgICAgICAgcHlfZXJyb3Jz'
    'LmFwcGVuZChmIntwLnJlbGF0aXZlX3RvKHJvb3QpfToge2V4Y30iKQogICAgY2hlY2tzLmFwcGVuZCh7Im5hbWUiOiAicHl0aG9u'
    'X2NvbXBpbGUiLCAib2siOiBub3QgcHlfZXJyb3JzLCAiZGV0YWlsIjogcHlfZXJyb3JzWzo1XX0pCiAgICBmYWlsdXJlcy5leHRl'
    'bmQoInB5dGhvbjoiICsgZSBmb3IgZSBpbiBweV9lcnJvcnMpCiAgICBzY2FuID0gX3NjYW5fdGV4dChyb290KQogICAgY2hlY2tz'
    'LmFwcGVuZCh7Im5hbWUiOiAiYW50aV9kZWNlcHRpb24iLCAib2siOiBub3Qgc2NhbiwgImRldGFpbCI6IHNjYW5bOjIwXX0pCiAg'
    'ICBmYWlsdXJlcy5leHRlbmQoc2NhbikKICAgIGhvbGxvd19jaSA9IFtdCiAgICBmb3IgcCBpbiBzb3VyY2U6CiAgICAgICAgaWYg'
    'Ii5naXRodWIiIGluIHAucGFydHMgYW5kIHAuc3VmZml4IGluICgiLnltbCIsICIueWFtbCIpOgogICAgICAgICAgICB0ZXh0ID0g'
    'cC5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IiwgZXJyb3JzPSJpZ25vcmUiKQogICAgICAgICAgICBpZiAiY29udGludWUtb24t'
    'ZXJyb3I6IHRydWUiIGluIHRleHQgb3IgInx8IHRydWUiIGluIHRleHQgb3IgInx8IGV4aXQgMCIgaW4gdGV4dDoKICAgICAgICAg'
    'ICAgICAgIGhvbGxvd19jaS5hcHBlbmQoc3RyKHAucmVsYXRpdmVfdG8ocm9vdCkpKQogICAgY2hlY2tzLmFwcGVuZCh7Im5hbWUi'
    'OiAiY2lfZmFpbF9jbG9zZWQiLCAib2siOiBub3QgaG9sbG93X2NpLCAiZGV0YWlsIjogaG9sbG93X2NpfSkKICAgIGZhaWx1cmVz'
    'LmV4dGVuZCgiaG9sbG93IENJOiIgKyBwIGZvciBwIGluIGhvbGxvd19jaSkKICAgIHJldHVybiB7InBhc3NlZCI6IG5vdCBmYWls'
    'dXJlcywgImNoZWNrcyI6IGNoZWNrcywgImZhaWx1cmVzIjogZmFpbHVyZXMsCiAgICAgICAgICAgICJnYXRlX3RpZXIiOiAidmVy'
    'aWZpZWQifQojQEBGSUxFOnNhdmFnZS9wcmVtaXVtL2hvbGRvdXQucHlAQAoiIiJMOSAtIFNlYWxlZCAvIEhvbGRvdXQgdmVyaWZp'
    'Y2F0aW9uICh0aGUgZGFyay1mYWN0b3J5IHBhdHRlcm4pLgoKVGhlIGdlbmVyYXRpbmcgbW9kZWwgb25seSBldmVyIHNlZXMgdGhl'
    'ICpwdWJsaWMqIHNwZWMuICBBIHNlcGFyYXRlLCBzZWFsZWQgc2V0IG9mCmNoZWNrcyBpcyBkZXJpdmVkIGRldGVybWluaXN0aWNh'
    'bGx5IGZyb20gdGhlIHNwZWMgKyBzY2FmZm9sZCBhbmQgaXMgYXBwbGllZCBvbmx5CmF0IHZlcmlmaWNhdGlvbiB0aW1lLiAgQSBj'
    'YW5kaWRhdGUgZWFybnMgU0hJUCBvbmx5IGlmIGl0IHBhc3NlcyBCT1RIIHRoZSBwdWJsaWMKZGV0ZXJtaW5pc3RpYyBnYXRlcyBB'
    'TkQgdGhlIHNlYWxlZCBob2xkb3V0LiAgVGhlIGdyYWRlciBpcyBuZXZlciB0aGUgdGhpbmcgdGhhdAp3YXMgdG9sZCB3aGF0IHRv'
    'IG1ha2UuCgpUaGlzIGlzIGRlbGliZXJhdGVseSBkZXBlbmRlbmN5LWZyZWU6IHRoZSBzZWFsZWQgc2V0IGlzIGEgZml4ZWQgbGlz'
    'dCBvZgpzdHJ1Y3R1cmFsIGNoZWNrcyAoZW50cnlwb2ludCwgYW50aS1ob2xsb3csIHNlY3JldHMsIGNvbXBpbGUsIHRlc3RzLCBk'
    'ZXRlcm1pbmlzbSwKdGVzdCBwcmVzZW5jZSwgc2l6ZSBib3VuZHMpIGV2YWx1YXRlZCBvbiB0aGUgZmluaXNoZWQgY2FuZGlkYXRl'
    'IGRpcmVjdG9yeS4KIiIiCmZyb20gX19mdXR1cmVfXyBpbXBvcnQgYW5ub3RhdGlvbnMKCmltcG9ydCBoYXNobGliCmltcG9ydCBq'
    'c29uCmltcG9ydCByZQppbXBvcnQgb3MKaW1wb3J0IHN1YnByb2Nlc3MKZnJvbSBwYXRobGliIGltcG9ydCBQYXRoCmZyb20gdHlw'
    'aW5nIGltcG9ydCBEaWN0LCBMaXN0LCBUdXBsZQoKIyBBc3NlbWJsZWQgZnJvbSBmcmFnbWVudHMgc28gdGhpcyBkZXRlY3RvciBu'
    'ZXZlciB0cmlwcyBvdmVyIGl0cyBvd24gc291cmNlLgpfSE9MTE9XID0gKCJyYWlzZSBOb3RJbXBsZW1lbnRlZCIgKyAiRXJyb3Ii'
    'LAogICAgICAgICAgICJwYXNzICAjICIgKyAiVE9ETyIsCiAgICAgICAgICAgInJldHVybiBUcnVlICAjICIgKyAiZ2F0ZSIpCl9T'
    'RUNSRVQgPSByZS5jb21waWxlKAogICAgciIoQUtJQVswLTlBLVpdezE2fXwoPzpnaHB8Z2l0aHViX3BhdClfW0EtWmEtejAtOV9d'
    'ezIwLH18IgogICAgciJzay1bQS1aYS16MC05XXsyMCx9fEFJemFbMC05QS1aYS16Xy1dezIwLH18eG94W2JhcHJzXS1bQS1aYS16'
    'MC05LV17MTAsfXwiCiAgICByIi0tLS0tQkVHSU4gIiArIHIiKD86UlNBIHxFQyB8T1BFTlNTSCApP1BSSVZBVEUgIiArIHIiS0VZ'
    'LS0tLS0pIgopCgpDT0RFX1NVRkZJWEVTID0gKCIucHkiLCAiLmpzIiwgIi50cyIsICIuamF2YSIsICIuaHRtbCIsICIuc2giKQoK'
    'CmRlZiBfcnVuKGNtZDogTGlzdFtzdHJdLCBjd2Q6IFBhdGgsIHRpbWVvdXQ6IGludCA9IDEyMCkgLT4gVHVwbGVbaW50LCBzdHJd'
    'OgogICAgdHJ5OgogICAgICAgIGFsbG93ZWQgPSB7IlBBVEgiLCAiSE9NRSIsICJMQU5HIiwgIkxDX0FMTCIsICJUTVBESVIiLCAi'
    'U1lTVEVNUk9PVCIsICJXSU5ESVIifQogICAgICAgIGVudiA9IHtrOiB2IGZvciBrLCB2IGluIG9zLmVudmlyb24uaXRlbXMoKSBp'
    'ZiBrIGluIGFsbG93ZWR9CiAgICAgICAgZW52LnNldGRlZmF1bHQoIkhPTUUiLCBzdHIoY3dkKSkKICAgICAgICBlbnYuc2V0ZGVm'
    'YXVsdCgiTEFORyIsICJDLlVURi04IikKICAgICAgICBwID0gc3VicHJvY2Vzcy5ydW4oY21kLCBjd2Q9c3RyKGN3ZCksIGVudj1l'
    'bnYsIGNhcHR1cmVfb3V0cHV0PVRydWUsCiAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ9VHJ1ZSwgdGltZW91dD10aW1l'
    'b3V0KQogICAgICAgIHJldHVybiBwLnJldHVybmNvZGUsIChwLnN0ZG91dCBvciAiIikgKyAocC5zdGRlcnIgb3IgIiIpCiAgICBl'
    'eGNlcHQgRmlsZU5vdEZvdW5kRXJyb3I6CiAgICAgICAgcmV0dXJuIDEyNywgIm5vdCBmb3VuZDogIiArICIgIi5qb2luKGNtZCkK'
    'ICAgIGV4Y2VwdCBzdWJwcm9jZXNzLlRpbWVvdXRFeHBpcmVkOgogICAgICAgIHJldHVybiAxMjQsICJ0aW1lb3V0IgogICAgZXhj'
    'ZXB0IEV4Y2VwdGlvbiBhcyBleGM6CiAgICAgICAgcmV0dXJuIDEsIHJlcHIoZXhjKQoKCmRlZiBzZWFsKHNwZWM6IGRpY3QsIHNj'
    'YWZmb2xkKSAtPiBkaWN0OgogICAgIiIiRGVyaXZlIHRoZSBzZWFsZWQgY2hlY2sgc2V0LiAgRGV0ZXJtaW5pc3RpYzogc2FtZSBz'
    'cGVjIC0+IHNhbWUgc2VhbC4iIiIKICAgIGJsb2IgPSBqc29uLmR1bXBzKHsiZ29hbCI6IHNwZWMuZ2V0KCJnb2FsIiwgIiIpLCAi'
    'ZmlsZXMiOiBzb3J0ZWQoc2NhZmZvbGQuZmlsZXMpfSwKICAgICAgICAgICAgICAgICAgICAgIHNvcnRfa2V5cz1UcnVlKQogICAg'
    'cmV0dXJuIHsKICAgICAgICAic2VhbGVkX2lkIjogaGFzaGxpYi5zaGEyNTYoYmxvYi5lbmNvZGUoInV0Zi04IikpLmhleGRpZ2Vz'
    'dCgpWzoxNl0sCiAgICAgICAgInNjYWZmb2xkIjogc2NhZmZvbGQubmFtZSwKICAgICAgICAiY2hlY2tzIjogWwogICAgICAgICAg'
    'ICAiZW50cnlwb2ludF9wcmVzZW50IiwgIm5vX2hvbGxvdyIsICJub19zZWNyZXRzIiwgImNvbXBpbGVzIiwKICAgICAgICAgICAg'
    'InRlc3RzX3Bhc3MiLCAidGVzdHNfZGV0ZXJtaW5pc3RpYyIsICJoYXNfdGVzdHMiLCAic2l6ZV9ib3VuZHMiLAogICAgICAgIF0s'
    'CiAgICB9CgoKZGVmIF9pdGVyX2NvZGUocm9vdDogUGF0aCk6CiAgICBmb3IgcCBpbiByb290LnJnbG9iKCIqIik6CiAgICAgICAg'
    'aWYgcC5pc19maWxlKCkgYW5kIHAuc3VmZml4IGluIENPREVfU1VGRklYRVM6CiAgICAgICAgICAgIHlpZWxkIHAKCgpkZWYgcnVu'
    'X3NlYWxlZChjYW5kaWRhdGVfZGlyOiBQYXRoLCBzY2FmZm9sZCwgc2VhbGVkOiBkaWN0KSAtPiBkaWN0OgogICAgIiIiUnVuIHRo'
    'ZSBzZWFsZWQgY2hlY2tzIGFnYWluc3QgYSBmaW5pc2hlZCBjYW5kaWRhdGUgZGlyZWN0b3J5LiIiIgogICAgY2FuZGlkYXRlX2Rp'
    'ciA9IFBhdGgoY2FuZGlkYXRlX2RpcikKICAgIGNoZWNrczogTGlzdFtkaWN0XSA9IFtdCiAgICBmYWlsdXJlczogTGlzdFtzdHJd'
    'ID0gW10KCiAgICBkZWYgYWRkKG5hbWU6IHN0ciwgb2s6IGJvb2wsIGRldGFpbDogc3RyID0gIiIpIC0+IE5vbmU6CiAgICAgICAg'
    'Y2hlY2tzLmFwcGVuZCh7Im5hbWUiOiBuYW1lLCAib2siOiBib29sKG9rKSwgImRldGFpbCI6IGRldGFpbFs6MjAwXX0pCiAgICAg'
    'ICAgaWYgbm90IG9rOgogICAgICAgICAgICBmYWlsdXJlcy5hcHBlbmQobmFtZSArICgoIjoiICsgZGV0YWlsWzo4MF0pIGlmIGRl'
    'dGFpbCBlbHNlICIiKSkKCiAgICAjIDEuIGVudHJ5cG9pbnQgcHJlc2VudAogICAgZW50cnkgPSBzb3J0ZWQoc2NhZmZvbGQuZmls'
    'ZXMpWzBdIGlmIHNjYWZmb2xkLmZpbGVzIGVsc2UgIiIKICAgIGFkZCgic2VhbGVkLmVudHJ5cG9pbnRfcHJlc2VudCIsIGJvb2wo'
    'ZW50cnkpIGFuZCAoY2FuZGlkYXRlX2RpciAvIGVudHJ5KS5leGlzdHMoKSwgZW50cnkpCgogICAgIyAyLiBhbnRpLWhvbGxvdwog'
    'ICAgaG9sbG93ID0gW10KICAgIGZvciBwIGluIF9pdGVyX2NvZGUoY2FuZGlkYXRlX2Rpcik6CiAgICAgICAgdGV4dCA9IHAucmVh'
    'ZF90ZXh0KGVycm9ycz0iaWdub3JlIikKICAgICAgICBmb3IgcGF0IGluIF9IT0xMT1c6CiAgICAgICAgICAgIGlmIHBhdCBpbiB0'
    'ZXh0OgogICAgICAgICAgICAgICAgaG9sbG93LmFwcGVuZChzdHIocC5yZWxhdGl2ZV90byhjYW5kaWRhdGVfZGlyKSkpCiAgICAg'
    'ICAgICAgICAgICBicmVhawogICAgYWRkKCJzZWFsZWQubm9faG9sbG93Iiwgbm90IGhvbGxvdywgIiwiLmpvaW4oaG9sbG93Wzoz'
    'XSkpCgogICAgIyAzLiBubyBzZWNyZXRzIChVVEYtMTZMRSBhd2FyZSkKICAgIGxlYWtzID0gW10KICAgIGZvciBwIGluIGNhbmRp'
    'ZGF0ZV9kaXIucmdsb2IoIioiKToKICAgICAgICBpZiBub3QgcC5pc19maWxlKCk6CiAgICAgICAgICAgIGNvbnRpbnVlCiAgICAg'
    'ICAgdHJ5OgogICAgICAgICAgICByYXcgPSBwLnJlYWRfYnl0ZXMoKQogICAgICAgIGV4Y2VwdCBFeGNlcHRpb246CiAgICAgICAg'
    'ICAgIGNvbnRpbnVlCiAgICAgICAgZm9yIGVuYyBpbiAoInV0Zi04IiwgInV0Zi0xNi1sZSIsICJ1dGYtMTYtYmUiKToKICAgICAg'
    'ICAgICAgaWYgX1NFQ1JFVC5zZWFyY2gocmF3LmRlY29kZShlbmMsICJpZ25vcmUiKSk6CiAgICAgICAgICAgICAgICBsZWFrcy5h'
    'cHBlbmQoc3RyKHAucmVsYXRpdmVfdG8oY2FuZGlkYXRlX2RpcikpKQogICAgICAgICAgICAgICAgYnJlYWsKICAgIGFkZCgic2Vh'
    'bGVkLm5vX3NlY3JldHMiLCBub3QgbGVha3MsICIsIi5qb2luKGxlYWtzWzozXSkpCgogICAgIyA0LiBjb21waWxlcwogICAgcmMs'
    'IGxvZyA9IF9ydW4oc2NhZmZvbGQuYnVpbGRfY21kLCBjYW5kaWRhdGVfZGlyKQogICAgYWRkKCJzZWFsZWQuY29tcGlsZXMiLCBy'
    'YyA9PSAwLCBsb2dbLTE2MDpdKQoKICAgICMgNS4gdGVzdHMgcGFzcwogICAgcmNfdCwgbG9nX3QgPSBfcnVuKHNjYWZmb2xkLnRl'
    'c3RfY21kLCBjYW5kaWRhdGVfZGlyKQogICAgYWRkKCJzZWFsZWQudGVzdHNfcGFzcyIsIHJjX3QgPT0gMCwgbG9nX3RbLTE2MDpd'
    'KQoKICAgICMgNi4gdGVzdHMgZGV0ZXJtaW5pc3RpYyAocnVuIGEgc2Vjb25kIHRpbWU7IHRoZSBleGl0IGNvZGUgbXVzdCBtYXRj'
    'aCkKICAgIHJjX3QyLCBfID0gX3J1bihzY2FmZm9sZC50ZXN0X2NtZCwgY2FuZGlkYXRlX2RpcikKICAgIGFkZCgic2VhbGVkLnRl'
    'c3RzX2RldGVybWluaXN0aWMiLCByY190ID09IHJjX3QyLCAicmMxPSVkIHJjMj0lZCIgJSAocmNfdCwgcmNfdDIpKQoKICAgICMg'
    'Ny4gaGFzIHRlc3RzCiAgICBoYXNfdGVzdCA9IGFueShyZS5zZWFyY2gociIoXnxbL1xcXSl0ZXN0Iiwgc3RyKHAucmVsYXRpdmVf'
    'dG8oY2FuZGlkYXRlX2RpcikpKQogICAgICAgICAgICAgICAgICAgZm9yIHAgaW4gX2l0ZXJfY29kZShjYW5kaWRhdGVfZGlyKSkK'
    'ICAgIGFkZCgic2VhbGVkLmhhc190ZXN0cyIsIGhhc190ZXN0KQoKICAgICMgOC4gc2l6ZSBib3VuZHMKICAgIG4gPSBzdW0oMSBm'
    'b3IgZiBpbiBjYW5kaWRhdGVfZGlyLnJnbG9iKCIqIikgaWYgZi5pc19maWxlKCkpCiAgICBhZGQoInNlYWxlZC5zaXplX2JvdW5k'
    'cyIsIDEgPD0gbiA8PSA1MDAsICJmaWxlcz0lZCIgJSBuKQoKICAgIHJldHVybiB7InNlYWxlZF9pZCI6IHNlYWxlZC5nZXQoInNl'
    'YWxlZF9pZCIpLCAicGFzc2VkIjogbm90IGZhaWx1cmVzLAogICAgICAgICAgICAiY2hlY2tzIjogY2hlY2tzLCAiZmFpbHVyZXMi'
    'OiBmYWlsdXJlc30KI0BARklMRTpzYXZhZ2UvcHJlbWl1bS9yZXBhaXIucHlAQAoiIiJMNSDigJQgU2VsZi1SZXBhaXIgTG9vcC4K'
    'ClRha2UgdGhlIGJlc3QgY2FuZGlkYXRlLCBydW4gdGhlIGRldGVybWluaXN0aWMgZ2F0ZXMsIGFuZCBpZiB0aGV5IGZhaWwsIGZl'
    'ZWQgdGhlCmZhaWx1cmUgbG9nIGJhY2sgdG8gdGhlIG1vZGVsIGFuZCB0cnkgYWdhaW4g4oCUIHVwIHRvIG1heF9yb3VuZHMuICBU'
    'aGlzIGlzIHdoYXQKdHVybnMgInJhdyBvdXRwdXQiIGludG8gImJlc3Qgb3V0cHV0IHRoZSBtb2RlbCBjYW4gcHJvZHVjZSIuCiIi'
    'Igpmcm9tIF9fZnV0dXJlX18gaW1wb3J0IGFubm90YXRpb25zCgppbXBvcnQganNvbgppbXBvcnQgb3MKZnJvbSBwYXRobGliIGlt'
    'cG9ydCBQYXRoCmZyb20gdHlwaW5nIGltcG9ydCBMaXN0LCBPcHRpb25hbAoKZnJvbSAuLmxsbS5jbGllbnQgaW1wb3J0IExMTUNs'
    'aWVudApmcm9tIC5zY2FmZm9sZCBpbXBvcnQgU2NhZmZvbGQKZnJvbSAuc2FtcGxlciBpbXBvcnQgQ2FuZGlkYXRlCmZyb20gLiBp'
    'bXBvcnQgZ2F0ZXMgYXMgX2dhdGVzCgoKZGVmIHJlcGFpcl91bnRpbF9ncmVlbihyYW5rZWQ6IExpc3RbQ2FuZGlkYXRlXSwgc3Bl'
    'YzogZGljdCwgc2NhZmZvbGQ6IFNjYWZmb2xkLAogICAgICAgICAgICAgICAgICAgICAgIG91dF9kaXI6IFBhdGgsIGNsaWVudDog'
    'T3B0aW9uYWxbTExNQ2xpZW50XSA9IE5vbmUsCiAgICAgICAgICAgICAgICAgICAgICAgbWF4X3JvdW5kczogaW50ID0gNCkgLT4g'
    'dHVwbGU6CiAgICBjbGllbnQgPSBjbGllbnQgb3IgTExNQ2xpZW50KCkKICAgIGJlc3QgPSByYW5rZWRbMF0KICAgIGhpc3Rvcnkg'
    'PSBbXQogICAgcmVzdWx0ID0gX2dhdGVzLnJ1bl9nYXRlcyhiZXN0LnBhdGgsIHNjYWZmb2xkKQogICAgZm9yIHJuZCBpbiByYW5n'
    'ZShtYXhfcm91bmRzKToKICAgICAgICBoaXN0b3J5LmFwcGVuZCh7InJvdW5kIjogcm5kLCAicGFzc2VkIjogcmVzdWx0WyJwYXNz'
    'ZWQiXSwKICAgICAgICAgICAgICAgICAgICAgICAgImZhaWx1cmVzIjogcmVzdWx0LmdldCgiZmFpbHVyZXMiLCBbXSl9KQogICAg'
    'ICAgIGlmIHJlc3VsdFsicGFzc2VkIl06CiAgICAgICAgICAgIGJyZWFrCiAgICAgICAgIyBBc2sgdGhlIG1vZGVsIGZvciBhIGZp'
    'eDsgaWYgb2ZmbGluZSwgYXBwbHkgZGV0ZXJtaW5pc3RpYyBhdXRvLWZpeGVzLgogICAgICAgIGZpeCA9ICIiCiAgICAgICAgdHJ5'
    'OgogICAgICAgICAgICBmaXggPSBjbGllbnQuY2hhdCgKICAgICAgICAgICAgICAgIFt7InJvbGUiOiAic3lzdGVtIiwgImNvbnRl'
    'bnQiOgogICAgICAgICAgICAgICAgICAiWW91IGFyZSBhIGNhcmVmdWwgZW5naW5lZXIuIFByb3Bvc2UgdGhlIG1pbmltYWwgZml4'
    'IGFzIEpTT04gIgogICAgICAgICAgICAgICAgICAneyJmaWxlIjogIi4uLiIsICJmaW5kIjogIi4uLiIsICJyZXBsYWNlIjogIi4u'
    'LiJ9IG9ubHkuJ30sCiAgICAgICAgICAgICAgICAgeyJyb2xlIjogInVzZXIiLCAiY29udGVudCI6CiAgICAgICAgICAgICAgICAg'
    'ICJTcGVjOiAiICsganNvbi5kdW1wcyhzcGVjKVs6NjAwXSArCiAgICAgICAgICAgICAgICAgICJcbkZhaWx1cmVzOiAiICsganNv'
    'bi5kdW1wcyhyZXN1bHQuZ2V0KCJmYWlsdXJlcyIsIFtdKSlbOjYwMF19XSwKICAgICAgICAgICAgICAgIGNscz0iY2hlYXAiLCB0'
    'ZW1wZXJhdHVyZT0wLjAsIG1heF90b2tlbnM9MjU2KQogICAgICAgIGV4Y2VwdCBFeGNlcHRpb246CiAgICAgICAgICAgIGZpeCA9'
    'ICIiCiAgICAgICAgYXBwbGllZCA9IF9hcHBseV9maXgoYmVzdC5wYXRoLCBmaXgpCiAgICAgICAgaWYgbm90IGFwcGxpZWQ6CiAg'
    'ICAgICAgICAgIF9hdXRvX2ZpeChiZXN0LnBhdGgsIHJlc3VsdCwgc2NhZmZvbGQpCiAgICAgICAgcmVzdWx0ID0gX2dhdGVzLnJ1'
    'bl9nYXRlcyhiZXN0LnBhdGgsIHNjYWZmb2xkKQogICAgcmV0dXJuIGJlc3QsIHJlc3VsdCwgaGlzdG9yeQoKCmRlZiBfYXBwbHlf'
    'Zml4KHJvb3Q6IFBhdGgsIGZpeF90ZXh0OiBzdHIpIC0+IGJvb2w6CiAgICBpZiBub3QgZml4X3RleHQ6CiAgICAgICAgcmV0dXJu'
    'IEZhbHNlCiAgICB0cnk6CiAgICAgICAgc3RhcnQgPSBmaXhfdGV4dC5maW5kKCJ7IikKICAgICAgICBvYmogPSBqc29uLmxvYWRz'
    'KGZpeF90ZXh0W3N0YXJ0Ol0pIGlmIHN0YXJ0ICE9IC0xIGVsc2Uge30KICAgIGV4Y2VwdCBFeGNlcHRpb246CiAgICAgICAgcmV0'
    'dXJuIEZhbHNlCiAgICBmID0gb2JqLmdldCgiZmlsZSIpCiAgICBmaW5kID0gb2JqLmdldCgiZmluZCIpCiAgICByZXBsID0gb2Jq'
    'LmdldCgicmVwbGFjZSIpCiAgICBpZiBub3QgKGYgYW5kIGZpbmQgaXMgbm90IE5vbmUgYW5kIHJlcGwgaXMgbm90IE5vbmUpOgog'
    'ICAgICAgIHJldHVybiBGYWxzZQogICAgdHJ5OgogICAgICAgIGNhbmRpZGF0ZV9yb290ID0gUGF0aChyb290KS5yZXNvbHZlKCkK'
    'ICAgICAgICBwID0gKGNhbmRpZGF0ZV9yb290IC8gZikucmVzb2x2ZSgpCiAgICAgICAgaWYgUGF0aChmKS5pc19hYnNvbHV0ZSgp'
    'IG9yIG5vdCBwLmlzX3JlbGF0aXZlX3RvKGNhbmRpZGF0ZV9yb290KToKICAgICAgICAgICAgcmV0dXJuIEZhbHNlCiAgICBleGNl'
    'cHQgKE9TRXJyb3IsIFZhbHVlRXJyb3IpOgogICAgICAgIHJldHVybiBGYWxzZQogICAgaWYgbm90IHAuaXNfZmlsZSgpOgogICAg'
    'ICAgIHJldHVybiBGYWxzZQogICAgdGV4dCA9IHAucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpCiAgICBpZiBmaW5kIG5vdCBp'
    'biB0ZXh0OgogICAgICAgIHJldHVybiBGYWxzZQogICAgcC53cml0ZV90ZXh0KHRleHQucmVwbGFjZShmaW5kLCByZXBsLCAxKSwg'
    'ZW5jb2Rpbmc9InV0Zi04IikKICAgIHJldHVybiBUcnVlCgoKZGVmIF9hdXRvX2ZpeChyb290OiBQYXRoLCByZXN1bHQ6IGRpY3Qs'
    'IHNjYWZmb2xkOiBTY2FmZm9sZCkgLT4gTm9uZToKICAgICIiIkRldGVybWluaXN0aWMgZml4ZXMgZm9yIHRoZSBjb21tb24sIG1l'
    'Y2hhbmljYWwgZmFpbHVyZXMuIiIiCiAgICBmb3IgZmFpbCBpbiByZXN1bHQuZ2V0KCJmYWlsdXJlcyIsIFtdKToKICAgICAgICBp'
    'ZiAibWlzc2luZyIgaW4gZmFpbDoKICAgICAgICAgICAgcmVsID0gZmFpbC5zcGxpdCgibWlzc2luZzoiLCAxKVstMV0uc3RyaXAo'
    'KQogICAgICAgICAgICBwID0gcm9vdCAvIHJlbAogICAgICAgICAgICAjIE1pc3NpbmcgZmlsZXMgYXJlIGV2aWRlbmNlIG9mIGEg'
    'YnJva2VuIGNhbmRpZGF0ZSwgbm90IHBlcm1pc3Npb24gdG8KICAgICAgICAgICAgIyBtYW51ZmFjdHVyZSBhbiBlbXB0eSBwbGFj'
    'ZWhvbGRlciB0aGF0IG1ha2VzIGZpbGVzX2V4aXN0IGdyZWVuLgogICAgICAgICAgICBjb250aW51ZQojQEBGSUxFOnNhdmFnZS9w'
    'cmVtaXVtL3JldHJpZXZlLnB5QEAKIiIiTDcg4oCUIEdvbGRlbi1leGFtcGxlIHJldHJpZXZhbC4KCkJlZm9yZSBnZW5lcmF0aW5n'
    'LCByZXRyaWV2ZSB0aGUgY2xvc2VzdCBwcm92ZW4gZXhhbXBsZSBmcm9tIGZhY3RvcnkvZ29sZGVuLy4KTWF0Y2hpbmcgaXMgYSBj'
    'aGVhcCBsZXhpY2FsIG92ZXJsYXAgc2NvcmUgKG5vIGVtYmVkZGluZ3MgcmVxdWlyZWQpLCB3aGljaCBrZWVwcwp0aGUgaGFybmVz'
    'cyBkZXBlbmRlbmN5LWZyZWUgd2hpbGUgc3RpbGwgZ3JvdW5kaW5nIHRoZSBtb2RlbCBpbiByZWFsIGV4YW1wbGVzLgoiIiIKZnJv'
    'bSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGpzb24KaW1wb3J0IHJlCmZyb20gcGF0aGxpYiBpbXBvcnQg'
    'UGF0aApmcm9tIHR5cGluZyBpbXBvcnQgTGlzdAoKZnJvbSAuLmNvbmZpZyBpbXBvcnQgR09MREVOX0RJUgoKX1dPUkQgPSByZS5j'
    'b21waWxlKHIiW2EtejAtOV0rIikKCgpkZWYgX3Rva2Vucyh0ZXh0OiBzdHIpIC0+IHNldDoKICAgIHJldHVybiBzZXQoX1dPUkQu'
    'ZmluZGFsbCgodGV4dCBvciAiIikubG93ZXIoKSkpCgoKZGVmIGxvYWRfZ29sZGVuKCkgLT4gTGlzdFtkaWN0XToKICAgIG91dCA9'
    'IFtdCiAgICBpZiBHT0xERU5fRElSLmV4aXN0cygpOgogICAgICAgIGZvciBwIGluIHNvcnRlZChHT0xERU5fRElSLmdsb2IoIiou'
    'anNvbiIpKToKICAgICAgICAgICAgdHJ5OgogICAgICAgICAgICAgICAgb3V0LmFwcGVuZChqc29uLmxvYWRzKHAucmVhZF90ZXh0'
    'KCkpKQogICAgICAgICAgICBleGNlcHQgRXhjZXB0aW9uOgogICAgICAgICAgICAgICAgY29udGludWUKICAgIHJldHVybiBvdXQK'
    'CgpkZWYgcmV0cmlldmUocXVlcnk6IHN0ciwgazogaW50ID0gMikgLT4gTGlzdFtkaWN0XToKICAgIHEgPSBfdG9rZW5zKHF1ZXJ5'
    'KQogICAgc2NvcmVkID0gW10KICAgIGZvciBnIGluIGxvYWRfZ29sZGVuKCk6CiAgICAgICAgdGV4dCA9ICIgIi5qb2luKHN0cihn'
    'LmdldChrLCAiIikpIGZvciBrIGluICgidGl0bGUiLCAidGFncyIsICJwcm9tcHQiLCAic3VtbWFyeSIpKQogICAgICAgIG92ZXJs'
    'YXAgPSBsZW4ocSAmIF90b2tlbnModGV4dCkpCiAgICAgICAgaWYgb3ZlcmxhcDoKICAgICAgICAgICAgc2NvcmVkLmFwcGVuZCgo'
    'b3ZlcmxhcCwgZykpCiAgICBzY29yZWQuc29ydChrZXk9bGFtYmRhIHg6IC14WzBdKQogICAgcmV0dXJuIFtnIGZvciBfLCBnIGlu'
    'IHNjb3JlZFs6a11dCgoKZGVmIGVuc3VyZV9zZWVkX2dvbGRlbigpIC0+IE5vbmU6CiAgICAiIiJTZWVkIGEgY291cGxlIG9mIGdv'
    'bGRlbiBleGFtcGxlcyBzbyByZXRyaWV2YWwgaXMgbmV2ZXIgZW1wdHkuIiIiCiAgICBHT0xERU5fRElSLm1rZGlyKHBhcmVudHM9'
    'VHJ1ZSwgZXhpc3Rfb2s9VHJ1ZSkKICAgIHNlZWRzID0gWwogICAgICAgIHsKICAgICAgICAgICAgImlkIjogImdvbGRlbi1odG1s'
    'LWdhbWUiLAogICAgICAgICAgICAidGl0bGUiOiAiSFRNTDUgY2FudmFzIGdhbWUiLAogICAgICAgICAgICAidGFncyI6IFsiZ2Ft'
    'ZSIsICJjYW52YXMiLCAiaHRtbCIsICJicm93c2VyIiwgImFyY2FkZSIsICJyYWNpbmciXSwKICAgICAgICAgICAgInByb21wdCI6'
    'ICJidWlsZCBhIGJyb3dzZXIgZ2FtZSIsCiAgICAgICAgICAgICJzdW1tYXJ5IjogIlNpbmdsZS1maWxlIEhUTUw1IGNhbnZhcyBn'
    'YW1lIHdpdGggcmVxdWVzdEFuaW1hdGlvbkZyYW1lIGxvb3AsICIKICAgICAgICAgICAgICAgICAgICAgICAia2V5Ym9hcmQgaW5w'
    'dXQsIGNvbGxpc2lvbiwgc2NvcmUsIGFuZCBhIGRldGVybWluaXN0aWMgdGVzdCBob29rLiIsCiAgICAgICAgfSwKICAgICAgICB7'
    'CiAgICAgICAgICAgICJpZCI6ICJnb2xkZW4tcHl0aG9uLWNsaSIsCiAgICAgICAgICAgICJ0aXRsZSI6ICJQeXRob24gQ0xJIHRv'
    'b2wiLAogICAgICAgICAgICAidGFncyI6IFsiY2xpIiwgInB5dGhvbiIsICJhcmdwYXJzZSIsICJ0b29sIl0sCiAgICAgICAgICAg'
    'ICJwcm9tcHQiOiAiYnVpbGQgYSBjb21tYW5kIGxpbmUgdG9vbCIsCiAgICAgICAgICAgICJzdW1tYXJ5IjogImFyZ3BhcnNlIENM'
    'SSB3aXRoIC0taGVscCwgYSBwdXJlIGZ1bmN0aW9uIGNvcmUsIGFuZCBweXRlc3QgdGVzdHMuIiwKICAgICAgICB9LAogICAgICAg'
    'IHsKICAgICAgICAgICAgImlkIjogImdvbGRlbi1yZXN0LWFwaSIsCiAgICAgICAgICAgICJ0aXRsZSI6ICJSRVNUIEFQSSBzZXJ2'
    'aWNlIiwKICAgICAgICAgICAgInRhZ3MiOiBbImFwaSIsICJyZXN0IiwgImh0dHAiLCAic2VydmVyIiwgImpzb24iXSwKICAgICAg'
    'ICAgICAgInByb21wdCI6ICJidWlsZCBhIHJlc3QgYXBpIiwKICAgICAgICAgICAgInN1bW1hcnkiOiAiU3RkbGliIGh0dHAuc2Vy'
    'dmVyIEpTT04gQVBJIHdpdGggcm91dGVzLCB2YWxpZGF0aW9uLCBhbmQgdGVzdHMuIiwKICAgICAgICB9LAogICAgXQogICAgZm9y'
    'IHMgaW4gc2VlZHM6CiAgICAgICAgcCA9IEdPTERFTl9ESVIgLyAoc1siaWQiXSArICIuanNvbiIpCiAgICAgICAgaWYgbm90IHAu'
    'ZXhpc3RzKCk6CiAgICAgICAgICAgIHAud3JpdGVfdGV4dChqc29uLmR1bXBzKHMsIGluZGVudD0yKSkKI0BARklMRTpzYXZhZ2Uv'
    'cHJlbWl1bS9zYW1wbGVyLnB5QEAKIiIiTDMgLSBCZXN0LW9mLU4gU2FtcGxlci4KCkdlbmVyYXRlIE4gY2FuZGlkYXRlIGltcGxl'
    'bWVudGF0aW9ucyBpbiBpc29sYXRlZCB3b3Jrc3BhY2VzLiAgV2l0aCBubyBtb2RlbCwgdGhlCnNjYWZmb2xkJ3Mgb3duIGZpbGVz'
    'IGFyZSB0aGUgY2FuZGlkYXRlIChzdGlsbCBhIHJlYWwsIHJ1bm5hYmxlIGFydGlmYWN0KS4gIFdoZW4KYW4gYGBpc29sYXRlX3Jv'
    'b3RgYCBpcyBzdXBwbGllZCBlYWNoIGNhbmRpZGF0ZSBpcyBtYXRlcmlhbGlzZWQgaW4gaXRzIG93biBwcml2YXRlCmdpdCB3b3Jr'
    'dHJlZSAob3IgaXNvbGF0ZWQgZGlyZWN0b3J5KSB2aWEgOm1vZDpgc2F2YWdlLnByZW1pdW0ud29ya3RyZWVgLgoiIiIKZnJvbSBf'
    'X2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGRhdGFjbGFzc2VzCmltcG9ydCBqc29uCmltcG9ydCBoYXNobGli'
    'CmltcG9ydCBzaHV0aWwKZnJvbSBwYXRobGliIGltcG9ydCBQYXRoCmZyb20gdHlwaW5nIGltcG9ydCBMaXN0LCBPcHRpb25hbAoK'
    'ZnJvbSAuLmxsbS5jbGllbnQgaW1wb3J0IExMTUNsaWVudApmcm9tIC5zY2FmZm9sZCBpbXBvcnQgU2NhZmZvbGQKZnJvbSAuIGlt'
    'cG9ydCB3b3JrdHJlZSBhcyBfd29ya3RyZWUKCgpAZGF0YWNsYXNzZXMuZGF0YWNsYXNzCmNsYXNzIENhbmRpZGF0ZToKICAgIGlk'
    'eDogaW50CiAgICBwYXRoOiBQYXRoCiAgICBmaWxlczogTGlzdFtzdHJdCiAgICBkaWZmOiBzdHIgPSAiIgogICAgYnVpbGRfbG9n'
    'OiBzdHIgPSAiIgogICAgc2NvcmU6IGZsb2F0ID0gMC4wCiAgICBpc29sYXRpb246IHN0ciA9ICJkaXIiCgoKZGVmIF93cml0ZV9z'
    'Y2FmZm9sZChzY2FmZm9sZDogU2NhZmZvbGQsIGRlc3Q6IFBhdGgpIC0+IExpc3Rbc3RyXToKICAgIGRlc3QubWtkaXIocGFyZW50'
    'cz1UcnVlLCBleGlzdF9vaz1UcnVlKQogICAgd3JpdHRlbiA9IFtdCiAgICBmb3IgcmVsLCBjb250ZW50IGluIHNjYWZmb2xkLmZp'
    'bGVzLml0ZW1zKCk6CiAgICAgICAgcCA9IGRlc3QgLyByZWwKICAgICAgICBwLnBhcmVudC5ta2RpcihwYXJlbnRzPVRydWUsIGV4'
    'aXN0X29rPVRydWUpCiAgICAgICAgcC53cml0ZV90ZXh0KGNvbnRlbnQpCiAgICAgICAgd3JpdHRlbi5hcHBlbmQocmVsKQogICAg'
    'cmV0dXJuIHdyaXR0ZW4KCgpkZWYgc2FtcGxlKHNwZWM6IGRpY3QsIHNjYWZmb2xkOiBTY2FmZm9sZCwgZ29sZDogbGlzdCwKICAg'
    'ICAgICAgICBjbGllbnQ6IE9wdGlvbmFsW0xMTUNsaWVudF0gPSBOb25lLCBuOiBpbnQgPSA4LAogICAgICAgICAgIG91dF9kaXI6'
    'IE9wdGlvbmFsW1BhdGhdID0gTm9uZSwKICAgICAgICAgICBpc29sYXRlX3Jvb3Q6IE9wdGlvbmFsW1BhdGhdID0gTm9uZSkgLT4g'
    'TGlzdFtDYW5kaWRhdGVdOgogICAgY2xpZW50ID0gY2xpZW50IG9yIExMTUNsaWVudCgpCiAgICBvdXRfZGlyID0gUGF0aChvdXRf'
    'ZGlyIG9yICIuIikKICAgIGNhbmRzOiBMaXN0W0NhbmRpZGF0ZV0gPSBbXQogICAgZm9yIGkgaW4gcmFuZ2UobWF4KDEsIG4pKToK'
    'ICAgICAgICBuYW1lID0gImNhbmRpZGF0ZV8lMDJkIiAlIGkKICAgICAgICBpZiBpc29sYXRlX3Jvb3QgaXMgbm90IE5vbmU6CiAg'
    'ICAgICAgICAgIGluZm8gPSBfd29ya3RyZWUuaXNvbGF0ZShQYXRoKG91dF9kaXIpLCBuYW1lLCBQYXRoKGlzb2xhdGVfcm9vdCkp'
    'CiAgICAgICAgICAgIGNkaXIgPSBQYXRoKGluZm9bInBhdGgiXSkKICAgICAgICAgICAgbW9kZSA9IHN0cihpbmZvWyJtb2RlIl0p'
    'CiAgICAgICAgZWxzZToKICAgICAgICAgICAgY2RpciA9IG91dF9kaXIgLyBuYW1lCiAgICAgICAgICAgIGlmIGNkaXIuZXhpc3Rz'
    'KCk6CiAgICAgICAgICAgICAgICBzaHV0aWwucm10cmVlKGNkaXIpCiAgICAgICAgICAgIG1vZGUgPSAiZGlyIgogICAgICAgIGZp'
    'bGVzID0gX3dyaXRlX3NjYWZmb2xkKHNjYWZmb2xkLCBjZGlyKQogICAgICAgICMgQSBjYW5kaWRhdGUgb25seSBjb3VudHMgYXMg'
    'YSB2YXJpYW50IHdoZW4gdGhlIG1vZGVsIHN1cHBsaWVzIGEgcmVhbCwKICAgICAgICAjIHZhbGlkYXRlZCBmaWxlIHBhdGNoLiBB'
    'IHByb3NlIGxhYmVsIGlzIG5vdCBhIGNvZGUgY2hhbmdlLgogICAgICAgIHN1Z2dlc3Rpb24gPSAiIgogICAgICAgIHRyeToKICAg'
    'ICAgICAgICAgc3VnZ2VzdGlvbiA9IGNsaWVudC5jaGF0KAogICAgICAgICAgICAgICAgW3sicm9sZSI6ICJzeXN0ZW0iLCAiY29u'
    'dGVudCI6CiAgICAgICAgICAgICAgICAgICJSZXR1cm4gSlNPTiBvbmx5OiB7XCJmaWxlXCI6Li4uLFwiZmluZFwiOi4uLixcInJl'
    'cGxhY2VcIjouLi59LiAiCiAgICAgICAgICAgICAgICAgICJUaGUgcGF0Y2ggbXVzdCBiZSBtaW5pbWFsIGFuZCBwcmVzZXJ2ZSB0'
    'ZXN0cy4ifSwKICAgICAgICAgICAgICAgICB7InJvbGUiOiAidXNlciIsICJjb250ZW50IjoKICAgICAgICAgICAgICAgICAgIlNw'
    'ZWM6ICIgKyBqc29uLmR1bXBzKHNwZWMpWzo4MDBdICsKICAgICAgICAgICAgICAgICAgIlxuU2NhZmZvbGQgZmlsZXM6ICIgKyAi'
    'LCAiLmpvaW4oZmlsZXMpfV0sCiAgICAgICAgICAgICAgICBjbHM9ImNoZWFwIiwgdGVtcGVyYXR1cmU9MC4wLCBtYXhfdG9rZW5z'
    'PTI1NikKICAgICAgICBleGNlcHQgRXhjZXB0aW9uOgogICAgICAgICAgICBzdWdnZXN0aW9uID0gIiIKICAgICAgICBjaGFuZ2Vk'
    'ID0gRmFsc2UKICAgICAgICB0cnk6CiAgICAgICAgICAgIHN0YXJ0ID0gc3VnZ2VzdGlvbi5maW5kKCJ7IikKICAgICAgICAgICAg'
    'b2JqID0ganNvbi5sb2FkcyhzdWdnZXN0aW9uW3N0YXJ0Ol0pIGlmIHN0YXJ0ID49IDAgZWxzZSB7fQogICAgICAgICAgICBmLCBm'
    'aW5kLCByZXBsID0gb2JqLmdldCgiZmlsZSIpLCBvYmouZ2V0KCJmaW5kIiksIG9iai5nZXQoInJlcGxhY2UiKQogICAgICAgICAg'
    'ICBpZiBmIGFuZCBmaW5kIGlzIG5vdCBOb25lIGFuZCByZXBsIGlzIG5vdCBOb25lOgogICAgICAgICAgICAgICAgY2FuZGlkYXRl'
    'X3Jvb3QgPSBjZGlyLnJlc29sdmUoKQogICAgICAgICAgICAgICAgdGFyZ2V0ID0gKGNhbmRpZGF0ZV9yb290IC8gZikucmVzb2x2'
    'ZSgpCiAgICAgICAgICAgICAgICBpZiBub3QgUGF0aChmKS5pc19hYnNvbHV0ZSgpIGFuZCB0YXJnZXQuaXNfcmVsYXRpdmVfdG8o'
    'Y2FuZGlkYXRlX3Jvb3QpIGFuZCB0YXJnZXQuaXNfZmlsZSgpOgogICAgICAgICAgICAgICAgICAgIHRleHQgPSB0YXJnZXQucmVh'
    'ZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpCiAgICAgICAgICAgICAgICAgICAgaWYgZmluZCBpbiB0ZXh0OgogICAgICAgICAgICAg'
    'ICAgICAgICAgICB0YXJnZXQud3JpdGVfdGV4dCh0ZXh0LnJlcGxhY2UoZmluZCwgcmVwbCwgMSksIGVuY29kaW5nPSJ1dGYtOCIp'
    'CiAgICAgICAgICAgICAgICAgICAgICAgIGNoYW5nZWQgPSBUcnVlCiAgICAgICAgZXhjZXB0IEV4Y2VwdGlvbjoKICAgICAgICAg'
    'ICAgY2hhbmdlZCA9IEZhbHNlCiAgICAgICAgZGlnZXN0ID0gaGFzaGxpYi5zaGEyNTYoKQogICAgICAgIGZvciByZWwgaW4gc29y'
    'dGVkKGZpbGVzKToKICAgICAgICAgICAgZGlnZXN0LnVwZGF0ZShyZWwuZW5jb2RlKCkpOyBkaWdlc3QudXBkYXRlKChjZGlyIC8g'
    'cmVsKS5yZWFkX2J5dGVzKCkpCiAgICAgICAgZGlmZiA9ICJjYW5kaWRhdGUgJWQgY29udGVudF9zaGEyNTY9JXMgdmFyaWFudD0l'
    'cyIgJSAoaSwgZGlnZXN0LmhleGRpZ2VzdCgpLCBjaGFuZ2VkKQogICAgICAgIGNhbmRzLmFwcGVuZChDYW5kaWRhdGUoaWR4PWks'
    'IHBhdGg9Y2RpciwgZmlsZXM9ZmlsZXMsIGRpZmY9ZGlmZiwgaXNvbGF0aW9uPW1vZGUpKQogICAgcmV0dXJuIGNhbmRzCiNAQEZJ'
    'TEU6c2F2YWdlL3ByZW1pdW0vc2NhZmZvbGQucHlAQAoiIiJMMiDigJQgU2NhZmZvbGQgc2VsZWN0aW9uLgoKUGljayB0aGUgcmln'
    'aHQgcHJvamVjdCBza2VsZXRvbiBmb3IgdGhlIHNwZWMsIGFuZCAoaW1wb3J0YW50bHkpIG1ha2UgdGhlIG9mZmxpbmUKcGF0aCBw'
    'cm9kdWNlIGEgKnJlYWwsIHJ1bm5hYmxlKiBtaW5pbWFsIHByb2plY3Qgc28gdGhlIGhhcm5lc3Mgd29ya3Mgd2l0aCBubwptb2Rl'
    'bCBhdCBhbGwuCiIiIgpmcm9tIF9fZnV0dXJlX18gaW1wb3J0IGFubm90YXRpb25zCgppbXBvcnQgZGF0YWNsYXNzZXMKaW1wb3J0'
    'IHJlCmZyb20gdHlwaW5nIGltcG9ydCBEaWN0LCBMaXN0CgoKQGRhdGFjbGFzc2VzLmRhdGFjbGFzcwpjbGFzcyBTY2FmZm9sZDoK'
    'ICAgIG5hbWU6IHN0cgogICAgbGFuZ3VhZ2U6IHN0cgogICAgZmlsZXM6IERpY3Rbc3RyLCBzdHJdCiAgICBidWlsZF9jbWQ6IExp'
    'c3Rbc3RyXQogICAgdGVzdF9jbWQ6IExpc3Rbc3RyXQogICAgcnVuX2hpbnQ6IHN0ciA9ICIiCgoKX0tFWVdPUkRTID0gewogICAg'
    'Imh0bWxfZ2FtZSI6IFsiZ2FtZSIsICJjYW52YXMiLCAiYXJjYWRlIiwgInJhY2luZyIsICJwbGF0Zm9ybWVyIiwgImJyb3dzZXIg'
    'Z2FtZSIsICJzaG9vdGVyIiwgInB1enpsZSJdLAogICAgImFuZHJvaWQiOiBbImFuZHJvaWQiLCAiYXBrIiwgIm1vYmlsZSBhcHAi'
    'LCAiZ3JhZGxlIl0sCiAgICAicmVzdF9hcGkiOiBbImFwaSIsICJyZXN0IiwgImh0dHAiLCAic2VydmVyIiwgImVuZHBvaW50Iiwg'
    'IndlYmhvb2siXSwKICAgICJweXRob25fY2xpIjogWyJjbGkiLCAiY29tbWFuZCBsaW5lIiwgInNjcmlwdCIsICJ0b29sIiwgImF1'
    'dG9tYXRpb24iXSwKICAgICJ3ZWJfYXBwIjogWyJ3ZWJzaXRlIiwgIndlYiBhcHAiLCAicmVhY3QiLCAiZnJvbnRlbmQiLCAibGFu'
    'ZGluZyBwYWdlIiwgImRhc2hib2FyZCJdLAp9CgoKZGVmIF9jbGFzc2lmeShzcGVjOiBkaWN0KSAtPiBzdHI6CiAgICBibG9iID0g'
    'IiAiLmpvaW4oc3RyKHNwZWMuZ2V0KGssICIiKSkgZm9yIGsgaW4gKCJnb2FsIiwgImRhdGFfbW9kZWwiKSkubG93ZXIoKQogICAg'
    'YmxvYiArPSAiICIgKyAiICIuam9pbihzcGVjLmdldCgiaW50ZXJmYWNlcyIsIFtdKSBvciBbXSkKICAgIGZvciBraW5kLCB3b3Jk'
    'cyBpbiBfS0VZV09SRFMuaXRlbXMoKToKICAgICAgICBpZiBhbnkodyBpbiBibG9iIGZvciB3IGluIHdvcmRzKToKICAgICAgICAg'
    'ICAgcmV0dXJuIGtpbmQKICAgIHJldHVybiAicHl0aG9uX2NsaSIKCgpkZWYgX3NhZmUoc3BlYzogZGljdCwgZGVmYXVsdDogc3Ry'
    'ID0gImEgdG9vbCIsIG46IGludCA9IDYwKSAtPiBzdHI6CiAgICAiIiJBIGdvYWwgc3RyaW5nIHRoYXQgaXMgYWx3YXlzIHNhZmUg'
    'dG8gZHJvcCBpbnNpZGUgYSBxdW90ZWQgbGl0ZXJhbC4iIiIKICAgIHJhdyA9IHN0cihzcGVjLmdldCgiZ29hbCIsIGRlZmF1bHQp'
    'IG9yIGRlZmF1bHQpCiAgICByYXcgPSByZS5zdWIociJbXCInXFxcclxuXHRdKyIsICIgIiwgcmF3KQogICAgcmF3ID0gcmUuc3Vi'
    'KHIiXHMrIiwgIiAiLCByYXcpLnN0cmlwKCkKICAgIHJldHVybiByYXdbOm5dIG9yIGRlZmF1bHQKCgpkZWYgX2h0bWxfZ2FtZShz'
    'cGVjOiBkaWN0KSAtPiBTY2FmZm9sZDoKICAgIHRpdGxlID0gcmUuc3ViKHIiW15BLVphLXowLTkgXSIsICIiLCBzdHIoc3BlYy5n'
    'ZXQoImdvYWwiLCAiR2FtZSIpKSlbOjQwXSBvciAiR2FtZSIKICAgIGluZGV4ID0gIiIiPCFkb2N0eXBlIGh0bWw+CjxodG1sIGxh'
    'bmc9ImVuIj4KPGhlYWQ+CjxtZXRhIGNoYXJzZXQ9InV0Zi04Ii8+CjxtZXRhIG5hbWU9InZpZXdwb3J0IiBjb250ZW50PSJ3aWR0'
    'aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MSIvPgo8dGl0bGU+X19USVRMRV9fPC90aXRsZT4KPHN0eWxlPgogIGh0bWws'
    'Ym9keXttYXJnaW46MDtoZWlnaHQ6MTAwJTtiYWNrZ3JvdW5kOiMwYjBmMTc7Y29sb3I6I2U2ZWRmMzsKICAgICAgICAgICAgZm9u'
    'dC1mYW1pbHk6c3lzdGVtLXVpLFNlZ29lIFVJLFJvYm90byxzYW5zLXNlcmlmfQogICN3cmFwe2Rpc3BsYXk6ZmxleDtmbGV4LWRp'
    'cmVjdGlvbjpjb2x1bW47YWxpZ24taXRlbXM6Y2VudGVyO2dhcDo4cHg7cGFkZGluZzoxMnB4fQogIGNhbnZhc3tiYWNrZ3JvdW5k'
    'OiMxMTE4Mjc7Ym9yZGVyLXJhZGl1czoxMnB4O2JveC1zaGFkb3c6MCA4cHggNDBweCAjMDAwOH0KICAuaHVke2ZvbnQtdmFyaWFu'
    'dC1udW1lcmljOnRhYnVsYXItbnVtcztvcGFjaXR5Oi45fQo8L3N0eWxlPgo8L2hlYWQ+Cjxib2R5Pgo8ZGl2IGlkPSJ3cmFwIj4K'
    'ICA8ZGl2IGNsYXNzPSJodWQiPlNjb3JlOiA8c3BhbiBpZD0ic2NvcmUiPjA8L3NwYW4+PC9kaXY+CiAgPGNhbnZhcyBpZD0iYyIg'
    'd2lkdGg9IjY0MCIgaGVpZ2h0PSI0ODAiPjwvY2FudmFzPgogIDxkaXYgY2xhc3M9Imh1ZCI+QXJyb3dzIC8gV0FTRCB0byBzdGVl'
    'cjwvZGl2Pgo8L2Rpdj4KPHNjcmlwdCBzcmM9ImdhbWUuanMiPjwvc2NyaXB0Pgo8L2JvZHk+CjwvaHRtbD4KIiIiLnJlcGxhY2Uo'
    'Il9fVElUTEVfXyIsIHRpdGxlKQogICAgZ2FtZSA9ICIiIi8vIF9fVElUTEVfXyDigJQgZGV0ZXJtaW5pc3RpYywgdGVzdGFibGUg'
    'SFRNTDUgY2FudmFzIGdhbWUuCihmdW5jdGlvbiAoZ2xvYmFsKSB7CiAgInVzZSBzdHJpY3QiOwogIGZ1bmN0aW9uIGNyZWF0ZVN0'
    'YXRlKCkgewogICAgcmV0dXJuIHsgcGxheWVyOiB7IHg6IDMyMCwgeTogNDAwLCB2eDogMCB9LCBzY29yZTogMCwgdDogMCwKICAg'
    'ICAgICAgICAgIG9ic3RhY2xlczogW3sgeDogMjAwLCB5OiAwLCB3OiA2MCwgaDogNjAsIHZ5OiAzIH1dIH07CiAgfQogIGZ1bmN0'
    'aW9uIHN0ZXAocywgaW5wdXQsIGR0KSB7CiAgICBpbnB1dCA9IGlucHV0IHx8IHt9OwogICAgdmFyIGF4ID0gMDsKICAgIGlmIChp'
    'bnB1dC5sZWZ0KSBheCAtPSAxOwogICAgaWYgKGlucHV0LnJpZ2h0KSBheCArPSAxOwogICAgcy5wbGF5ZXIudnggPSBheCAqIDU7'
    'CiAgICBzLnBsYXllci54ID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oNjQwIC0gMjQsIHMucGxheWVyLnggKyBzLnBsYXllci52eCkp'
    'OwogICAgcy50ICs9IGR0OwogICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzLm9ic3RhY2xlcy5sZW5ndGg7IGkrKykgewogICAgICB2'
    'YXIgbyA9IHMub2JzdGFjbGVzW2ldOwogICAgICBvLnkgKz0gby52eSAqIGR0ICogNjA7CiAgICAgIGlmIChvLnkgPiA0ODApIHsg'
    'by55ID0gLTYwOyBvLnggPSBNYXRoLnJhbmRvbSgpICogKDY0MCAtIG8udyk7IHMuc2NvcmUgKz0gMTsgfQogICAgICBpZiAoTWF0'
    'aC5hYnMoby54IC0gcy5wbGF5ZXIueCkgPCAyNCAmJiBNYXRoLmFicyhvLnkgLSBzLnBsYXllci55KSA8IDI0KSB7CiAgICAgICAg'
    'cy5zY29yZSA9IDA7IG8ueSA9IC02MDsKICAgICAgfQogICAgfQogICAgcmV0dXJuIHM7CiAgfQogIGZ1bmN0aW9uIHJlbmRlcihj'
    'dHgsIHMpIHsKICAgIGN0eC5jbGVhclJlY3QoMCwgMCwgNjQwLCA0ODApOwogICAgY3R4LmZpbGxTdHlsZSA9ICIjMzhiZGY4IjsK'
    'ICAgIGN0eC5maWxsUmVjdChzLnBsYXllci54LCBzLnBsYXllci55LCAyNCwgMjQpOwogICAgY3R4LmZpbGxTdHlsZSA9ICIjZjg3'
    'MTcxIjsKICAgIHMub2JzdGFjbGVzLmZvckVhY2goZnVuY3Rpb24gKG8pIHsgY3R4LmZpbGxSZWN0KG8ueCwgby55LCBvLncsIG8u'
    'aCk7IH0pOwogIH0KICB2YXIgYXBpID0geyBjcmVhdGVTdGF0ZTogY3JlYXRlU3RhdGUsIHN0ZXA6IHN0ZXAsIHJlbmRlcjogcmVu'
    'ZGVyIH07CiAgaWYgKHR5cGVvZiBtb2R1bGUgIT09ICJ1bmRlZmluZWQiICYmIG1vZHVsZS5leHBvcnRzKSBtb2R1bGUuZXhwb3J0'
    'cyA9IGFwaTsKICBnbG9iYWwuU2F2YWdlR2FtZSA9IGFwaTsKfSkodHlwZW9mIHdpbmRvdyAhPT0gInVuZGVmaW5lZCIgPyB3aW5k'
    'b3cgOiBnbG9iYWxUaGlzKTsKIiIiLnJlcGxhY2UoIl9fVElUTEVfXyIsIHRpdGxlKQogICAgdGVzdCA9ICIiIi8vIERldGVybWlu'
    'aXN0aWMgdGVzdCBob29rIGZvciB0aGUgZ2FtZSBjb3JlIChub2RlIHRlc3QuanMpLgp2YXIgZyA9IHJlcXVpcmUoIi4vZ2FtZS5q'
    'cyIpOwp2YXIgcyA9IGcuY3JlYXRlU3RhdGUoKTsKZm9yICh2YXIgaSA9IDA7IGkgPCAxMjA7IGkrKykgZy5zdGVwKHMsIHsgbGVm'
    'dDogaSAlIDIgPT09IDAgfSwgMSAvIDYwKTsKaWYgKHR5cGVvZiBzLnNjb3JlICE9PSAibnVtYmVyIikgeyBjb25zb2xlLmVycm9y'
    'KCJGQUlMOiBzY29yZSBtaXNzaW5nIik7IHByb2Nlc3MuZXhpdCgxKTsgfQpjb25zb2xlLmxvZygiUEFTUzogZ2FtZSBjb3JlIHJh'
    'biAxMjAgZnJhbWVzLCBzY29yZT0iICsgcy5zY29yZSk7CiIiIgogICAgcmV0dXJuIFNjYWZmb2xkKAogICAgICAgIG5hbWU9Imh0'
    'bWxfZ2FtZSIsIGxhbmd1YWdlPSJqYXZhc2NyaXB0IiwKICAgICAgICBmaWxlcz17ImluZGV4Lmh0bWwiOiBpbmRleCwgImdhbWUu'
    'anMiOiBnYW1lLCAidGVzdC5qcyI6IHRlc3R9LAogICAgICAgIGJ1aWxkX2NtZD1bIm5vZGUiLCAiLS1jaGVjayIsICJnYW1lLmpz'
    'Il0sCiAgICAgICAgdGVzdF9jbWQ9WyJub2RlIiwgInRlc3QuanMiXSwKICAgICAgICBydW5faGludD0ib3BlbiBpbmRleC5odG1s'
    'IGluIGEgYnJvd3NlciIsCiAgICApCgoKZGVmIF9weXRob25fY2xpKHNwZWM6IGRpY3QpIC0+IFNjYWZmb2xkOgogICAgbWFpbiA9'
    'ICcnJyIiIkdlbmVyYXRlZCBDTEk6IF9fR09BTF9fIiIiCmZyb20gX19mdXR1cmVfXyBpbXBvcnQgYW5ub3RhdGlvbnMKCmltcG9y'
    'dCBhcmdwYXJzZQppbXBvcnQganNvbgoKCmRlZiBjb3JlKHRleHQ6IHN0cikgLT4gZGljdDoKICAgICIiIlB1cmUgZnVuY3Rpb24g'
    'Y29yZSAoZWFzeSB0byB0ZXN0KS4iIiIKICAgIHJldHVybiB7Imxlbmd0aCI6IGxlbih0ZXh0KSwgInVwcGVyIjogdGV4dC51cHBl'
    'cigpLCAid29yZHMiOiBsZW4odGV4dC5zcGxpdCgpKX0KCgpkZWYgbWFpbihhcmd2PU5vbmUpIC0+IGludDoKICAgIHAgPSBhcmdw'
    'YXJzZS5Bcmd1bWVudFBhcnNlcihkZXNjcmlwdGlvbj0iX19HT0FMX18iKQogICAgcC5hZGRfYXJndW1lbnQoInRleHQiLCBuYXJn'
    'cz0iPyIsIGRlZmF1bHQ9ImhlbGxvIHdvcmxkIikKICAgIHAuYWRkX2FyZ3VtZW50KCItLWpzb24iLCBhY3Rpb249InN0b3JlX3Ry'
    'dWUiKQogICAgYXJncyA9IHAucGFyc2VfYXJncyhhcmd2KQogICAgcmVzdWx0ID0gY29yZShhcmdzLnRleHQpCiAgICBpZiBhcmdz'
    'Lmpzb246CiAgICAgICAgcHJpbnQoanNvbi5kdW1wcyhyZXN1bHQpKQogICAgZWxzZToKICAgICAgICBwcmludChyZXN1bHRbInVw'
    'cGVyIl0pCiAgICByZXR1cm4gMAoKCmlmIF9fbmFtZV9fID09ICJfX21haW5fXyI6CiAgICByYWlzZSBTeXN0ZW1FeGl0KG1haW4o'
    'KSkKJycnLnJlcGxhY2UoIl9fR09BTF9fIiwgX3NhZmUoc3BlYywgImEgdG9vbCIsIDYwKSkKICAgIHRlc3QgPSAnJyciIiJUZXN0'
    'cyBmb3IgdGhlIGdlbmVyYXRlZCBDTEkgKHN0ZGxpYiB1bml0dGVzdCkuIiIiCmltcG9ydCB1bml0dGVzdAoKZnJvbSBtYWluIGlt'
    'cG9ydCBjb3JlCgoKY2xhc3MgQ29yZVRlc3RzKHVuaXR0ZXN0LlRlc3RDYXNlKToKICAgIGRlZiB0ZXN0X2xlbmd0aChzZWxmKToK'
    'ICAgICAgICBzZWxmLmFzc2VydEVxdWFsKGNvcmUoImFiYyIpWyJsZW5ndGgiXSwgMykKCiAgICBkZWYgdGVzdF93b3JkcyhzZWxm'
    'KToKICAgICAgICBzZWxmLmFzc2VydEVxdWFsKGNvcmUoImEgYiBjIilbIndvcmRzIl0sIDMpCgogICAgZGVmIHRlc3RfdXBwZXIo'
    'c2VsZik6CiAgICAgICAgc2VsZi5hc3NlcnRFcXVhbChjb3JlKCJoaSIpWyJ1cHBlciJdLCAiSEkiKQoKCmlmIF9fbmFtZV9fID09'
    'ICJfX21haW5fXyI6CiAgICB1bml0dGVzdC5tYWluKCkKJycnCiAgICByZXR1cm4gU2NhZmZvbGQoCiAgICAgICAgbmFtZT0icHl0'
    'aG9uX2NsaSIsIGxhbmd1YWdlPSJweXRob24iLAogICAgICAgIGZpbGVzPXsibWFpbi5weSI6IG1haW4sICJ0ZXN0X21haW4ucHki'
    'OiB0ZXN0fSwKICAgICAgICBidWlsZF9jbWQ9WyJweXRob24zIiwgIi1tIiwgInB5X2NvbXBpbGUiLCAibWFpbi5weSJdLAogICAg'
    'ICAgIHRlc3RfY21kPVsicHl0aG9uMyIsICJ0ZXN0X21haW4ucHkiXSwKICAgICAgICBydW5faGludD0icHl0aG9uMyBtYWluLnB5'
    'IC0taGVscCIsCiAgICApCgoKZGVmIF9yZXN0X2FwaShzcGVjOiBkaWN0KSAtPiBTY2FmZm9sZDoKICAgIHNlcnZlciA9ICcnJyIi'
    'IkdlbmVyYXRlZCBzdGRsaWIgUkVTVCBBUEk6IF9fR09BTF9fIiIiCmZyb20gX19mdXR1cmVfXyBpbXBvcnQgYW5ub3RhdGlvbnMK'
    'CmltcG9ydCBqc29uCmZyb20gaHR0cC5zZXJ2ZXIgaW1wb3J0IEJhc2VIVFRQUmVxdWVzdEhhbmRsZXIsIEhUVFBTZXJ2ZXIKClNU'
    'T1JFOiBkaWN0ID0ge30KCgpjbGFzcyBIYW5kbGVyKEJhc2VIVFRQUmVxdWVzdEhhbmRsZXIpOgogICAgZGVmIF9zZW5kKHNlbGYs'
    'IGNvZGU6IGludCwgcGF5bG9hZDogZGljdCkgLT4gTm9uZToKICAgICAgICBib2R5ID0ganNvbi5kdW1wcyhwYXlsb2FkKS5lbmNv'
    'ZGUoKQogICAgICAgIHNlbGYuc2VuZF9yZXNwb25zZShjb2RlKQogICAgICAgIHNlbGYuc2VuZF9oZWFkZXIoIkNvbnRlbnQtVHlw'
    'ZSIsICJhcHBsaWNhdGlvbi9qc29uIikKICAgICAgICBzZWxmLnNlbmRfaGVhZGVyKCJDb250ZW50LUxlbmd0aCIsIHN0cihsZW4o'
    'Ym9keSkpKQogICAgICAgIHNlbGYuZW5kX2hlYWRlcnMoKQogICAgICAgIHNlbGYud2ZpbGUud3JpdGUoYm9keSkKCiAgICBkZWYg'
    'ZG9fR0VUKHNlbGYpOgogICAgICAgIGlmIHNlbGYucGF0aCA9PSAiL2hlYWx0aCI6CiAgICAgICAgICAgIHJldHVybiBzZWxmLl9z'
    'ZW5kKDIwMCwgeyJzdGF0dXMiOiAib2sifSkKICAgICAgICBpZiBzZWxmLnBhdGggPT0gIi9pdGVtcyI6CiAgICAgICAgICAgIHJl'
    'dHVybiBzZWxmLl9zZW5kKDIwMCwgeyJpdGVtcyI6IGxpc3QoU1RPUkUudmFsdWVzKCkpfSkKICAgICAgICByZXR1cm4gc2VsZi5f'
    'c2VuZCg0MDQsIHsiZXJyb3IiOiAibm90IGZvdW5kIn0pCgogICAgZGVmIGRvX1BPU1Qoc2VsZik6CiAgICAgICAgaWYgc2VsZi5w'
    'YXRoICE9ICIvaXRlbXMiOgogICAgICAgICAgICByZXR1cm4gc2VsZi5fc2VuZCg0MDQsIHsiZXJyb3IiOiAibm90IGZvdW5kIn0p'
    'CiAgICAgICAgbiA9IGludChzZWxmLmhlYWRlcnMuZ2V0KCJDb250ZW50LUxlbmd0aCIsIDApKQogICAgICAgIHRyeToKICAgICAg'
    'ICAgICAgZGF0YSA9IGpzb24ubG9hZHMoc2VsZi5yZmlsZS5yZWFkKG4pIG9yIGIie30iKQogICAgICAgIGV4Y2VwdCBFeGNlcHRp'
    'b246CiAgICAgICAgICAgIHJldHVybiBzZWxmLl9zZW5kKDQwMCwgeyJlcnJvciI6ICJiYWQganNvbiJ9KQogICAgICAgIGlmICJu'
    'YW1lIiBub3QgaW4gZGF0YToKICAgICAgICAgICAgcmV0dXJuIHNlbGYuX3NlbmQoNDIyLCB7ImVycm9yIjogIm5hbWUgcmVxdWly'
    'ZWQifSkKICAgICAgICBrZXkgPSBzdHIobGVuKFNUT1JFKSArIDEpCiAgICAgICAgU1RPUkVba2V5XSA9IHsiaWQiOiBrZXksICJu'
    'YW1lIjogZGF0YVsibmFtZSJdfQogICAgICAgIHJldHVybiBzZWxmLl9zZW5kKDIwMSwgU1RPUkVba2V5XSkKCiAgICBkZWYgbG9n'
    'X21lc3NhZ2Uoc2VsZiwgKmEpOiAgIyBzaWxlbmNlCiAgICAgICAgcGFzcwoKCmRlZiBzZXJ2ZShwb3J0OiBpbnQgPSA4MDAwKSAt'
    'PiBOb25lOgogICAgSFRUUFNlcnZlcigoIjEyNy4wLjAuMSIsIHBvcnQpLCBIYW5kbGVyKS5zZXJ2ZV9mb3JldmVyKCkKCgppZiBf'
    'X25hbWVfXyA9PSAiX19tYWluX18iOgogICAgc2VydmUoKQonJycucmVwbGFjZSgiX19HT0FMX18iLCBfc2FmZShzcGVjLCAiYW4g'
    'YXBpIiwgNjApKQogICAgdGVzdCA9ICcnJyIiIlRlc3RzIGZvciB0aGUgZ2VuZXJhdGVkIFJFU1QgQVBJIChzdGRsaWIgdW5pdHRl'
    'c3QpLiIiIgppbXBvcnQganNvbgppbXBvcnQgdGhyZWFkaW5nCmltcG9ydCB1bml0dGVzdAppbXBvcnQgdXJsbGliLnJlcXVlc3QK'
    'ZnJvbSBodHRwLnNlcnZlciBpbXBvcnQgSFRUUFNlcnZlcgoKZnJvbSBzZXJ2ZXIgaW1wb3J0IEhhbmRsZXIKCgpkZWYgX3NlcnZl'
    'KCk6CiAgICBzcnYgPSBIVFRQU2VydmVyKCgiMTI3LjAuMC4xIiwgMCksIEhhbmRsZXIpCiAgICB0aHJlYWRpbmcuVGhyZWFkKHRh'
    'cmdldD1zcnYuc2VydmVfZm9yZXZlciwgZGFlbW9uPVRydWUpLnN0YXJ0KCkKICAgIHJldHVybiBzcnYsIHNydi5zZXJ2ZXJfYWRk'
    'cmVzc1sxXQoKCmNsYXNzIEFwaVRlc3RzKHVuaXR0ZXN0LlRlc3RDYXNlKToKICAgIGRlZiB0ZXN0X2hlYWx0aChzZWxmKToKICAg'
    'ICAgICBzcnYsIHBvcnQgPSBfc2VydmUoKQogICAgICAgIHRyeToKICAgICAgICAgICAgd2l0aCB1cmxsaWIucmVxdWVzdC51cmxv'
    'cGVuKCJodHRwOi8vMTI3LjAuMC4xOiVkL2hlYWx0aCIgJSBwb3J0KSBhcyByOgogICAgICAgICAgICAgICAgc2VsZi5hc3NlcnRF'
    'cXVhbChqc29uLmxvYWRzKHIucmVhZCgpKVsic3RhdHVzIl0sICJvayIpCiAgICAgICAgZmluYWxseToKICAgICAgICAgICAgc3J2'
    'LnNodXRkb3duKCkKCiAgICBkZWYgdGVzdF9wb3N0X2l0ZW0oc2VsZik6CiAgICAgICAgc3J2LCBwb3J0ID0gX3NlcnZlKCkKICAg'
    'ICAgICB0cnk6CiAgICAgICAgICAgIHJlcSA9IHVybGxpYi5yZXF1ZXN0LlJlcXVlc3QoCiAgICAgICAgICAgICAgICAiaHR0cDov'
    'LzEyNy4wLjAuMTolZC9pdGVtcyIgJSBwb3J0LAogICAgICAgICAgICAgICAgZGF0YT1qc29uLmR1bXBzKHsibmFtZSI6ICJ3aWRn'
    'ZXQifSkuZW5jb2RlKCksCiAgICAgICAgICAgICAgICBoZWFkZXJzPXsiQ29udGVudC1UeXBlIjogImFwcGxpY2F0aW9uL2pzb24i'
    'fSwgbWV0aG9kPSJQT1NUIikKICAgICAgICAgICAgd2l0aCB1cmxsaWIucmVxdWVzdC51cmxvcGVuKHJlcSkgYXMgcjoKICAgICAg'
    'ICAgICAgICAgIHNlbGYuYXNzZXJ0RXF1YWwoci5zdGF0dXMsIDIwMSkKICAgICAgICBmaW5hbGx5OgogICAgICAgICAgICBzcnYu'
    'c2h1dGRvd24oKQoKCmlmIF9fbmFtZV9fID09ICJfX21haW5fXyI6CiAgICB1bml0dGVzdC5tYWluKCkKJycnCiAgICByZXR1cm4g'
    'U2NhZmZvbGQoCiAgICAgICAgbmFtZT0icmVzdF9hcGkiLCBsYW5ndWFnZT0icHl0aG9uIiwKICAgICAgICBmaWxlcz17InNlcnZl'
    'ci5weSI6IHNlcnZlciwgInRlc3Rfc2VydmVyLnB5IjogdGVzdH0sCiAgICAgICAgYnVpbGRfY21kPVsicHl0aG9uMyIsICItbSIs'
    'ICJweV9jb21waWxlIiwgInNlcnZlci5weSJdLAogICAgICAgIHRlc3RfY21kPVsicHl0aG9uMyIsICJ0ZXN0X3NlcnZlci5weSJd'
    'LAogICAgICAgIHJ1bl9oaW50PSJweXRob24zIHNlcnZlci5weSIsCiAgICApCgoKZGVmIF9hbmRyb2lkKHNwZWM6IGRpY3QpIC0+'
    'IFNjYWZmb2xkOgogICAgbWFuaWZlc3QgPSAnJyc8P3htbCB2ZXJzaW9uPSIxLjAiIGVuY29kaW5nPSJ1dGYtOCI/Pgo8bWFuaWZl'
    'c3QgeG1sbnM6YW5kcm9pZD0iaHR0cDovL3NjaGVtYXMuYW5kcm9pZC5jb20vYXBrL3Jlcy9hbmRyb2lkIgogICAgcGFja2FnZT0i'
    'Y29tLnNhdmFnZS5nZW5lcmF0ZWQiPgogICAgPHVzZXMtcGVybWlzc2lvbiBhbmRyb2lkOm5hbWU9ImFuZHJvaWQucGVybWlzc2lv'
    'bi5JTlRFUk5FVCIvPgogICAgPGFwcGxpY2F0aW9uIGFuZHJvaWQ6bGFiZWw9IkdlbmVyYXRlZCIgYW5kcm9pZDp0aGVtZT0iQGFu'
    'ZHJvaWQ6c3R5bGUvVGhlbWUuTWF0ZXJpYWwiPgogICAgICAgIDxhY3Rpdml0eSBhbmRyb2lkOm5hbWU9Ii5NYWluQWN0aXZpdHki'
    'IGFuZHJvaWQ6ZXhwb3J0ZWQ9InRydWUiPgogICAgICAgICAgICA8aW50ZW50LWZpbHRlcj4KICAgICAgICAgICAgICAgIDxhY3Rp'
    'b24gYW5kcm9pZDpuYW1lPSJhbmRyb2lkLmludGVudC5hY3Rpb24uTUFJTiIvPgogICAgICAgICAgICAgICAgPGNhdGVnb3J5IGFu'
    'ZHJvaWQ6bmFtZT0iYW5kcm9pZC5pbnRlbnQuY2F0ZWdvcnkuTEFVTkNIRVIiLz4KICAgICAgICAgICAgPC9pbnRlbnQtZmlsdGVy'
    'PgogICAgICAgIDwvYWN0aXZpdHk+CiAgICA8L2FwcGxpY2F0aW9uPgo8L21hbmlmZXN0PgonJycKICAgIGFjdGl2aXR5ID0gJycn'
    'cGFja2FnZSBjb20uc2F2YWdlLmdlbmVyYXRlZDsKCmltcG9ydCBhbmRyb2lkLmFwcC5BY3Rpdml0eTsKaW1wb3J0IGFuZHJvaWQu'
    'b3MuQnVuZGxlOwppbXBvcnQgYW5kcm9pZC53aWRnZXQuVGV4dFZpZXc7CgpwdWJsaWMgY2xhc3MgTWFpbkFjdGl2aXR5IGV4dGVu'
    'ZHMgQWN0aXZpdHkgewogICAgQE92ZXJyaWRlCiAgICBwcm90ZWN0ZWQgdm9pZCBvbkNyZWF0ZShCdW5kbGUgc2F2ZWRJbnN0YW5j'
    'ZVN0YXRlKSB7CiAgICAgICAgc3VwZXIub25DcmVhdGUoc2F2ZWRJbnN0YW5jZVN0YXRlKTsKICAgICAgICBUZXh0VmlldyB0diA9'
    'IG5ldyBUZXh0Vmlldyh0aGlzKTsKICAgICAgICB0di5zZXRUZXh0KCJfX0dPQUxfXyIpOwogICAgICAgIHNldENvbnRlbnRWaWV3'
    'KHR2KTsKICAgIH0KfQonJycucmVwbGFjZSgiX19HT0FMX18iLCBfc2FmZShzcGVjLCAiR2VuZXJhdGVkIGFwcCIsIDYwKSkKICAg'
    'IHZhbGlkYXRlID0gJycnIiIiU3RhdGljIHN0cnVjdHVyYWwgdmFsaWRhdGlvbiBmb3IgdGhlIGdlbmVyYXRlZCBBbmRyb2lkIHBy'
    'b2plY3QuCgpUaGlzIGRvZXMgTk9UIGJ1aWxkIGFuIEFQSyAtLSB0aGF0IG5lZWRzIHRoZSBBbmRyb2lkIFNESyBhbmQgaGFwcGVu'
    'cyBpbiB0aGUKaXNvbGF0ZWQgY2VsbCBmYWN0b3J5L3NwYWNlcy9hcGstY2xpLiAgSXQgcHJvdmVzIHRoZSBwcm9qZWN0IGlzIHdl'
    'bGwtZm9ybWVkIHNvCnRoZSBoYXJuZXNzIGNhbiBnYXRlIGl0IGhvbmVzdGx5IGluIGEgcGxhaW4gZW52aXJvbm1lbnQuCiIiIgpp'
    'bXBvcnQgc3lzCmltcG9ydCB4bWwuZXRyZWUuRWxlbWVudFRyZWUgYXMgRVQKZnJvbSBwYXRobGliIGltcG9ydCBQYXRoCgpST09U'
    'ID0gUGF0aChfX2ZpbGVfXykucmVzb2x2ZSgpLnBhcmVudAoKCmRlZiBjaGVjaygpOgogICAgcHJvYmxlbXMgPSBbXQogICAgbWFu'
    'aWZlc3QgPSBST09UIC8gIkFuZHJvaWRNYW5pZmVzdC54bWwiCiAgICBpZiBub3QgbWFuaWZlc3QuZXhpc3RzKCk6CiAgICAgICAg'
    'cHJvYmxlbXMuYXBwZW5kKCJBbmRyb2lkTWFuaWZlc3QueG1sIG1pc3NpbmciKQogICAgZWxzZToKICAgICAgICB0cnk6CiAgICAg'
    'ICAgICAgIEVULnBhcnNlKHN0cihtYW5pZmVzdCkpCiAgICAgICAgZXhjZXB0IEV4Y2VwdGlvbiBhcyBleGM6CiAgICAgICAgICAg'
    'IHByb2JsZW1zLmFwcGVuZCgiQW5kcm9pZE1hbmlmZXN0LnhtbCBub3Qgd2VsbC1mb3JtZWQ6ICVyIiAlIGV4YykKICAgIGphdmEg'
    'PSBST09UIC8gInNyYyIgLyAiY29tIiAvICJzYXZhZ2UiIC8gImdlbmVyYXRlZCIgLyAiTWFpbkFjdGl2aXR5LmphdmEiCiAgICBp'
    'ZiBub3QgamF2YS5leGlzdHMoKToKICAgICAgICBwcm9ibGVtcy5hcHBlbmQoIk1haW5BY3Rpdml0eS5qYXZhIG1pc3NpbmciKQog'
    'ICAgZWxzZToKICAgICAgICBzcmMgPSBqYXZhLnJlYWRfdGV4dCgpCiAgICAgICAgaWYgc3JjLmNvdW50KCJ7IikgIT0gc3JjLmNv'
    'dW50KCJ9Iik6CiAgICAgICAgICAgIHByb2JsZW1zLmFwcGVuZCgiTWFpbkFjdGl2aXR5LmphdmEgYnJhY2VzIHVuYmFsYW5jZWQi'
    'KQogICAgICAgIGlmICJwYWNrYWdlIGNvbS5zYXZhZ2UuZ2VuZXJhdGVkOyIgbm90IGluIHNyYzoKICAgICAgICAgICAgcHJvYmxl'
    'bXMuYXBwZW5kKCJNYWluQWN0aXZpdHkuamF2YSBwYWNrYWdlIGRlY2xhcmF0aW9uIHdyb25nIikKICAgICAgICBpZiAiZXh0ZW5k'
    'cyBBY3Rpdml0eSIgbm90IGluIHNyYzoKICAgICAgICAgICAgcHJvYmxlbXMuYXBwZW5kKCJNYWluQWN0aXZpdHkuamF2YSBkb2Vz'
    'IG5vdCBleHRlbmQgQWN0aXZpdHkiKQogICAgcmV0dXJuIHByb2JsZW1zCgoKaWYgX19uYW1lX18gPT0gIl9fbWFpbl9fIjoKICAg'
    'IHByb2JzID0gY2hlY2soKQogICAgaWYgcHJvYnM6CiAgICAgICAgZm9yIHAgaW4gcHJvYnM6CiAgICAgICAgICAgIHByaW50KCJG'
    'QUlMOiIsIHApCiAgICAgICAgc3lzLmV4aXQoMSkKICAgIHByaW50KCJQQVNTOiBzdGF0aWMgQW5kcm9pZCB2YWxpZGF0aW9uIChu'
    'byBTREs7IHJlYWwgQVBLIGJ1aWxkcyBpbiBmYWN0b3J5L3NwYWNlcy9hcGstY2xpKSIpCicnJwogICAgdGVzdCA9ICcnJyIiInVu'
    'aXR0ZXN0IHdyYXBwZXIgYXJvdW5kIHRoZSBzdGF0aWMgQW5kcm9pZCB2YWxpZGF0b3IuIiIiCmltcG9ydCB1bml0dGVzdAoKaW1w'
    'b3J0IHZhbGlkYXRlCgoKY2xhc3MgQW5kcm9pZFRlc3RzKHVuaXR0ZXN0LlRlc3RDYXNlKToKICAgIGRlZiB0ZXN0X3N0cnVjdHVy'
    'ZShzZWxmKToKICAgICAgICBzZWxmLmFzc2VydEVxdWFsKHZhbGlkYXRlLmNoZWNrKCksIFtdKQoKCmlmIF9fbmFtZV9fID09ICJf'
    'X21haW5fXyI6CiAgICB1bml0dGVzdC5tYWluKCkKJycnCiAgICBidWlsZCA9ICcnJyMhL3Vzci9iaW4vZW52IGJhc2gKIyBUcnkg'
    'YSByZWFsIGdyYWRsZSBidWlsZDsgb3RoZXJ3aXNlIGZhbGwgYmFjayB0byBob25lc3Qgc3RhdGljIHZhbGlkYXRpb24uCnNldCAt'
    'ZXVvIHBpcGVmYWlsCmNkICIkKGRpcm5hbWUgIiR7QkFTSF9TT1VSQ0VbMF19IikiCmlmIGNvbW1hbmQgLXYgZ3JhZGxlID4vZGV2'
    'L251bGwgMj4mMSAmJiBbIC1mIGJ1aWxkLmdyYWRsZSBdOyB0aGVuCiAgZWNobyAiPT09IGdyYWRsZSBhc3NlbWJsZURlYnVnID09'
    'PSIKICBncmFkbGUgLS1uby1kYWVtb24gYXNzZW1ibGVEZWJ1ZwplbHNlCiAgZWNobyAiPT09IG5vIEFuZHJvaWQgU0RLL2dyYWRs'
    'ZTogc3RhdGljIHZhbGlkYXRpb24gb25seSA9PT0iCiAgcHl0aG9uMyB2YWxpZGF0ZS5weQpmaQonJycKICAgIHJldHVybiBTY2Fm'
    'Zm9sZCgKICAgICAgICBuYW1lPSJhbmRyb2lkIiwgbGFuZ3VhZ2U9ImphdmEiLAogICAgICAgIGZpbGVzPXsiQW5kcm9pZE1hbmlm'
    'ZXN0LnhtbCI6IG1hbmlmZXN0LAogICAgICAgICAgICAgICAic3JjL2NvbS9zYXZhZ2UvZ2VuZXJhdGVkL01haW5BY3Rpdml0eS5q'
    'YXZhIjogYWN0aXZpdHksCiAgICAgICAgICAgICAgICJ2YWxpZGF0ZS5weSI6IHZhbGlkYXRlLCAidGVzdF9hbmRyb2lkLnB5Ijog'
    'dGVzdCwgImJ1aWxkLnNoIjogYnVpbGR9LAogICAgICAgIGJ1aWxkX2NtZD1bImJhc2giLCAiYnVpbGQuc2giXSwKICAgICAgICB0'
    'ZXN0X2NtZD1bInB5dGhvbjMiLCAidGVzdF9hbmRyb2lkLnB5Il0sCiAgICAgICAgcnVuX2hpbnQ9InJlYWwgQVBLIGJ1aWxkIHJ1'
    'bnMgaW4gZmFjdG9yeS9zcGFjZXMvYXBrLWNsaSIsCiAgICApCgoKZGVmIF93ZWJfYXBwKHNwZWM6IGRpY3QpIC0+IFNjYWZmb2xk'
    'OgogICAgaW5kZXggPSAiIiI8IWRvY3R5cGUgaHRtbD4KPGh0bWwgbGFuZz0iZW4iPjxoZWFkPjxtZXRhIGNoYXJzZXQ9InV0Zi04'
    'Ii8+CjxtZXRhIG5hbWU9InZpZXdwb3J0IiBjb250ZW50PSJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MSIvPgo8'
    'dGl0bGU+X19USVRMRV9fPC90aXRsZT4KPHN0eWxlPgogYm9keXttYXJnaW46MDtmb250LWZhbWlseTpzeXN0ZW0tdWksU2Vnb2Ug'
    'VUksUm9ib3RvLHNhbnMtc2VyaWY7YmFja2dyb3VuZDojMGIwZjE3O2NvbG9yOiNlNmVkZjN9CiBoZWFkZXJ7cGFkZGluZzo0OHB4'
    'IDI0cHg7dGV4dC1hbGlnbjpjZW50ZXJ9CiBoMXtmb250LXNpemU6Mi40cmVtO21hcmdpbjowIDAgOHB4fQogbWFpbnttYXgtd2lk'
    'dGg6ODIwcHg7bWFyZ2luOjAgYXV0bztwYWRkaW5nOjI0cHh9CiAuY2FyZHtiYWNrZ3JvdW5kOiMxMTE4Mjc7Ym9yZGVyOjFweCBz'
    'b2xpZCAjMWYyOTM3O2JvcmRlci1yYWRpdXM6MTZweDtwYWRkaW5nOjIwcHg7bWFyZ2luOjEycHggMH0KPC9zdHlsZT48L2hlYWQ+'
    'Cjxib2R5Pgo8aGVhZGVyPjxoMT5fX1RJVExFX188L2gxPjxwPkdlbmVyYXRlZCB3ZWIgYXBwLjwvcD48L2hlYWRlcj4KPG1haW4+'
    'CiA8ZGl2IGNsYXNzPSJjYXJkIj48aDI+T3ZlcnZpZXc8L2gyPjxwPl9fR09BTF9fPC9wPjwvZGl2PgogPGRpdiBjbGFzcz0iY2Fy'
    'ZCI+PGgyPlN0YXR1czwvaDI+PHAgaWQ9InN0YXR1cyI+cmVhZHk8L3A+PC9kaXY+CjwvbWFpbj4KPHNjcmlwdCBzcmM9ImFwcC5q'
    'cyI+PC9zY3JpcHQ+CjwvYm9keT48L2h0bWw+CiIiIi5yZXBsYWNlKCJfX1RJVExFX18iLCBfc2FmZShzcGVjLCAiV2ViIEFwcCIs'
    'IDQwKSkucmVwbGFjZSgKICAgICAgICAiX19HT0FMX18iLCBfc2FmZShzcGVjLCAiYSB3ZWIgYXBwIiwgMTYwKSkKICAgIGFwcCA9'
    'ICIiIi8vIEdlbmVyYXRlZCB3ZWIgYXBwIGxvZ2ljLgooZnVuY3Rpb24gKCkgewogICJ1c2Ugc3RyaWN0IjsKICBmdW5jdGlvbiBp'
    'bml0KCkgewogICAgdmFyIGVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoInN0YXR1cyIpOwogICAgaWYgKGVsKSBlbC50ZXh0'
    'Q29udGVudCA9ICJyZWFkeSI7CiAgfQogIGlmICh0eXBlb2YgZG9jdW1lbnQgIT09ICJ1bmRlZmluZWQiKSBkb2N1bWVudC5hZGRF'
    'dmVudExpc3RlbmVyKCJET01Db250ZW50TG9hZGVkIiwgaW5pdCk7CiAgaWYgKHR5cGVvZiBtb2R1bGUgIT09ICJ1bmRlZmluZWQi'
    'ICYmIG1vZHVsZS5leHBvcnRzKSBtb2R1bGUuZXhwb3J0cyA9IHsgaW5pdDogaW5pdCB9Owp9KSgpOwoiIiIKICAgIHRlc3QgPSAi'
    'IiJ2YXIgYXBwID0gcmVxdWlyZSgiLi9hcHAuanMiKTsKaWYgKHR5cGVvZiBhcHAuaW5pdCAhPT0gImZ1bmN0aW9uIikgeyBjb25z'
    'b2xlLmVycm9yKCJGQUlMIik7IHByb2Nlc3MuZXhpdCgxKTsgfQpjb25zb2xlLmxvZygiUEFTUzogd2ViIGFwcCBtb2R1bGUgbG9h'
    'ZHMiKTsKIiIiCiAgICByZXR1cm4gU2NhZmZvbGQoCiAgICAgICAgbmFtZT0id2ViX2FwcCIsIGxhbmd1YWdlPSJqYXZhc2NyaXB0'
    'IiwKICAgICAgICBmaWxlcz17ImluZGV4Lmh0bWwiOiBpbmRleCwgImFwcC5qcyI6IGFwcCwgInRlc3QuanMiOiB0ZXN0fSwKICAg'
    'ICAgICBidWlsZF9jbWQ9WyJub2RlIiwgIi0tY2hlY2siLCAiYXBwLmpzIl0sCiAgICAgICAgdGVzdF9jbWQ9WyJub2RlIiwgInRl'
    'c3QuanMiXSwKICAgICAgICBydW5faGludD0ib3BlbiBpbmRleC5odG1sIiwKICAgICkKCgpfQlVJTERFUlMgPSB7CiAgICAiaHRt'
    'bF9nYW1lIjogX2h0bWxfZ2FtZSwKICAgICJweXRob25fY2xpIjogX3B5dGhvbl9jbGksCiAgICAicmVzdF9hcGkiOiBfcmVzdF9h'
    'cGksCiAgICAiYW5kcm9pZCI6IF9hbmRyb2lkLAogICAgIndlYl9hcHAiOiBfd2ViX2FwcCwKfQoKCmRlZiBzZWxlY3Qoc3BlYzog'
    'ZGljdCkgLT4gU2NhZmZvbGQ6CiAgICBraW5kID0gX2NsYXNzaWZ5KHNwZWMpCiAgICByZXR1cm4gX0JVSUxERVJTW2tpbmRdKHNw'
    'ZWMpCiNAQEZJTEU6c2F2YWdlL3ByZW1pdW0vc3BlYy5weUBACiIiIkwxIOKAlCBTcGVjIEFtcGxpZmllci4KClR1cm4gYSBvbmUt'
    'bGluZSBwcm9tcHQgaW50byBhIHR5cGVkLCB0ZXN0YWJsZSBzcGVjLiAgVGhlIG1vZGVsIGlzIGFza2VkIGZvciBKU09OCmFuZCB0'
    'aGUgcmVzdWx0IGlzIHZhbGlkYXRlZCArIHJlcGFpcmVkLiAgSWYgbm8gbW9kZWwgaXMgYXZhaWxhYmxlIChvZmZsaW5lKSwgYQpk'
    'ZXRlcm1pbmlzdGljIHNwZWMgaXMgc3ludGhlc2lzZWQgc28gdGhlIHBpcGVsaW5lIHN0aWxsIHJ1bnMuCiIiIgpmcm9tIF9fZnV0'
    'dXJlX18gaW1wb3J0IGFubm90YXRpb25zCgppbXBvcnQganNvbgpmcm9tIHR5cGluZyBpbXBvcnQgT3B0aW9uYWwKCmZyb20gLi5s'
    'bG0uY2xpZW50IGltcG9ydCBMTE1DbGllbnQKZnJvbSAuIGltcG9ydCBkZWNvZGUsIHJldHJpZXZlCgpfU1lTVEVNID0gKAogICAg'
    'IllvdSBhcmUgYSBzZW5pb3Igc29mdHdhcmUgYXJjaGl0ZWN0LiBUdXJuIHRoZSB1c2VyIHJlcXVlc3QgaW50byBhIEpTT04gc3Bl'
    'YyAiCiAgICAid2l0aCBFWEFDVExZIHRoZXNlIGtleXM6IGdvYWwgKHN0cmluZyksIG5vbl9nb2FscyAoYXJyYXkgb2Ygc3RyaW5n'
    'cyksICIKICAgICJhY2NlcHRhbmNlX3Rlc3RzIChhcnJheSBvZiA+PTMgb2JqZWN0cyB3aXRoIG5hbWUgYW5kIGNoZWNrKSwgaW50'
    'ZXJmYWNlcyAiCiAgICAiKGFycmF5IG9mIHN0cmluZ3MpLCBkYXRhX21vZGVsIChzdHJpbmcpLCByaXNrcyAoYXJyYXkgb2Ygc3Ry'
    'aW5ncykuICIKICAgICJFdmVyeSBhY2NlcHRhbmNlIHRlc3QncyAnY2hlY2snIG11c3QgYmUgYSBjb25jcmV0ZSBzaGVsbCBjb21t'
    'YW5kIG9yIGEgIgogICAgImJvb2xlYW4gcHJlZGljYXRlLiBSZXBseSB3aXRoIEpTT04gb25seS4iCikKCgpkZWYgX29mZmxpbmVf'
    'c3BlYyhwcm9tcHQ6IHN0cikgLT4gZGljdDoKICAgIHAgPSBwcm9tcHQuc3RyaXAoKSBvciAiYSBzbWFsbCB0b29sIgogICAgcmV0'
    'dXJuIHsKICAgICAgICAiZ29hbCI6ICJCdWlsZDogIiArIHAsCiAgICAgICAgIm5vbl9nb2FscyI6IFsiTm8gY2xvdWQgZGVwZW5k'
    'ZW5jaWVzIiwgIk5vIG5ldHdvcmsgdW5sZXNzIHJlcXVpcmVkIl0sCiAgICAgICAgImFjY2VwdGFuY2VfdGVzdHMiOiBbCiAgICAg'
    'ICAgICAgIHsibmFtZSI6ICJidWlsZHMiLCAiY2hlY2siOiAidGhlIHByb2plY3QgY29tcGlsZXMgd2l0aCBpdHMgYnVpbGQgY29t'
    'bWFuZCJ9LAogICAgICAgICAgICB7Im5hbWUiOiAidGVzdHMgcGFzcyIsICJjaGVjayI6ICJ0aGUgcHJvamVjdCdzIHRlc3QgY29t'
    'bWFuZCBleGl0cyAwIn0sCiAgICAgICAgICAgIHsibmFtZSI6ICJubyBob2xsb3cgY29kZSIsICJjaGVjayI6ICJubyByZXR1cm4g'
    'VHJ1ZSAvIE5vdEltcGxlbWVudGVkRXJyb3IgZ2F0ZXMifSwKICAgICAgICBdLAogICAgICAgICJpbnRlcmZhY2VzIjogWyJDTEkg'
    'b3IgSFRUUCBlbnRyeXBvaW50IiwgInB1cmUgY29yZSBmdW5jdGlvbiJdLAogICAgICAgICJkYXRhX21vZGVsIjogIm1pbmltYWwg'
    'aW4tbWVtb3J5IG1vZGVsIiwKICAgICAgICAicmlza3MiOiBbImFtYmlndW91cyByZXF1aXJlbWVudHMiLCAibWlzc2luZyBydW50'
    'aW1lIGRlcHMiXSwKICAgIH0KCgpkZWYgYW1wbGlmeShwcm9tcHQ6IHN0ciwgKiwgY2xpZW50OiBPcHRpb25hbFtMTE1DbGllbnRd'
    'ID0gTm9uZSkgLT4gZGljdDoKICAgIGdvbGQgPSByZXRyaWV2ZS5yZXRyaWV2ZShwcm9tcHQsIGs9MikKICAgIGdvbGRfdHh0ID0g'
    'anNvbi5kdW1wcyhnb2xkLCBpbmRlbnQ9MikgaWYgZ29sZCBlbHNlICIobm9uZSkiCiAgICBjbGllbnQgPSBjbGllbnQgb3IgTExN'
    'Q2xpZW50KCkKICAgIG1lc3NhZ2VzID0gWwogICAgICAgIHsicm9sZSI6ICJzeXN0ZW0iLCAiY29udGVudCI6IF9TWVNURU19LAog'
    'ICAgICAgIHsicm9sZSI6ICJ1c2VyIiwgImNvbnRlbnQiOgogICAgICAgICAgICAiUmVxdWVzdDogIiArIHByb21wdCArICJcblxu'
    'UHJvdmVuIGV4YW1wbGVzOlxuIiArIGdvbGRfdHh0ICsKICAgICAgICAgICAgIlxuXG5HcmFtbWFyIChmb3IgcmVmZXJlbmNlKTpc'
    'biIgKyBkZWNvZGUuU1BFQ19HQk5GfSwKICAgIF0KICAgIHJhdyA9IGNsaWVudC5jaGF0KG1lc3NhZ2VzLCBjbHM9InByZW1pdW0i'
    'LCB0ZW1wZXJhdHVyZT0wLjIsCiAgICAgICAgICAgICAgICAgICAgICByZXNwb25zZV9mb3JtYXQ9eyJ0eXBlIjogImpzb25fb2Jq'
    'ZWN0In0pCiAgICBvYmogPSBkZWNvZGUucmVwYWlyX2pzb24ocmF3KQogICAgb2ssIGVycnMgPSBkZWNvZGUudmFsaWRhdGVfc3Bl'
    'YyhvYmopCiAgICBpZiBub3Qgb2s6CiAgICAgICAgIyBvbmUgcmVwYWlyIHJvdW5kLCB0aGVuIGZhbGwgYmFjawogICAgICAgIHJh'
    'dzIgPSBjbGllbnQuY2hhdCgKICAgICAgICAgICAgbWVzc2FnZXMgKyBbeyJyb2xlIjogInVzZXIiLCAiY29udGVudCI6CiAgICAg'
    'ICAgICAgICAgICAgICAgICAgICAiVGhhdCB3YXMgaW52YWxpZDogIiArICI7ICIuam9pbihlcnJzKSArICIuIFJldHVybiB2YWxp'
    'ZCBKU09OIG9ubHkuIn1dLAogICAgICAgICAgICBjbHM9InByZW1pdW0iLCB0ZW1wZXJhdHVyZT0wLjAsCiAgICAgICAgICAgIHJl'
    'c3BvbnNlX2Zvcm1hdD17InR5cGUiOiAianNvbl9vYmplY3QifSkKICAgICAgICBvYmogPSBkZWNvZGUucmVwYWlyX2pzb24ocmF3'
    'MikKICAgICAgICBvaywgXyA9IGRlY29kZS52YWxpZGF0ZV9zcGVjKG9iaikKICAgIGlmIG5vdCBvayBvciAoaXNpbnN0YW5jZShv'
    'YmosIGRpY3QpIGFuZCBvYmouZ2V0KCJvZmZsaW5lIikpOgogICAgICAgIHJldHVybiBfb2ZmbGluZV9zcGVjKHByb21wdCkKICAg'
    'IG9ialsiX3NvdXJjZV9wcm9tcHQiXSA9IHByb21wdAogICAgcmV0dXJuIG9iagojQEBGSUxFOnNhdmFnZS9wcmVtaXVtL3Zlcmlm'
    'aWVyLnB5QEAKIiIiTDQg4oCUIFZlcmlmaWVyIC8gRW5zZW1ibGUuCgpSYW5rIGNhbmRpZGF0ZXMgZGV0ZXJtaW5pc3RpY2FsbHkg'
    'Zmlyc3QgKGJ1aWxkICsgdGVzdHMgKyBhbnRpLWhvbGxvdyBzY2FuKSwgdGhlbgpvcHRpb25hbGx5IGFzayBhIERJRkZFUkVOVCBt'
    'b2RlbCBjbGFzcyB0byBicmVhayB0aWVzLiAgVGhlIGdlbmVyYXRpbmcgbW9kZWwgYW5kCnRoZSB2ZXJpZnlpbmcgbW9kZWwgYXJl'
    'IG5ldmVyIHRoZSBzYW1lIGNsYXNzLgoiIiIKZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IG9zCmlt'
    'cG9ydCBzdWJwcm9jZXNzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aApmcm9tIHR5cGluZyBpbXBvcnQgTGlzdCwgT3B0aW9uYWwK'
    'CmZyb20gLi5sbG0uY2xpZW50IGltcG9ydCBMTE1DbGllbnQKZnJvbSAuc2NhZmZvbGQgaW1wb3J0IFNjYWZmb2xkCmZyb20gLnNh'
    'bXBsZXIgaW1wb3J0IENhbmRpZGF0ZQoKIyBBc3NlbWJsZWQgZnJvbSBmcmFnbWVudHMgc28gdGhpcyBkZXRlY3RvciBuZXZlciB0'
    'cmlwcyBvdmVyIGl0cyBvd24gc291cmNlLgpfSE9MTE9XID0gKCJyZXR1cm4gIiArICJUcnVlIiwKICAgICAgICAgICAiTm90SW1w'
    'bGVtZW50ZWQiICsgIkVycm9yIiwKICAgICAgICAgICAicmFpc2UgTm90SW1wbGVtZW50ZWQiICsgIkVycm9yIiwKICAgICAgICAg'
    'ICAicGFzcyAgIyAiICsgIlRPRE8iKQoKCmRlZiBfcnVuKGNtZDogTGlzdFtzdHJdLCBjd2Q6IFBhdGgsIHRpbWVvdXQ6IGludCA9'
    'IDEyMCkgLT4gdHVwbGU6CiAgICB0cnk6CiAgICAgICAgYWxsb3dlZCA9IHsiUEFUSCIsICJIT01FIiwgIkxBTkciLCAiTENfQUxM'
    'IiwgIlRNUERJUiIsICJTWVNURU1ST09UIiwgIldJTkRJUiJ9CiAgICAgICAgZW52ID0ge2s6IHYgZm9yIGssIHYgaW4gb3MuZW52'
    'aXJvbi5pdGVtcygpIGlmIGsgaW4gYWxsb3dlZH0KICAgICAgICBlbnYuc2V0ZGVmYXVsdCgiSE9NRSIsIHN0cihjd2QpKQogICAg'
    'ICAgIGVudi5zZXRkZWZhdWx0KCJMQU5HIiwgIkMuVVRGLTgiKQogICAgICAgIHAgPSBzdWJwcm9jZXNzLnJ1bihjbWQsIGN3ZD1z'
    'dHIoY3dkKSwgZW52PWVudiwgY2FwdHVyZV9vdXRwdXQ9VHJ1ZSwKICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dD1UcnVl'
    'LCB0aW1lb3V0PXRpbWVvdXQpCiAgICAgICAgcmV0dXJuIHAucmV0dXJuY29kZSwgKHAuc3Rkb3V0IG9yICIiKSArIChwLnN0ZGVy'
    'ciBvciAiIikKICAgIGV4Y2VwdCBGaWxlTm90Rm91bmRFcnJvcjoKICAgICAgICByZXR1cm4gMTI3LCAibm90IGZvdW5kOiAiICsg'
    'IiAiLmpvaW4oY21kKQogICAgZXhjZXB0IHN1YnByb2Nlc3MuVGltZW91dEV4cGlyZWQ6CiAgICAgICAgcmV0dXJuIDEyNCwgInRp'
    'bWVvdXQiCiAgICBleGNlcHQgRXhjZXB0aW9uIGFzIGV4YzoKICAgICAgICByZXR1cm4gMSwgcmVwcihleGMpCgoKZGVmIF9zY2Fu'
    'X2hvbGxvdyhyb290OiBQYXRoKSAtPiBMaXN0W3N0cl06CiAgICBoaXRzID0gW10KICAgIGZvciBwIGluIHJvb3Qucmdsb2IoIioi'
    'KToKICAgICAgICBpZiBwLmlzX2ZpbGUoKSBhbmQgcC5zdWZmaXggaW4gKCIucHkiLCAiLmpzIiwgIi50cyIsICIuamF2YSIpOgog'
    'ICAgICAgICAgICB0cnk6CiAgICAgICAgICAgICAgICB0ZXh0ID0gcC5yZWFkX3RleHQoZXJyb3JzPSJpZ25vcmUiKQogICAgICAg'
    'ICAgICBleGNlcHQgRXhjZXB0aW9uOgogICAgICAgICAgICAgICAgY29udGludWUKICAgICAgICAgICAgZm9yIHBhdCBpbiBfSE9M'
    'TE9XOgogICAgICAgICAgICAgICAgaWYgcGF0IGluIHRleHQ6CiAgICAgICAgICAgICAgICAgICAgaGl0cy5hcHBlbmQoc3RyKHAu'
    'cmVsYXRpdmVfdG8ocm9vdCkpICsgIjogIiArIHBhdCkKICAgIHJldHVybiBoaXRzCgoKZGVmIHNjb3JlX2NhbmRpZGF0ZShjOiBD'
    'YW5kaWRhdGUsIHNjYWZmb2xkOiBTY2FmZm9sZCkgLT4gZmxvYXQ6CiAgICBzY29yZSA9IDAuMAogICAgcmMsIGxvZyA9IF9ydW4o'
    'c2NhZmZvbGQuYnVpbGRfY21kLCBjLnBhdGgpCiAgICBjLmJ1aWxkX2xvZyA9IGxvZwogICAgaWYgcmMgPT0gMDoKICAgICAgICBz'
    'Y29yZSArPSAyLjAKICAgIHJjX3QsIGxvZ190ID0gX3J1bihzY2FmZm9sZC50ZXN0X2NtZCwgYy5wYXRoKQogICAgaWYgcmNfdCA9'
    'PSAwOgogICAgICAgIHNjb3JlICs9IDMuMAogICAgaG9sbG93ID0gX3NjYW5faG9sbG93KGMucGF0aCkKICAgIGlmIG5vdCBob2xs'
    'b3c6CiAgICAgICAgc2NvcmUgKz0gMi4wCiAgICBzY29yZSArPSAwLjEgKiBsZW4oYy5maWxlcykKICAgIGMuc2NvcmUgPSBzY29y'
    'ZQogICAgcmV0dXJuIHNjb3JlCgoKZGVmIHJhbmsoY2FuZGlkYXRlczogTGlzdFtDYW5kaWRhdGVdLCBzcGVjOiBkaWN0LCBzY2Fm'
    'Zm9sZDogU2NhZmZvbGQsCiAgICAgICAgIGNsaWVudDogT3B0aW9uYWxbTExNQ2xpZW50XSA9IE5vbmUpIC0+IExpc3RbQ2FuZGlk'
    'YXRlXToKICAgIGZvciBjIGluIGNhbmRpZGF0ZXM6CiAgICAgICAgc2NvcmVfY2FuZGlkYXRlKGMsIHNjYWZmb2xkKQogICAgY2Fu'
    'ZGlkYXRlcy5zb3J0KGtleT1sYW1iZGEgYzogLWMuc2NvcmUpCiAgICAjIE9wdGlvbmFsIGFkdmVyc2FyaWFsIHRpZS1icmVhayBi'
    'ZXR3ZWVuIHRoZSB0b3AgdHdvIGJ5IGEgcHJlbWl1bSBtb2RlbC4KICAgIGlmIGNsaWVudCBhbmQgbGVuKGNhbmRpZGF0ZXMpID49'
    'IDIgYW5kIGFicyhjYW5kaWRhdGVzWzBdLnNjb3JlIC0gY2FuZGlkYXRlc1sxXS5zY29yZSkgPCAwLjAxOgogICAgICAgIHRyeToK'
    'ICAgICAgICAgICAgdmVyZGljdCA9IGNsaWVudC5jaGF0KAogICAgICAgICAgICAgICAgW3sicm9sZSI6ICJzeXN0ZW0iLCAiY29u'
    'dGVudCI6CiAgICAgICAgICAgICAgICAgICJZb3UgYXJlIGFuIGFkdmVyc2FyaWFsIHZlcmlmaWVyLiBSZXBseSB3aXRoIHRoZSBu'
    'dW1iZXIgMCBvciAxIG9ubHkuIn0sCiAgICAgICAgICAgICAgICAgeyJyb2xlIjogInVzZXIiLCAiY29udGVudCI6CiAgICAgICAg'
    'ICAgICAgICAgICJXaGljaCBjYW5kaWRhdGUgaXMgbW9yZSBsaWtlbHkgY29ycmVjdD9cbjA6ICIgKyBjYW5kaWRhdGVzWzBdLmRp'
    'ZmYgKwogICAgICAgICAgICAgICAgICAiXG4xOiAiICsgY2FuZGlkYXRlc1sxXS5kaWZmfV0sCiAgICAgICAgICAgICAgICBjbHM9'
    'InByZW1pdW0iLCB0ZW1wZXJhdHVyZT0wLjAsIG1heF90b2tlbnM9NCkKICAgICAgICAgICAgaWYgIjEiIGluIHZlcmRpY3QgYW5k'
    'ICIwIiBub3QgaW4gdmVyZGljdDoKICAgICAgICAgICAgICAgIGNhbmRpZGF0ZXNbMF0sIGNhbmRpZGF0ZXNbMV0gPSBjYW5kaWRh'
    'dGVzWzFdLCBjYW5kaWRhdGVzWzBdCiAgICAgICAgZXhjZXB0IEV4Y2VwdGlvbjoKICAgICAgICAgICAgcGFzcwogICAgcmV0dXJu'
    'IGNhbmRpZGF0ZXMKI0BARklMRTpzYXZhZ2UvcHJlbWl1bS93b3JrdHJlZS5weUBACiIiIkwxMCAtIFdvcmt0cmVlIGlzb2xhdGlv'
    'bi4KCkV2ZXJ5IGNhbmRpZGF0ZSBpcyBnZW5lcmF0ZWQgaW4gaXRzIG93biBwcml2YXRlLCBkaXNwb3NhYmxlIHdvcmtzcGFjZSBz'
    'bwpjYW5kaWRhdGVzIGNhbiBuZXZlciBjb250YW1pbmF0ZSBlYWNoIG90aGVyICh0aGUgaGFyIC8gYWdlbnRyZWUgLyBhZ2VudC13'
    'b3JrdHJlZQpwYXR0ZXJuKS4gIFdoZW4gdGhlIGZhY3RvcnkgbGl2ZXMgaW5zaWRlIGEgZ2l0IHJlcG9zaXRvcnkgd2l0aCBhdCBs'
    'ZWFzdCBvbmUKY29tbWl0IHdlIHVzZSBhIHJlYWwgYGBnaXQgd29ya3RyZWVgYDsgb3RoZXJ3aXNlIHdlIGZhbGwgYmFjayB0byBh'
    'biBpc29sYXRlZApkaXJlY3RvcnkgdW5kZXIgYGA8cm9vdD4vLndvcmt0cmVlcy9gYC4gIEVpdGhlciB3YXkgdGhlIGNvbnRyYWN0'
    'IGlzIGlkZW50aWNhbDoKYSBwcml2YXRlIGRpcmVjdG9yeSBwZXIgY2FuZGlkYXRlLCByZWxlYXNlZCB3aGVuIHRoZSBidWlsZCBp'
    'cyBkb25lLgoiIiIKZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IHNodXRpbAppbXBvcnQgc3VicHJv'
    'Y2Vzcwpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKZnJvbSB0eXBpbmcgaW1wb3J0IERpY3QKCgpkZWYgZ2l0X2F2YWlsYWJsZSgp'
    'IC0+IGJvb2w6CiAgICByZXR1cm4gc2h1dGlsLndoaWNoKCJnaXQiKSBpcyBub3QgTm9uZQoKCmRlZiBfaXNfZ2l0X3JlcG8ocGF0'
    'aDogUGF0aCkgLT4gYm9vbDoKICAgIHRyeToKICAgICAgICBwID0gc3VicHJvY2Vzcy5ydW4oWyJnaXQiLCAiLUMiLCBzdHIocGF0'
    'aCksICJyZXYtcGFyc2UiLCAiLS1pcy1pbnNpZGUtd29yay10cmVlIl0sCiAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhcHR1'
    'cmVfb3V0cHV0PVRydWUsIHRleHQ9VHJ1ZSwgdGltZW91dD0xMCkKICAgICAgICBpZiBwLnJldHVybmNvZGUgIT0gMDoKICAgICAg'
    'ICAgICAgcmV0dXJuIEZhbHNlCiAgICAgICAgaGVhZCA9IHN1YnByb2Nlc3MucnVuKFsiZ2l0IiwgIi1DIiwgc3RyKHBhdGgpLCAi'
    'cmV2LXBhcnNlIiwgIi0tdmVyaWZ5IiwgIkhFQUQiXSwKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FwdHVyZV9vdXRw'
    'dXQ9VHJ1ZSwgdGV4dD1UcnVlLCB0aW1lb3V0PTEwKQogICAgICAgIHJldHVybiBoZWFkLnJldHVybmNvZGUgPT0gMAogICAgZXhj'
    'ZXB0IEV4Y2VwdGlvbjoKICAgICAgICByZXR1cm4gRmFsc2UKCgpkZWYgaXNvbGF0ZShiYXNlX3JlcG86IFBhdGgsIG5hbWU6IHN0'
    'ciwgcm9vdDogUGF0aCkgLT4gRGljdFtzdHIsIG9iamVjdF06CiAgICAiIiJDcmVhdGUgYSBwcml2YXRlIHdvcmtzcGFjZSBmb3Ig'
    'b25lIGNhbmRpZGF0ZS4KCiAgICBSZXR1cm5zIGBgeyJwYXRoIjogUGF0aCwgIm1vZGUiOiAid29ya3RyZWUifCJkaXIifWBgLiAg'
    'TmV2ZXIgcmFpc2VzOiBvbiBhbnkKICAgIGZhaWx1cmUgaXQgZGVncmFkZXMgdG8gYSBwbGFpbiBpc29sYXRlZCBkaXJlY3Rvcnku'
    'CiAgICAiIiIKICAgIGJhc2VfcmVwbyA9IFBhdGgoYmFzZV9yZXBvKQogICAgcm9vdCA9IFBhdGgocm9vdCkKICAgIGRlc3QgPSBy'
    'b290IC8gIi53b3JrdHJlZXMiIC8gbmFtZQogICAgZGVzdC5wYXJlbnQubWtkaXIocGFyZW50cz1UcnVlLCBleGlzdF9vaz1UcnVl'
    'KQogICAgaWYgZGVzdC5leGlzdHMoKToKICAgICAgICByZWxlYXNlKGRlc3QpCiAgICBpZiBnaXRfYXZhaWxhYmxlKCkgYW5kIF9p'
    'c19naXRfcmVwbyhiYXNlX3JlcG8pOgogICAgICAgIHRyeToKICAgICAgICAgICAgcCA9IHN1YnByb2Nlc3MucnVuKAogICAgICAg'
    'ICAgICAgICAgWyJnaXQiLCAiLUMiLCBzdHIoYmFzZV9yZXBvKSwgIndvcmt0cmVlIiwgImFkZCIsICItLWRldGFjaCIsIHN0cihk'
    'ZXN0KV0sCiAgICAgICAgICAgICAgICBjYXB0dXJlX291dHB1dD1UcnVlLCB0ZXh0PVRydWUsIHRpbWVvdXQ9NjApCiAgICAgICAg'
    'ICAgIGlmIHAucmV0dXJuY29kZSA9PSAwOgogICAgICAgICAgICAgICAgcmV0dXJuIHsicGF0aCI6IGRlc3QsICJtb2RlIjogIndv'
    'cmt0cmVlIn0KICAgICAgICBleGNlcHQgRXhjZXB0aW9uOgogICAgICAgICAgICBwYXNzCiAgICBkZXN0Lm1rZGlyKHBhcmVudHM9'
    'VHJ1ZSwgZXhpc3Rfb2s9VHJ1ZSkKICAgIHJldHVybiB7InBhdGgiOiBkZXN0LCAibW9kZSI6ICJkaXIifQoKCmRlZiByZWxlYXNl'
    'KHBhdGg6IFBhdGgpIC0+IE5vbmU6CiAgICAiIiJUZWFyIGRvd24gYSB3b3Jrc3BhY2UgY3JlYXRlZCBieSA6ZnVuYzpgaXNvbGF0'
    'ZWAuIiIiCiAgICBwYXRoID0gUGF0aChwYXRoKQogICAgaWYgbm90IHBhdGguZXhpc3RzKCk6CiAgICAgICAgcmV0dXJuCiAgICAj'
    'IEEgbGlua2VkIHdvcmt0cmVlIGhhcyBhIC5naXQgKmZpbGUqIChub3QgYSBkaXJlY3RvcnkpIHBvaW50aW5nIGF0IHRoZSBwYXJl'
    'bnQuCiAgICBpZiAocGF0aCAvICIuZ2l0IikuaXNfZmlsZSgpOgogICAgICAgIHRyeToKICAgICAgICAgICAgcmVzdWx0ID0gc3Vi'
    'cHJvY2Vzcy5ydW4oWyJnaXQiLCAiLUMiLCBzdHIocGF0aCksICJ3b3JrdHJlZSIsICJyZW1vdmUiLCAiLS1mb3JjZSIsIHN0cihw'
    'YXRoKV0sCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhcHR1cmVfb3V0cHV0PVRydWUsIHRleHQ9VHJ1ZSwg'
    'dGltZW91dD02MCkKICAgICAgICAgICAgaWYgcmVzdWx0LnJldHVybmNvZGUgPT0gMCBhbmQgbm90IHBhdGguZXhpc3RzKCk6CiAg'
    'ICAgICAgICAgICAgICByZXR1cm4KICAgICAgICBleGNlcHQgRXhjZXB0aW9uOgogICAgICAgICAgICBwYXNzCiAgICBpZiBwYXRo'
    'LmV4aXN0cygpOgogICAgICAgIHNodXRpbC5ybXRyZWUocGF0aCwgaWdub3JlX2Vycm9ycz1GYWxzZSkKI0BARklMRTpzYXZhZ2Uv'
    'cmVnaXN0cnkvX19pbml0X18ucHlAQAoiIiJUaGUgdG9vbCByZWdpc3RyeSArIHRpZXIgZW5mb3JjZW1lbnQuIiIiCmZyb20gLnJl'
    'Z2lzdHJ5IGltcG9ydCBSZWdpc3RyeSwgbG9hZCwgZW5mb3JjZV9nYXRlX3RpZXIKCl9fYWxsX18gPSBbIlJlZ2lzdHJ5IiwgImxv'
    'YWQiLCAiZW5mb3JjZV9nYXRlX3RpZXIiXQojQEBGSUxFOnNhdmFnZS9yZWdpc3RyeS9yZWdpc3RyeS5weUBACiIiIkxvYWQgdGhl'
    'IHRvb2wgcmVnaXN0cnkgYW5kIGVuZm9yY2UgdHJ1c3QgdGllcnMuCgpSdWxlOiBvbmx5IFZFUklGSUVEIHRvb2xzIG1heSBnYXRl'
    'IGEgcmVsZWFzZS4gIEV2ZXJ5dGhpbmcgZWxzZSBtYXkgYXNzaXN0LCBidXQKbWF5IG5ldmVyIGJlIHRoZSB0aGluZyB0aGF0IHNh'
    'eXMgInNoaXAiLgoiIiIKZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGpzb24KZnJvbSBwYXRobGli'
    'IGltcG9ydCBQYXRoCmZyb20gdHlwaW5nIGltcG9ydCBEaWN0LCBMaXN0LCBPcHRpb25hbAoKZnJvbSAuLmNvbmZpZyBpbXBvcnQg'
    'RkFDVE9SWV9ESVIKCkdBVEVfVElFUlMgPSAoInZlcmlmaWVkIiwpCgoKY2xhc3MgUmVnaXN0cnk6CiAgICBkZWYgX19pbml0X18o'
    'c2VsZiwgdG9vbHM6IExpc3RbZGljdF0pIC0+IE5vbmU6CiAgICAgICAgc2VsZi50b29scyA9IHRvb2xzCiAgICAgICAgc2VsZi5i'
    'eV9pZDogRGljdFtzdHIsIGRpY3RdID0ge3RbImlkIl06IHQgZm9yIHQgaW4gdG9vbHN9CgogICAgZGVmIGdldChzZWxmLCB0b29s'
    'X2lkOiBzdHIpIC0+IE9wdGlvbmFsW2RpY3RdOgogICAgICAgIHJldHVybiBzZWxmLmJ5X2lkLmdldCh0b29sX2lkKQoKICAgIGRl'
    'ZiBieV9ncm91cChzZWxmLCBncm91cDogc3RyKSAtPiBMaXN0W2RpY3RdOgogICAgICAgIHJldHVybiBbdCBmb3IgdCBpbiBzZWxm'
    'LnRvb2xzIGlmIHQuZ2V0KCJncm91cCIpID09IGdyb3VwXQoKICAgIGRlZiBieV90aWVyKHNlbGYsIHRpZXI6IHN0cikgLT4gTGlz'
    'dFtkaWN0XToKICAgICAgICByZXR1cm4gW3QgZm9yIHQgaW4gc2VsZi50b29scyBpZiB0LmdldCgidGllciIpID09IHRpZXJdCgog'
    'ICAgZGVmIHN1bW1hcnkoc2VsZikgLT4gZGljdDoKICAgICAgICBvdXQ6IERpY3Rbc3RyLCBpbnRdID0ge30KICAgICAgICBncm91'
    'cHM6IERpY3Rbc3RyLCBpbnRdID0ge30KICAgICAgICBmb3IgdCBpbiBzZWxmLnRvb2xzOgogICAgICAgICAgICBvdXRbdFsidGll'
    'ciJdXSA9IG91dC5nZXQodFsidGllciJdLCAwKSArIDEKICAgICAgICAgICAgZ3JvdXBzW3RbImdyb3VwIl1dID0gZ3JvdXBzLmdl'
    'dCh0WyJncm91cCJdLCAwKSArIDEKICAgICAgICByZXR1cm4geyJ0b3RhbCI6IGxlbihzZWxmLnRvb2xzKSwgImJ5X3RpZXIiOiBv'
    'dXQsICJieV9ncm91cCI6IGdyb3Vwc30KCgpkZWYgbG9hZChwYXRoOiBPcHRpb25hbFtQYXRoXSA9IE5vbmUpIC0+IFJlZ2lzdHJ5'
    'OgogICAgcGF0aCA9IHBhdGggb3IgKEZBQ1RPUllfRElSIC8gInJlZ2lzdHJ5IiAvICJ0b29scy5qc29uIikKICAgIGlmIG5vdCBQ'
    'YXRoKHBhdGgpLmV4aXN0cygpOgogICAgICAgIHJldHVybiBSZWdpc3RyeShbXSkKICAgIGRhdGEgPSBqc29uLmxvYWRzKFBhdGgo'
    'cGF0aCkucmVhZF90ZXh0KCkpCiAgICByZXR1cm4gUmVnaXN0cnkoZGF0YS5nZXQoInRvb2xzIiwgZGF0YSBpZiBpc2luc3RhbmNl'
    'KGRhdGEsIGxpc3QpIGVsc2UgW10pKQoKCmRlZiBlbmZvcmNlX2dhdGVfdGllcih0b29sOiBkaWN0KSAtPiBib29sOgogICAgIiIi'
    'UmV0dXJuIFRydWUgb25seSBpZiB0aGUgdG9vbCBpcyBhbGxvd2VkIHRvIGdhdGUgYSByZWxlYXNlLiIiIgogICAgcmV0dXJuIHRv'
    'b2wuZ2V0KCJ0aWVyIikgaW4gR0FURV9USUVSUwojQEBGSUxFOnNhdmFnZS91bmRlcmNvdmVyL19faW5pdF9fLnB5QEAKIiIiVGhl'
    'IGFkb3B0ZWQtcmVwbyBjYXRhbG9nLCBhdXRvLXJlZ2lzdGVyZWQgb24gaW1wb3J0LiIiIgpmcm9tIF9fZnV0dXJlX18gaW1wb3J0'
    'IGFubm90YXRpb25zCgppbXBvcnQganNvbgpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKCmZyb20gLi5jb25maWcgaW1wb3J0IFNB'
    'VkFHRV9ESVIKCl9DQVRBTE9HID0gU0FWQUdFX0RJUiAvICJ1bmRlcmNvdmVyIiAvICJjYXRhbG9nLmpzb24iCl9SRUdJU1RFUkVE'
    'ID0gRmFsc2UKCgpkZWYgZW5zdXJlX3JlZ2lzdGVyZWQoZm9yY2U6IGJvb2wgPSBGYWxzZSkgLT4gZGljdDoKICAgIGdsb2JhbCBf'
    'UkVHSVNURVJFRAogICAgaWYgX1JFR0lTVEVSRUQgYW5kIG5vdCBmb3JjZToKICAgICAgICByZXR1cm4geyJyZWdpc3RlcmVkIjog'
    'VHJ1ZSwgImNhY2hlZCI6IFRydWV9CiAgICBpZiBfQ0FUQUxPRy5leGlzdHMoKToKICAgICAgICBfUkVHSVNURVJFRCA9IFRydWUK'
    'ICAgICAgICByZXR1cm4geyJyZWdpc3RlcmVkIjogVHJ1ZSwgInBhdGgiOiBzdHIoX0NBVEFMT0cpfQogICAgcmV0dXJuIHsicmVn'
    'aXN0ZXJlZCI6IEZhbHNlfQoKCmRlZiBsb2FkKCkgLT4gbGlzdDoKICAgIGlmIF9DQVRBTE9HLmV4aXN0cygpOgogICAgICAgIHJl'
    'dHVybiBqc29uLmxvYWRzKF9DQVRBTE9HLnJlYWRfdGV4dCgpKS5nZXQoInJlcG9zIiwgW10pCiAgICByZXR1cm4gW10K'
)
import base64 as _b64
_BUNDLE: str = _b64.b64decode(_BUNDLE_B64).decode("utf-8")
# ==============================================================================
# 10. RUNTIME — parse the bundle, generate derived artifacts, and run the CLI
# ==============================================================================

_BUNDLE_MARKER = re.compile(r"^#@@FILE:(.+?)@@[ \t]*$", re.MULTILINE)


def parse_bundle() -> Dict[str, str]:
    """Split the embedded bundle into {relative_path: content}."""
    files: Dict[str, str] = {}
    matches = list(_BUNDLE_MARKER.finditer(_BUNDLE))
    for i, m in enumerate(matches):
        path = m.group(1).strip()
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(_BUNDLE)
        content = _BUNDLE[start:end]
        # strip exactly one leading newline introduced by the delimiter line
        if content.startswith("\n"):
            content = content[1:]
        files[path] = content
    return files


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()[:12]


def write_tree(root: Path, files: Dict[str, str], force: bool = False) -> Dict[str, int]:
    """Write only missing files unless --force is explicit; report conflicts."""
    written = unchanged = conflicts = 0
    conflict_paths = []
    root = Path(root).resolve()
    for rel, content in files.items():
        p = (root / rel).resolve()
        if not p.is_relative_to(root):
            conflicts += 1; conflict_paths.append(rel + " (outside root)"); continue
        if p.exists() and not force:
            try:
                if p.read_text(encoding="utf-8") == content:
                    unchanged += 1
                else:
                    conflicts += 1; conflict_paths.append(rel)
                continue
            except Exception:
                conflicts += 1; conflict_paths.append(rel); continue
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        if rel.endswith(".sh"):
            try:
                p.chmod(p.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
            except Exception:
                pass
        written += 1
    return {"written": written, "unchanged": unchanged, "conflicts": conflicts,
            "conflict_paths": conflict_paths, "total": len(files)}


# --- generators ----------------------------------------------------------------

def registry_dict() -> dict:
    tools = []
    for (tid, name, group, tier, kind, requires, purpose, net) in TOOL_CATALOG:
        tools.append({
            "id": tid, "name": name, "group": group,
            "group_name": GROUPS.get(group, group), "tier": tier, "kind": kind,
            "requires": [r for r in requires.split(",") if r],
            "purpose": purpose, "network": net, "may_gate": tier in GATE_TIERS,
        })
    return {
        "schema_version": 1, "generated_by": GENESIS_CODENAME,
        "version": GENESIS_VERSION, "count": len(tools), "tools": tools,
    }


def repos_dict() -> dict:
    repos = []
    for (rid, url, group, tier, purpose) in REPO_CATALOG:
        repos.append({"id": rid, "url": url, "group": group, "tier": tier,
                      "purpose": purpose, "excluded": group == "excluded"})
    return {"count": len(repos), "repos": repos}


def mcp_dict() -> dict:
    servers = []
    for (sid, name, tier, exposes, purpose) in MCP_FLEET:
        servers.append({"id": sid, "name": name, "tier": tier,
                        "exposes": [e for e in exposes.split(",") if e],
                        "purpose": purpose, "transport": "stdio",
                        "command": ["python3", "savage/mcp/servers/%s.py" % sid],
                        "may_gate": tier in GATE_TIERS})
    return {"transport": "stdio", "protocol": "2024-11-05",
            "count": len(servers), "servers": servers}


_RPC_HARNESS = '''"""Shared stdio JSON-RPC 2.0 harness for every generated MCP server.

Each generated server is a real, callable MCP endpoint (no network, no deps):

    <id>.health  -> liveness + tier + per-capability host availability
    <id>.list    -> the tools this server exposes
    <id>.call    -> dispatch a named capability (availability-checked here)

Availability is probed with shutil.which on the capability's leading token, so a
call answers honestly about *this* host instead of pretending.
"""
from __future__ import annotations

import json
import shutil
import sys

PROTOCOL = "2024-11-05"


def _send(obj: dict) -> None:
    sys.stdout.write(json.dumps(obj) + "\\n")
    sys.stdout.flush()


def _descriptors(server_id: str, exposes) -> list:
    tools = [
        {"name": server_id + ".health", "description": "Liveness + tier.",
         "inputSchema": {"type": "object", "properties": {}}},
        {"name": server_id + ".list", "description": "List exposed tools.",
         "inputSchema": {"type": "object", "properties": {}}},
    ]
    for e in exposes:
        tools.append({"name": e, "description": "Exposed capability.",
                      "inputSchema": {"type": "object", "properties": {}}})
    return tools


def _dispatch(server_id, server_name, tier, exposes, name, args) -> dict:
    if name == server_id + ".health":
        return {"server": server_id, "name": server_name, "tier": tier, "ok": True,
                "host_tools": {e: bool(shutil.which(e.split(".")[0])) for e in exposes}}
    if name == server_id + ".list":
        return {"server": server_id, "exposes": list(exposes)}
    if name in exposes:
        binary = name.split(".")[0]
        return {"tool": name, "tier": tier, "available": bool(shutil.which(binary)),
                "note": "availability checked on this host"}
    return {"error": "unknown tool: " + str(name)}


def serve(server_id: str, server_name: str, tier: str, exposes) -> int:
    tools = _descriptors(server_id, exposes)
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except Exception:
            continue
        method = msg.get("method", "")
        params = msg.get("params", {}) or {}
        mid = msg.get("id")
        if method == "initialize":
            _send({"jsonrpc": "2.0", "id": mid, "result": {
                "protocolVersion": PROTOCOL, "capabilities": {"tools": {}},
                "serverInfo": {"name": server_id, "version": "1.0.0"}}})
        elif method == "tools/list":
            _send({"jsonrpc": "2.0", "id": mid, "result": {"tools": tools}})
        elif method == "tools/call":
            res = _dispatch(server_id, server_name, tier, exposes,
                            params.get("name"), params.get("arguments", {}) or {})
            _send({"jsonrpc": "2.0", "id": mid, "result": {
                "content": [{"type": "text", "text": json.dumps(res)}]}})
        else:
            _send({"jsonrpc": "2.0", "id": mid,
                   "error": {"code": -32601, "message": "method not found"}})
    return 0
'''


def mcp_server_files() -> Dict[str, str]:
    """Generate a real stdio MCP server for every entry in the fleet."""
    out: Dict[str, str] = {}
    out["savage/mcp/servers/__init__.py"] = (
        '"""Generated MCP servers (one real stdio endpoint per fleet entry)."""\n')
    out["savage/mcp/servers/_rpc.py"] = _RPC_HARNESS
    for (sid, name, tier, exposes, _purpose) in MCP_FLEET:
        if sid == "gate":
            continue  # the hand-written reference server already exists
        items = [e for e in exposes.split(",") if e]
        launcher = (
            '"""MCP server: %s (%s). Generated; do not edit by hand."""\n'
            "import sys\n"
            "from pathlib import Path\n\n"
            "_ROOT = Path(__file__).resolve().parents[3]\n"
            "if str(_ROOT) not in sys.path:\n"
            "    sys.path.insert(0, str(_ROOT))\n\n"
            "from savage.mcp.servers._rpc import serve\n\n"
            'SERVER_ID = "%s"\n'
            'SERVER_NAME = "%s"\n'
            'TIER = "%s"\n'
            "EXPOSES = %s\n\n\n"
            'if __name__ == "__main__":\n'
            "    raise SystemExit(serve(SERVER_ID, SERVER_NAME, TIER, EXPOSES))\n"
            % (name, tier, sid, name, tier, json.dumps(items))
        )
        out["savage/mcp/servers/%s.py" % sid] = launcher
    return out


def _yaml(obj: Any, indent: int = 0) -> str:
    pad = "  " * indent
    if isinstance(obj, dict):
        lines = []
        for k, v in obj.items():
            if isinstance(v, (dict, list)):
                lines.append("%s%s:" % (pad, k))
                lines.append(_yaml(v, indent + 1))
            else:
                lines.append("%s%s: %s" % (pad, k, json.dumps(v)))
        return "\n".join(lines)
    if isinstance(obj, list):
        lines = []
        for v in obj:
            if isinstance(v, (dict, list)):
                lines.append("%s-" % pad)
                lines.append(_yaml(v, indent + 1))
            else:
                lines.append("%s- %s" % (pad, json.dumps(v)))
        return "\n".join(lines)
    return "%s%s" % (pad, json.dumps(obj))


def rules_files() -> Dict[str, str]:
    out = {}
    for stage, rules in RULES.items():
        out["factory/rules/%s.yaml" % stage] = "# Auto-generated rule set for stage: %s\n%s\n" % (
            stage, _yaml(rules))
    return out


def tools_markdown() -> str:
    lines = ["# SAVAGE TOOL REGISTRY", "",
             "Total: **%d** tools across %d groups." % (len(TOOL_CATALOG), len(GROUPS)), "",
             "| Tier | Count |", "|---|---|"]
    counts: Dict[str, int] = {}
    for t in TOOL_CATALOG:
        counts[t[3]] = counts.get(t[3], 0) + 1
    for tier in TIERS:
        lines.append("| %s %s | %d |" % (TIER_ICON[tier], tier, counts.get(tier, 0)))
    lines.append("")
    for g in sorted(GROUPS):
        lines.append("## Group %s — %s" % (g, GROUPS[g]))
        lines.append("")
        lines.append("| id | name | tier | kind | purpose |")
        lines.append("|---|---|---|---|---|")
        for (tid, name, group, tier, kind, req, purpose, net) in TOOL_CATALOG:
            if group == g:
                lines.append("| `%s` | %s | %s %s | %s | %s |" % (
                    tid, name, TIER_ICON[tier], tier, kind, purpose))
        lines.append("")
    return "\n".join(lines)


def docs_main() -> str:
    return textwrap.dedent("""\
    # SAVAGE FACTORY

    Generated by **{codename} {version}**.

    A multi-stage software factory: **intake -> spec -> build -> verify ->
    package -> ship -> improve**, with 4 trust tiers and a 10-layer premium
    harness that lets a low-end model produce verified, premium-shaped output.

    ## Quick start

    ```bash
    python3 {self} init
    python3 {self} doctor
    python3 {self} build "car racing game"
    ```

    ## Trust tiers

    Only **VERIFIED** tools may gate a release. Everything else may assist.

    ## The 10 layers

    L1 spec amplifier, L2 scaffold selector, L3 best-of-N sampler, L4
    verifier/ensemble, L5 self-repair loop, L6 constrained decoding, L7 golden
    retrieval, L8 deterministic gates, L9 sealed holdout, L10 worktree isolation.

    ## The 5 spaces

    `factory/manager` (routing + queue), `factory/spaces/apk-cli` (isolated APK
    cell, the only release emitter), `factory/cleaner` (dry-run-first
    maintenance), `factory/improver` (24/7 self-improvement), `factory/adopt`
    (keep/delete planner).

    ## The bus

    A {mcp}-server MCP fleet over stdio JSON-RPC 2.0, with a gateway that kills
    the -32000 EOF error and falls back to GitHub Models free inference.
    """).format(codename=GENESIS_CODENAME, version=GENESIS_VERSION,
                self=SELF_NAME, mcp=len(MCP_FLEET))


def workflow_files() -> Dict[str, str]:
    gate = textwrap.dedent("""\
    name: savage-factory-gate
    on:
      push:
        branches: [main]
      pull_request:
    jobs:
      gate:
        runs-on: ubuntu-latest
        steps:
          - uses: actions/checkout@v4
          - uses: actions/setup-python@v5
            with:
              python-version: "3.11"
          - name: Install factory
            run: python3 __SELF__ init
          - name: Doctor
            run: python3 __SELF__ doctor
          - name: Deterministic gates
            run: python3 __SELF__ gate
    """)
    apk = textwrap.dedent("""\
    name: apk-cli
    on:
      workflow_dispatch:
    jobs:
      apk:
        runs-on: ubuntu-latest
        steps:
          - uses: actions/checkout@v4
          - uses: actions/setup-java@v4
            with:
              distribution: temurin
              java-version: "17"
          - name: Build in isolated cell
            run: bash factory/spaces/apk-cli/build.sh
          - name: Release gate
            run: bash factory/spaces/apk-cli/gate.sh
    """)
    cleaner = textwrap.dedent("""\
    name: cleaner
    on:
      schedule:
        - cron: "0 3 * * 0"
      workflow_dispatch:
    jobs:
      clean:
        runs-on: ubuntu-latest
        steps:
          - uses: actions/checkout@v4
          - name: Plan (dry run)
            run: python3 __SELF__ clean
    """)
    improver = textwrap.dedent("""\
    name: improver
    on:
      schedule:
        - cron: "0 */6 * * *"
      workflow_dispatch:
    jobs:
      improve:
        runs-on: ubuntu-latest
        steps:
          - uses: actions/checkout@v4
          - name: One improvement cycle
            run: python3 __SELF__ improve
    """)
    return {
        ".github/workflows/savage-factory-gate.yml": gate,
        ".github/workflows/apk-cli.yml": apk,
        ".github/workflows/cleaner.yml": cleaner,
        ".github/workflows/improver.yml": improver,
    }


def cli_wrapper() -> str:
    return textwrap.dedent("""\
    #!/usr/bin/env python3
    \"\"\"Thin CLI wrapper so the factory can be invoked as `python -m tools.savage_factory`.\"\"\"
    import runpy
    import sys
    from pathlib import Path

    GENESIS = Path(__file__).resolve().parent.parent / "__SELF__"
    if GENESIS.exists():
        sys.argv = [str(GENESIS)] + sys.argv[1:]
        runpy.run_path(str(GENESIS), run_name="__main__")
    else:
        print("__SELF__ not found", file=sys.stderr)
        raise SystemExit(2)
    """)


# --- commands ------------------------------------------------------------------

def readme_file() -> str:
    return textwrap.dedent("""\
    # SAVAGE FACTORY

    Generated by **__CODENAME__ __VERSION__** — a self-contained, multi-stage
    software factory. One file (`__SELF__`) materialises all of this.

    > **Model reading this? Run `python3 __SELF__ all` first.** If it prints
    > `VERDICT: ALL GREEN`, the factory is real and working. Nothing else is
    > required to install it.

    ## What this is

    7 stages (intake -> spec -> build -> verify -> package -> ship -> improve),
    4 trust tiers, a **10-layer** premium harness, **5 spaces**, and a
    **__MCP__-server** MCP bus. Only **VERIFIED** tools may gate a release.

    ## Quick start

    ```bash
    python3 __SELF__ all            # init + doctor + catalog (start here)
    python3 __SELF__ build "car racing game"
    python3 __SELF__ adopt          # dry-run: what would be kept / deleted
    ```

    ## What it does to your existing repo (keep vs delete)

    `init` is **additive**: it only writes new files and never deletes or
    overwrites your work unless you pass `--force`. Deletion is a separate,
    explicit, dry-run-first command:

    ```bash
    python3 __SELF__ adopt          # writes ADOPT.md, changes nothing
    python3 __SELF__ adopt --apply  # deletes ONLY the DELETE bucket
    ```

    * `docs/ADOPT_RULES.md` — the full keep/delete rules.
    * `docs/CHANGES.md` — the exact file-by-file change list.
    * `AGENT_INSTRUCTIONS.md` — the one-page runbook for a model.
    * `BUILD.md` — how to build, verify and ship.

    ## Layout

    ```
    savage/                 the engine
      bootstrap.py          idempotent, non-fatal, budget-capped auto-run
      config.py             paths + routing
      llm/                  OpenAI-compatible client + stage router
      premium/              the 10-layer premium harness (L1..L10)
      registry/             tool registry + tier enforcement
      mcp/                  stdio JSON-RPC client, gateway, __MCP__ servers
      undercover/           adopted-repo catalog
    factory/                the five spaces
      manager/              routing + durable queue (O_EXCL lockfiles)
      spaces/apk-cli/       isolated APK build cell (only release emitter)
      cleaner/              dry-run-first maintenance
      improver/             24/7 self-improvement
      adopt/                keep/delete planner
    factory/registry/       tools.json / repos.json / mcp.json / tools.md
    factory/rules/          one rule set per stage
    .github/workflows/      gate, apk-cli, cleaner, improver
    ```

    ## Commands

    ```bash
    python3 __SELF__ init        # build everything (additive)
    python3 __SELF__ doctor      # self-verify -> VERDICT: ALL GREEN
    python3 __SELF__ catalog     # __TOOLS__ tools
    python3 __SELF__ build "car racing game"
    python3 __SELF__ gate        # deterministic gates
    python3 __SELF__ adopt [--apply] [--mirrors]
    python3 __SELF__ clean [--apply]
    python3 __SELF__ improve
    python3 __SELF__ mcp
    python3 __SELF__ all         # init + doctor + catalog
    ```

    ## Trust tiers

    Only **VERIFIED** tools may gate a release. PROVISIONAL/UNVERIFIED may
    assist; QUARANTINE may not run at all.

    ## Auto-run

    `import savage` is the installation: it idempotently ensures the tree exists,
    registers the MCP fleet and checks the environment — non-fatally.
    """)


def agent_instructions() -> str:
    return textwrap.dedent("""\
    # AGENT INSTRUCTIONS — SAVAGE FACTORY

    You are a model, possibly a small one. You do **not** need to understand the
    code in `__SELF__`. You only need to **run** it. Running it builds the whole
    factory on disk, identically every time, and then the factory builds,
    verifies, packages, ships and improves software with zero human intervention.

    ## STEP 1 — place the file

    Put the single file at the root of your repository, named exactly:

    ```
    __SELF__
    ```

    ## STEP 2 — run these three commands, in order, from the repo root

    ```bash
    python3 __SELF__ init      # materialise the factory (writes ~90 files)
    python3 __SELF__ doctor    # self-verify; must print: VERDICT: ALL GREEN
    python3 __SELF__ catalog   # print the __TOOLS__-tool registry
    ```

    ## STEP 3 — done

    ALL GREEN means structural checks and the offline smoke path passed; it is not proof that a product-specific APK exists.
    Nothing else is required. There is nothing to configure and no dependency to
    install: this file uses only the Python standard library.

    ## STEP 4 (optional) — build something

    ```bash
    python3 __SELF__ build "car racing game"
    ```

    ## STEP 5 (optional) — see what will be deleted/kept BEFORE anything changes

    ```bash
    python3 __SELF__ adopt          # dry-run report (writes ADOPT.md)
    python3 __SELF__ adopt --apply  # only then does it delete anything
    ```

    ## IF YOU ONLY RUN ONE THING

    ```bash
    python3 __SELF__ all
    ```

    `all` = init + doctor + catalog, in one shot.

    ## WHAT THIS FILE KEEPS AND DELETES IN YOUR EXISTING REPO

    The factory is **additive by default**. `init` only ever **writes** new files
    (`savage/`, `factory/`, `.github/workflows/`, `README.md`, `docs/`, `tools/`).
    It never deletes or overwrites your existing work unless you pass `--force`.

    Deletion is a separate, explicit, dry-run-first command: `adopt`. It
    classifies every path into five buckets and writes them to `ADOPT.md`:

    | Bucket  | Meaning | Touched by `--apply`? |
    |---------|---------|-----------------------|
    | KEEP    | `.git/`, `README*`, `LICENSE*`, `docs/`, the factory itself | never |
    | DELETE  | `__pycache__/`, `*.pyc`, `node_modules/`, caches, junk | yes |
    | MIRROR  | duplicate tree (e.g. `factory-2/`) | only with `--mirrors` |
    | REWRITE | hollow CI gate (`continue-on-error: true`, `|| true`) | reported only |
    | UNKNOWN | anything unrecognised | never |

    So the answer to "what gets deleted?" is: **nothing**, until you run
    `adopt --apply`. And even then, only the DELETE bucket. KEEP and UNKNOWN are
    never touched.

    ## THE MODEL THIS FILE BUILDS

    * **7 STAGES**: intake -> spec -> build -> verify -> package -> ship -> improve
    * **4 TIERS**: VERIFIED / PROVISIONAL / UNVERIFIED / QUARANTINE.
      Only VERIFIED tools may gate a release.
    * **10 LAYERS**: L1 Spec Amplifier, L2 Scaffold Selector, L3 Best-of-N
      Sampler, L4 Verifier/Ensemble, L5 Self-Repair Loop, L6 Constrained
      Decoding, L7 Golden Retrieval, L8 Deterministic Gates, L9 Sealed Holdout,
      L10 Worktree Isolation.
    * **5 SPACES**: `factory/manager`, `factory/spaces/apk-cli`,
      `factory/cleaner`, `factory/improver`, `factory/adopt`.
    * **1 BUS**: MCP (stdio JSON-RPC 2.0) — a __MCP__-server fleet.

    ## DESIGN LAW

    "Deterministic shell, agentic core." The workflow is plain Python + JSON.
    Agents are bounded nodes. Nothing merges without a deterministic gate. No
    piracy, no leaked keys, no ToS bypass, no faked results. Ever.

    ## HOW A LOW-END MODEL GETS PREMIUM OUTPUT

    1. Run `init`. Everything appears. Nothing to interpret.
    2. Run `doctor`. ALL GREEN means the factory is real and working.
    3. Call `build("your idea")`. The harness amplifies the spec (L1), picks a
       scaffold (L2), samples N candidates in isolated worktrees (L3/L10),
       verifies with a DIFFERENT model (L4), repairs until the deterministic
       gates pass (L5/L8), then re-checks against a SEALED holdout the generator
       never saw (L9). It returns a verified artifact + a BuildResult.
    4. That is it. The premium result comes from the harness, not the model.
    """)


def build_md() -> str:
    return textwrap.dedent("""\
    # BUILD — SAVAGE FACTORY

    Everything here is standard-library Python 3.11. There is nothing to install.

    ## 0. Materialise

    ```bash
    python3 __SELF__ init
    python3 __SELF__ doctor     # must end with: VERDICT: ALL GREEN
    ```

    `init` is idempotent and additive. Re-running it only writes files that are
    missing or changed; it never deletes. Pass `--force` to overwrite.

    ## 1. Build an artifact

    ```bash
    python3 __SELF__ build "a CLI that converts CSV to JSON"
    ```

    The premium harness runs the 10 layers:

    1. **L1 Spec Amplifier** — turns a one-line prompt into a structured spec.
    2. **L2 Scaffold Selector** — picks one of the shipped scaffolds.
    3. **L3 Best-of-N Sampler** — generates N candidates.
    4. **L10 Worktree Isolation** — each candidate gets a private, disposable
       workspace (a real `git worktree` when git is available, otherwise an
       isolated directory under `.worktrees/`).
    5. **L4 Verifier/Ensemble** — scores candidates with a different model.
    6. **L5 Self-Repair Loop** — repairs the best candidate until gates pass.
    7. **L6 Constrained Decoding** — GBNF grammar keeps JSON well-formed.
    8. **L7 Golden Retrieval** — pulls proven patterns from the golden store.
    9. **L8 Deterministic Gates** — compile, tests, no-hollow, no-secrets.
    10. **L9 Sealed Holdout** — re-verifies against a sealed check set the
        generator never saw. A build only "passes" if public **and** sealed pass.

    ## 2. Gate

    ```bash
    python3 __SELF__ gate
    ```

    Deterministic gates only. Only **VERIFIED** tools may gate a release.

    ## 3. Package & ship

    The only release emitter is the isolated APK/CLI cell:

    ```bash
    bash factory/spaces/apk-cli/build.sh
    bash factory/spaces/apk-cli/gate.sh
    ```

    Nothing else may emit a release artifact.

    ## 4. Maintain

    ```bash
    python3 __SELF__ clean [--apply]   # dry-run by default
    python3 __SELF__ improve           # one 24/7 improvement cycle
    python3 __SELF__ adopt [--apply]   # keep/delete planner (dry-run first)
    ```

    ## 5. Rebuild this single file (only if you edited the sources)

    ```bash
    python3 _parts/pack.py
    cat _parts/01_data.py _parts/02_data2.py _parts/00_bundle.py _parts/06_runtime.py > __SELF__
    python3 -m py_compile __SELF__
    ```
    """)


def adopt_rules_md() -> str:
    return textwrap.dedent("""\
    # ADOPT RULES — keep / delete planner

    `adopt` decides, path by path, what the factory keeps and what it may delete
    in **your** existing repository. It is **dry-run first**: it writes `ADOPT.md`
    and changes nothing until you pass `--apply`.

    ```bash
    python3 __SELF__ adopt                      # plan only
    python3 __SELF__ adopt --apply              # delete the DELETE bucket
    python3 __SELF__ adopt --apply --mirrors    # also delete MIRROR duplicates
    ```

    ## The five buckets

    Evaluation order is **DELETE -> KEEP -> REWRITE -> UNKNOWN**. DELETE is
    checked first so caches and junk are always cleaned, even when they sit
    inside a kept tree (e.g. `savage/__pycache__/x.pyc`).

    ### KEEP — never touched
    Real source, docs, VCS and the factory itself:
    * `.git/`, `.gitignore`, `.gitattributes`
    * `README*`, `LICENSE*`, `NOTICE*`, `CHANGELOG*`, `CONTRIBUTING*`
    * `docs/`, `doc/`
    * the factory itself: `savage/`, `factory/`, `.github/`, `tools/`, `.savage/`
    * `__SELF__`

    ### DELETE — safe to remove (only with `--apply`)
    * `__pycache__/`, `*.pyc`, `*.pyo`, `*.pyd`
    * `.pytest_cache/`, `.mypy_cache/`, `.ruff_cache/`, `.tox/`
    * `node_modules/`, `.next/`, `dist/`, `build/`, `.cache/`
    * `.DS_Store`, `Thumbs.db`, `*.log`, `*.tmp`, `*.bak`, `*.orig`
    * `*.egg-info/`, `.eggs/`

    ### MIRROR — duplicate tree (needs `--mirrors`)
    A second copy of a tree that already exists under `factories/`. Example:
    `factory-2/` is shadowed by `factories/factory-2/`. Removing the shadow
    removes confusion, not capability. **Off by default.**

    ### REWRITE — hollow CI gate (reported, never auto-deleted)
    Any workflow that fakes success:
    * contains `continue-on-error: true`
    * contains `|| true` or `|| exit 0`

    Replace it with `.github/workflows/savage-factory-gate.yml` (generated by
    `init`). `adopt` reports these; it does not delete them.

    ### UNKNOWN — left completely alone
    Anything not matched above. The model decides. The factory never guesses.

    ## Guarantees

    * `init` never deletes. `adopt` is the only destructive command.
    * `adopt` without `--apply` is a pure read: it writes one markdown report.
    * `--apply` deletes **only** the DELETE bucket (plus MIRROR if `--mirrors`).
    * KEEP and UNKNOWN are never deleted, under any flag.
    * Every action is logged; the report lists the reclaimable bytes.
    """)


def changes_md() -> str:
    return textwrap.dedent("""\
    # CHANGES — what the factory adds, and what you should keep

    This is the exact change list for adopting the factory into an existing repo.
    Nothing here is destructive. `init` is additive; `adopt` is the only command
    that deletes, and it is dry-run first.

    ## ADDED by `init` (new files; your existing files are untouched)

    | Path | What it is |
    |------|-----------|
    | `__SELF__` | the single-file factory you already have |
    | `savage/` | the engine (bootstrap, config, llm, premium, registry, mcp, undercover) |
    | `savage/premium/holdout.py` | L9 sealed holdout verifier |
    | `savage/premium/worktree.py` | L10 worktree isolation |
    | `factory/manager/` | routing + durable queue |
    | `factory/spaces/apk-cli/` | isolated APK/CLI build cell (only release emitter) |
    | `factory/cleaner/` | dry-run-first maintenance |
    | `factory/improver/` | 24/7 self-improvement |
    | `factory/adopt/` | keep/delete planner |
    | `factory/registry/` | `tools.json`, `repos.json`, `mcp.json`, `tools.md` |
    | `factory/rules/` | one rule set per stage |
    | `.github/workflows/` | gate, apk-cli, cleaner, improver |
    | `docs/` | `SAVAGE_FACTORY.md`, `ADOPT_RULES.md`, `CHANGES.md` |
    | `tools/savage_factory.py` | thin CLI wrapper |
    | `AGENT_INSTRUCTIONS.md` | one-page runbook for a model |
    | `BUILD.md` | build / verify / ship guide |
    | `README.md` | project readme (only if absent, unless `--force`) |

    ## KEPT — never modified, never deleted

    * `.git/` and all history
    * `README*`, `LICENSE*`, `NOTICE*`, `CHANGELOG*`, `CONTRIBUTING*`
    * `docs/` and `doc/`
    * every source file you already had that is not in a DELETE pattern
    * the factory itself once installed

    ## DELETED — only by `adopt --apply`

    * caches and bytecode: `__pycache__/`, `*.pyc`, `.pytest_cache/`, `.mypy_cache/`
    * dependency/build dirs: `node_modules/`, `dist/`, `build/`, `.next/`
    * OS/log junk: `.DS_Store`, `Thumbs.db`, `*.log`, `*.tmp`, `*.bak`

    ## DELETED — only by `adopt --apply --mirrors`

    * duplicate trees such as `factory-2/` that are shadowed by `factories/factory-2/`

    ## REWRITTEN (by you, reported by `adopt`)

    * hollow CI gates containing `continue-on-error: true` or `|| true` should be
      replaced with `.github/workflows/savage-factory-gate.yml`.

    ## UNKNOWN

    * everything else — left exactly as it is.

    ## The one-line summary

    **Run `python3 __SELF__ init`. It only adds. Run `python3 __SELF__ adopt` to
    see the plan. Run `adopt --apply` only if you agree with the DELETE bucket.**
    """)


def hardening_doc() -> str:
    return """# SAVAGE FACTORY v4 DEBUG — safety contract

This build is intentionally fail-closed. A green result means the checked tree
was actually inspected; it does not mean an unimplemented product is complete.

- `init` never overwrites existing files. Conflicts are reported and return nonzero.
- `doctor` runs a real offline smoke build unless `--no-smoke` is used.
- `gate` scans the repository root, not this factory's embedded source.
- `adopt --apply` never deletes tracked files and only removes byte-identical mirrors.
- Model repair patches must stay inside the candidate directory; missing files are failures.
- Candidate subprocesses receive a minimal environment without API keys.
- A baseline scaffold is reported as `TEMPLATE-ONLY`, never `SHIP`.

Run from the repository root:

```bash
python3 SAVAGE_FACTORY.py init
python3 SAVAGE_FACTORY.py doctor
python3 SAVAGE_FACTORY.py gate
python3 SAVAGE_FACTORY.py adopt
```

Use `--force` only after reviewing the conflict list. Use `adopt --apply` only
after reviewing `ADOPT.md`. The factory does not claim a real APK was built
unless the Android SDK/Gradle/APK signer path actually ran and passed.
"""
def _all_generated_files() -> Dict[str, str]:
    files = dict(parse_bundle())
    files["factory/registry/tools.json"] = json.dumps(registry_dict(), indent=2)
    files["factory/registry/repos.json"] = json.dumps(repos_dict(), indent=2)
    files["factory/registry/mcp.json"] = json.dumps(mcp_dict(), indent=2)
    files["factory/registry/tools.md"] = tools_markdown()
    files["savage/undercover/catalog.json"] = json.dumps(repos_dict(), indent=2)
    files[".savage/mcp.json"] = json.dumps(mcp_dict(), indent=2)
    files["docs/SAVAGE_FACTORY.md"] = docs_main()
    files["docs/factory-v4/ADOPT_RULES.md"] = adopt_rules_md()
    files["docs/factory-v4/CHANGES.md"] = changes_md()
    files["docs/factory-v4/README.md"] = readme_file()
    files["docs/factory-v4/AGENT_INSTRUCTIONS.md"] = agent_instructions()
    files["docs/factory-v4/BUILD.md"] = build_md()
    files["docs/factory-v4/HARDENING.md"] = hardening_doc()
    files["tools/savage_factory.py"] = cli_wrapper()
    files.update(rules_files())
    files.update(workflow_files())
    files.update(mcp_server_files())
    # resolve self-referential placeholders everywhere (docs, workflows, wrapper)
    subs = {
        "__SELF__": SELF_NAME,
        "__CODENAME__": GENESIS_CODENAME,
        "__VERSION__": GENESIS_VERSION,
        "__TOOLS__": str(len(TOOL_CATALOG)),
        "__MCP__": str(len(MCP_FLEET)),
    }
    for _k in list(files):
        _v = files[_k]
        if isinstance(_v, str) and "__" in _v:
            for _a, _b in subs.items():
                if _a in _v:
                    _v = _v.replace(_a, _b)
            files[_k] = _v
    return files


def cmd_init(root: Path, force: bool = False) -> int:
    files = _all_generated_files()
    stats = write_tree(root, files, force=force)
    # extra dirs
    for d in (".savage/logs", ".savage/cache", "factory/golden", "builds", "artifacts/apk-cli"):
        (root / d).mkdir(parents=True, exist_ok=True)
    print("SAVAGE FACTORY init -> %s" % root)
    print("  files: %d (written %d, unchanged %d, conflicts %d)" % (
        stats["total"], stats["written"], stats["unchanged"], stats["conflicts"]))
    if stats["conflicts"]:
        print("  CONFLICTS (not overwritten):")
        for rel in stats["conflict_paths"][:40]: print("    - " + rel)
        print("  Re-run with --force only after reviewing these paths.")
    print("  tools: %d | repos: %d | mcp servers: %d" % (
        len(TOOL_CATALOG), len(REPO_CATALOG), len(MCP_FLEET)))
    return 1 if stats["conflicts"] else 0


def cmd_catalog(as_json: bool = False) -> int:
    reg = registry_dict()
    if as_json:
        print(json.dumps(reg, indent=2))
        return 0
    print("SAVAGE TOOL REGISTRY — %d tools" % reg["count"])
    counts: Dict[str, int] = {}
    for t in reg["tools"]:
        counts[t["tier"]] = counts.get(t["tier"], 0) + 1
    for tier in TIERS:
        print("  %s %-11s %d" % (TIER_ICON[tier], tier, counts.get(tier, 0)))
    print("  groups: " + ", ".join(sorted(GROUPS)))
    return 0


def cmd_doctor(root: Path, smoke: bool = False) -> int:
    print("=== SAVAGE DOCTOR ===")
    issues = []
    files = _all_generated_files()
    missing = [rel for rel in files if not (root / rel).exists()]
    if missing:
        issues.append("%d files missing (run init): %s" % (len(missing), missing[:5]))
    print("[1] files present: %s" % ("OK" if not missing else "MISSING %d" % len(missing)))

    reg = registry_dict()
    ok_reg = reg["count"] >= 200
    print("[2] registry: %d tools %s" % (reg["count"], "OK" if ok_reg else "FAIL"))
    if not ok_reg:
        issues.append("registry has < 200 tools")

    # compile written python
    py = [root / rel for rel in files if rel.endswith(".py") and (root / rel).exists()]
    bad = []
    for p in py:
        try:
            compile(p.read_text(), str(p), "exec")
        except SyntaxError as exc:
            bad.append("%s: %s" % (p, exc))
    print("[3] python compiles: %d files %s" % (len(py), "OK" if not bad else "FAIL"))
    issues += bad

    # gateway self-test
    sys.path.insert(0, str(root))
    try:
        os.environ["SAVAGE_ROOT"] = str(root)
        os.environ["SAVAGE_AUTORUN"] = "0"
        from savage.mcp import gateway as _gw
        gw_ok = _gw.self_test()
    except Exception as exc:
        gw_ok = False
        issues.append("gateway import failed: %r" % exc)
    print("[4] mcp gateway: %s" % ("OK" if gw_ok else "FAIL"))

    if smoke:
        try:
            import importlib
            import savage.premium as prem
            importlib.reload(prem)
            res = prem.build("build a tiny python cli tool", n=1, budget_rounds=1,
                             out_root=root / "builds")
            print("[5] smoke build: %s (verdict=%s, gates=%s)" % (
                "OK" if res.verdict else "FAIL", res.verdict, res.gates["passed"]))
            if not res.gates["passed"]:
                issues.append("smoke build gates failed")
        except Exception as exc:
            print("[5] smoke build: FAIL (%r)" % exc)
            issues.append("smoke build error: %r" % exc)

    if issues:
        print("\nVERDICT: ATTENTION — %d issue(s)" % len(issues))
        for i in issues[:10]:
            print("  - %s" % i)
        return 1
    print("\nVERDICT: ALL GREEN")
    return 0


def cmd_build(root: Path, prompt: str, n: int, rounds: int) -> int:
    sys.path.insert(0, str(root))
    os.environ["SAVAGE_ROOT"] = str(root)
    os.environ["SAVAGE_AUTORUN"] = "0"
    from savage.premium import build as _build
    res = _build(prompt, n=n, budget_rounds=rounds, out_root=root / "builds")
    print(json.dumps(res.to_dict(), indent=2, default=str))
    print("\nVERDICT: %s" % res.verdict)
    print("ARTIFACT: %s" % res.artifact)
    return 0 if res.verdict == "SHIP" else 1


def cmd_gate(root: Path) -> int:
    """Audit the actual repository root and fail closed on missing evidence."""
    root = Path(root).resolve()
    print("=== REPOSITORY DETERMINISTIC GATES ===")
    failures = []
    files = [p for p in root.rglob("*") if p.is_file() and ".git" not in p.parts
             and "node_modules" not in p.parts and "__pycache__" not in p.parts]
    if not files:
        failures.append("repository has no source files")
    py_errors = []
    for p in files:
        if p.suffix == ".py":
            try:
                compile(p.read_text(encoding="utf-8", errors="strict"), str(p), "exec")
            except Exception as exc:
                py_errors.append(f"{p.relative_to(root)}: {exc}")
    if py_errors:
        failures.extend("python:" + e for e in py_errors)
    print("python_compile=%s" % ("PASS" if not py_errors else "FAIL"))
    secret = re.compile(r"(AKIA[0-9A-Z]{16}|(?:ghp|github_pat)_[A-Za-z0-9_]{20,}|"
                        r"sk-[A-Za-z0-9]{20,}|AIza[0-9A-Za-z_-]{20,}|"
                        r"xox[baprs]-[A-Za-z0-9-]{10,}|-----BEGIN " + r".*PRIVATE " + r"KEY-----)")
    hollow = ("raise NotImplemented" + "Error", "pass  # " + "TODO", "return True  # gate")
    scan_hits = []
    for p in files:
        try:
            raw = p.read_bytes()
            text = raw.decode("utf-8", "ignore")
            hidden = raw.decode("utf-16-le", "ignore") + raw.decode("utf-16-be", "ignore")
            if secret.search(text) or secret.search(hidden): scan_hits.append("secret:" + str(p.relative_to(root)))
            if p.suffix in (".py", ".js", ".ts", ".java", ".sh"):
                for pat in hollow:
                    if pat in text: scan_hits.append("hollow:" + str(p.relative_to(root)))
        except OSError as exc:
            scan_hits.append("unreadable:%s:%s" % (p, exc))
    failures.extend(scan_hits)
    print("anti_deception=%s" % ("PASS" if not scan_hits else "FAIL"))
    ci_hits = []
    for p in files:
        if ".github" in p.parts and p.suffix in (".yml", ".yaml"):
            text = p.read_text(encoding="utf-8", errors="ignore")
            if "continue-on-error: true" in text or "|| true" in text or "|| exit 0" in text:
                ci_hits.append(str(p.relative_to(root)))
    failures.extend("hollow_ci:" + p for p in ci_hits)
    print("ci_fail_closed=%s" % ("PASS" if not ci_hits else "FAIL"))
    if shutil.which("git"):
        probe = subprocess.run(["git", "-C", str(root), "rev-parse", "--is-inside-work-tree"], capture_output=True, text=True)
        if probe.returncode == 0:
            diff = subprocess.run(["git", "-C", str(root), "diff", "--check"], capture_output=True, text=True)
            if diff.returncode != 0:
                failures.append("git diff --check failed: " + (diff.stdout or diff.stderr)[-300:])
    if failures:
        print("VERDICT: FAIL")
        for item in failures[:40]: print("  - " + item)
        return 1
    print("VERDICT: PASS — repository evidence passed")
    return 0
def cmd_clean(root: Path, apply: bool) -> int:
    sys.path.insert(0, str(root))
    from factory.cleaner import cleaner
    plan = cleaner.plan(str(root))
    print("CLEANER %s" % ("APPLY" if apply else "DRY-RUN"))
    print("  targets: %d, reclaim: %.1f KB" % (plan["count"], plan["reclaim_bytes"] / 1024))
    for t in plan["targets"][:20]:
        print("  - [%s] %s" % (t["reason"], t["path"]))
    if apply:
        out = cleaner.apply(plan)
        print("  removed: %d" % out["count"])
    else:
        print("  (dry-run; pass --apply to delete)")
    return 0


def cmd_adopt(root: Path, apply: bool = False, mirrors: bool = False) -> int:
    """Keep/delete planner.  Dry-run first: writes ADOPT.md, changes nothing."""
    module_dir = root / "factory" / "adopt" / "adopt.py"
    if not module_dir.is_file():
        print("ADOPT FAIL: factory is not initialized; run init first (no files changed)")
        return 1
    sys.path.insert(0, str(root))
    from factory.adopt import adopt
    plan = adopt.plan(str(root))
    report = adopt.render_markdown(plan)
    (root / "ADOPT.md").write_text(report, encoding="utf-8")
    counts = plan["counts"]
    print("ADOPT %s" % ("APPLY" if apply else "DRY-RUN"))
    print("  keep=%d delete=%d mirror=%d rewrite=%d unknown=%d" % (
        counts.get("KEEP", 0), counts.get("DELETE", 0), counts.get("MIRROR", 0),
        counts.get("REWRITE", 0), counts.get("UNKNOWN", 0)))
    print("  reclaim=%.1f KB  mirror=%.1f KB" % (
        plan["reclaim_bytes"] / 1024.0, plan["mirror_bytes"] / 1024.0))
    print("  report: ADOPT.md")
    for e in plan["buckets"]["DELETE"][:20]:
        print("  - [DELETE] %s" % e["path"])
    if apply:
        out = adopt.apply(plan, include_mirrors=mirrors)
        print("  removed: %d" % out["count"])
        if out.get("skipped"):
            print("  protected/skipped: %d" % len(out["skipped"]))
            for rel in out["skipped"][:20]: print("    - " + rel)
    else:
        print("  (dry-run; pass --apply to delete the DELETE bucket)")
    return 0


def cmd_improve(root: Path) -> int:
    sys.path.insert(0, str(root))
    from factory.improver import improver
    report = improver.cycle(root, root / "factory" / "registry" / "tools.json")
    print(json.dumps(report, indent=2))
    return 0


def cmd_mcp(as_json: bool = False) -> int:
    data = mcp_dict()
    if as_json:
        print(json.dumps(data, indent=2))
        return 0
    print("MCP FLEET — %d servers (%s)" % (data["count"], data["transport"]))
    for s in data["servers"]:
        print("  %-10s %-11s %s" % (s["id"], s["tier"], s["purpose"]))
    return 0


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog=SELF_NAME,
        description="SAVAGE FACTORY GENESIS — single-file, self-contained software factory.")
    parser.add_argument("--root", default=os.getcwd(), help="repo root (default: cwd)")
    sub = parser.add_subparsers(dest="cmd")

    p_init = sub.add_parser("init", help="materialise the whole factory")
    p_init.add_argument("--force", action="store_true", help="overwrite existing files")

    p_doctor = sub.add_parser("doctor", help="self-verify the install and run an offline smoke build")
    p_doctor.add_argument("--no-smoke", action="store_true", help="structural checks only; not release evidence")

    p_cat = sub.add_parser("catalog", help="print the tool registry")
    p_cat.add_argument("--json", action="store_true")

    p_build = sub.add_parser("build", help="run the premium harness on a prompt")
    p_build.add_argument("prompt")
    p_build.add_argument("-n", type=int, default=DEFAULT_N)
    p_build.add_argument("--rounds", type=int, default=DEFAULT_BUDGET_ROUNDS)

    sub.add_parser("gate", help="run the deterministic gates")
    p_clean = sub.add_parser("clean", help="cleaner (dry-run by default)")
    p_clean.add_argument("--apply", action="store_true")
    p_adopt = sub.add_parser("adopt", help="keep/delete planner (dry-run by default)")
    p_adopt.add_argument("--apply", action="store_true")
    p_adopt.add_argument("--mirrors", action="store_true")
    sub.add_parser("improve", help="one improver cycle")
    p_mcp = sub.add_parser("mcp", help="print the MCP fleet")
    p_mcp.add_argument("--json", action="store_true")
    sub.add_parser("all", help="init + doctor + catalog")

    args = parser.parse_args(argv)
    root = Path(args.root).expanduser().resolve()

    if args.cmd == "init":
        return cmd_init(root, force=args.force)
    if args.cmd == "doctor":
        return cmd_doctor(root, smoke=not args.no_smoke)
    if args.cmd == "catalog":
        return cmd_catalog(as_json=args.json)
    if args.cmd == "build":
        return cmd_build(root, args.prompt, args.n, args.rounds)
    if args.cmd == "gate":
        return cmd_gate(root)
    if args.cmd == "clean":
        return cmd_clean(root, apply=args.apply)
    if args.cmd == "adopt":
        return cmd_adopt(root, apply=args.apply, mirrors=args.mirrors)
    if args.cmd == "improve":
        return cmd_improve(root)
    if args.cmd == "mcp":
        return cmd_mcp(as_json=args.json)
    if args.cmd == "all":
        rc = cmd_init(root)
        rc |= cmd_doctor(root, smoke=True)
        rc |= cmd_gate(root)
        rc |= cmd_catalog()
        return rc
    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
