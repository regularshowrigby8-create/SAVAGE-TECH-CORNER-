# Test results

Executed from the packaged directory:

```text
TEST_RC:0 HELP_RC:0 COMPILE_RC:0
Ran 5 tests in 1.499s
OK
```

Covered regressions:

- clean initialization and actual repository gate pass;
- hollow code and token-shaped secret rejection;
- non-destructive initialization conflict handling;
- baseline scaffold classified as `TEMPLATE-ONLY`, not `SHIP`;
- tracked files preserved during adoption cleanup.

The ZIP itself was validated with `unzip -t` and reported no compressed-data errors. The standalone `SAVAGE_FACTORY.py` compiled successfully and its CLI help executed successfully.
