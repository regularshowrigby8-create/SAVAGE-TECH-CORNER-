# SAVAGE FACTORY v4 DEBUG — final package

## What changed

This package hardens the `factory rework` engine against false-green certification and unsafe cleanup:

1. **Repository gate now audits the actual `--root` tree**, not the embedded base64 blob.
2. **Secrets, hollow code, hollow CI, Python syntax, and git whitespace errors fail closed.** Detector literals are constructed to avoid self-matching.
3. **`init` is non-destructive by default**: existing differing files are reported as conflicts and cause a nonzero exit; `--force` is explicit.
4. **`doctor` runs the offline smoke build by default.** `--no-smoke` is structural-only and is not release evidence.
5. **Offline baseline scaffolds are `TEMPLATE-ONLY`, never `SHIP`.** A real product-specific change is required for shipping.
6. **Repair patches are path-confined** and missing-file auto-fixes no longer create empty placeholders.
7. **Candidate subprocesses receive a reduced environment** with API-key variables excluded.
8. **Adoption deletion is conservative**: tracked files are preserved, traversal paths are rejected, and mirrors must be recursively byte-identical before they are eligible.
9. **Candidate workspaces are released in a `finally` block.**
10. **The generated documentation is namespaced** under `docs/factory-v4/` so the factory does not silently replace a host README.

## Safe execution

```bash
python3 SAVAGE_FACTORY.py --root /path/to/repo init
python3 SAVAGE_FACTORY.py --root /path/to/repo doctor
python3 SAVAGE_FACTORY.py --root /path/to/repo gate
python3 SAVAGE_FACTORY.py --root /path/to/repo adopt
```

Review `ADOPT.md` before applying cleanup:

```bash
python3 SAVAGE_FACTORY.py --root /path/to/repo adopt --apply
python3 SAVAGE_FACTORY.py --root /path/to/repo adopt --apply --mirrors
```

Run a build:

```bash
python3 SAVAGE_FACTORY.py --root /path/to/repo build "a small Android app" -n 4 --rounds 4
```

A `SHIP` verdict means the deterministic public gates and independent holdout passed. `TEMPLATE-ONLY` and `FIX-FIRST` are not release verdicts.

## Android/APK honesty boundary

The generic Android scaffold performs static structure checks when the Android SDK/Gradle toolchain is absent. That is intentionally not called a real APK build. A production APK must pass the APK cell gate with a real Gradle/SDK build, manifest/package checks, provenance/hash checks, alignment, and signing verification.

## Known limitations

- The package cannot turn an underspecified prompt into a complete product without a capable model and project-specific acceptance tests.
- Static secret scanning is a detector, not a replacement for secret rotation or a managed secret scanner.
- The generic holdout is stronger than a single public test command but still needs product-specific hidden tests for serious applications.
- The default offline smoke build is expected to return `TEMPLATE-ONLY`; that is the honest result when no model supplies a real implementation change.
