# SAVAGE FACTORY v4 DEBUG — criticism and improvement record

## Executive verdict

The `factory rework` commit had a useful layered shape, but it was not yet a dependable APK factory. The main risk was **false confidence**: several checks could pass without proving that the user’s repository, candidate implementation, or APK had actually been validated.

The debug build hardens those paths and deliberately returns non-release states when evidence is missing. It is safer and more diagnosable, but it is not magic: top-level APK quality still depends on a real Android build cell, product-specific acceptance tests, and a model that makes actual candidate changes.

## Critical findings addressed

| Area | Original weakness | Debug improvement |
|---|---|---|
| Root gate | `gate` scanned the embedded bundle and could report PASS while the target repo was broken | Gate walks the actual `--root`; Python compile, secrets, hollow code, hollow CI and git checks fail closed |
| Doctor | Smoke build was opt-in, so `all` could look green without exercising the build path | Smoke is the default; `--no-smoke` is explicitly structural-only |
| Candidate variation | Sampler asked for prose suggestions but ignored them; best-of-N could be cosmetic duplicates | Only validated in-tree JSON patches count as variants; candidate content hashes are recorded |
| Repair | Model file paths were not confined; missing files could become empty placeholders | Absolute/traversal paths are rejected; missing files remain failures |
| Template shipping | A passing baseline scaffold could be presented as a product result | Unchanged baseline is `TEMPLATE-ONLY` and forces gates false |
| Process execution | Candidate commands inherited the full environment | Candidate subprocesses receive a reduced environment without API-key variables |
| Init | Existing differing files were silently overwritten unless users knew the force behavior | Existing conflicts are listed and return nonzero; `--force` is explicit |
| Adopt | Tracked logs matched DELETE patterns; mirror detection assumed duplicates; deletion errors were swallowed | Tracked paths are protected, mirrors require recursive byte identity, paths are root-confined |
| Workspaces | Candidate cleanup was not guaranteed after the build | Candidate paths are released in `finally` |
| Self-scanning | Secret patterns could flag their own detector source | Detector literals are assembled to avoid self-matching while retaining runtime detection |
| APK gate | Valid ZIP plus `provenance.json` was not sufficient evidence of a signed/releasable APK | The package documents the boundary: static Android validation is not a real APK build; the APK cell must prove build/provenance/signing evidence |

## Additional quality recommendations

1. Add project-specific acceptance tests to every APK prompt: launch, navigation, core user flow, offline behavior, and persistence.
2. Make the Android cell produce a provenance record containing source commit, Gradle task, SDK/build-tools versions, APK SHA-256, signer identity, and test results; verify every field against the produced artifact.
3. Run release builds in a clean container with pinned SDK/build-tools and no network after dependency resolution.
4. Add mutation testing: deliberately break the manifest, launcher activity, a test assertion, and the APK hash, then require each gate to fail.
5. Add differential candidate checks so candidates that only change comments or documentation cannot win over behaviorally tested candidates.
6. Add dependency lock verification and SBOM generation for APK and web/Node projects.
7. Keep an append-only build evidence directory; do not delete logs as part of normal adoption cleanup.
8. Add a human review checkpoint for destructive cleanup and signing/publishing actions.

## Correct interpretation of results

- `VERDICT: PASS` from `gate` means repository evidence passed the checks implemented here.
- `VERDICT: ALL GREEN` from `doctor --no-smoke` means only structural checks passed.
- `TEMPLATE-ONLY` means the scaffold passed mechanical tests but was not changed into a product implementation.
- `FIX-FIRST` means one or more public or sealed checks failed.
- `SHIP` is reserved for a changed candidate that passes both public gates and the sealed holdout.
