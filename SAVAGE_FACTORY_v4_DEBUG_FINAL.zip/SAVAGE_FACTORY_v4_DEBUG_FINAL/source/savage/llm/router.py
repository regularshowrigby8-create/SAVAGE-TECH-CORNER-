"""Stage -> model-class routing, then model-class -> endpoint."""
from __future__ import annotations

from ..config import ROUTING
from .client import LLMClient, available_endpoints


def route_stage(stage: str) -> str:
    return ROUTING.get(stage, "cheap")


def pick(stage: str, *, force_endpoint: str | None = None) -> LLMClient:
    """Return a client bound to the model class the stage routes to."""
    cls = route_stage(stage)
    if cls == "none":
        cls = "cheap"
    return LLMClient(endpoint=force_endpoint, cls=cls)


def describe() -> dict:
    return {"routing": dict(ROUTING), "endpoints": available_endpoints()}
