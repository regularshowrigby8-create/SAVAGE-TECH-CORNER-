"""A tiny, dependency-free OpenAI-compatible client.

It walks the endpoint list, uses the first one with a usable key/host, and falls
back to a deterministic offline stub so the whole harness still runs end-to-end
in a sandbox with no credentials (useful for the low-end model to self-test).
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Any, Dict, List, Optional

# id, base_url, env_key, default_model, class, notes
ENDPOINTS: List[tuple] = [
    ("github-models", "https://models.github.ai/inference", "GITHUB_TOKEN", "openai/gpt-4o-mini", "premium", ""),
    ("groq", "https://api.groq.com/openai/v1", "GROQ_API_KEY", "llama-3.3-70b-versatile", "premium", ""),
    ("cerebras", "https://api.cerebras.ai/v1", "CEREBRAS_API_KEY", "llama3.1-70b", "premium", ""),
    ("gemini", "https://generativelanguage.googleapis.com/v1beta/openai", "GEMINI_API_KEY", "gemini-1.5-flash", "premium", ""),
    ("deepseek", "https://api.deepseek.com/v1", "DEEPSEEK_API_KEY", "deepseek-chat", "cheap", ""),
    ("openrouter", "https://openrouter.ai/api/v1", "OPENROUTER_API_KEY", "meta-llama/llama-3.1-8b-instruct:free", "cheap", ""),
    ("mistral", "https://api.mistral.ai/v1", "MISTRAL_API_KEY", "open-mistral-nemo", "cheap", ""),
    ("together", "https://api.together.xyz/v1", "TOGETHER_API_KEY", "meta-llama/Llama-3.3-70B-Instruct-Turbo-Free", "premium", ""),
    ("ollama", "http://localhost:11434/v1", "OLLAMA_HOST", "qwen2.5-coder:7b", "cheap", ""),
    ("lmstudio", "http://localhost:1234/v1", "LMSTUDIO_HOST", "local-model", "cheap", ""),
    ("vllm", "http://localhost:8000/v1", "VLLM_HOST", "local-model", "cheap", ""),
    ("llamacpp", "http://localhost:8080/v1", "LLAMACPP_HOST", "local-model", "cheap", ""),
]


def available_endpoints() -> List[dict]:
    out = []
    for eid, base, env, model, cls, _ in ENDPOINTS:
        key = os.environ.get(env, "")
        usable = bool(key) or eid in ("ollama", "lmstudio", "vllm", "llamacpp")
        out.append({"id": eid, "base_url": base, "env": env, "model": model,
                    "class": cls, "usable": usable})
    return out


class LLMClient:
    def __init__(self, endpoint: Optional[str] = None, model: Optional[str] = None,
                 timeout: int = 120, cls: str = "cheap") -> None:
        self.timeout = timeout
        self.endpoint = endpoint
        self.model = model
        self.cls = cls

    def _resolve(self, cls: str) -> Optional[dict]:
        cands = available_endpoints()
        if self.endpoint:
            cands = [c for c in cands if c["id"] == self.endpoint] or cands
        pref = [c for c in cands if c["class"] == cls and c["usable"]]
        anyu = [c for c in cands if c["usable"]]
        pool = pref or anyu
        return pool[0] if pool else None

    def chat(self, messages: List[Dict[str, str]], *, cls: Optional[str] = None,
             temperature: float = 0.2, max_tokens: int = 2048,
             response_format: Optional[dict] = None) -> str:
        cls = cls or self.cls
        ep = self._resolve(cls)
        if not ep:
            return self._offline(messages)
        model = self.model or ep["model"]
        key = os.environ.get(ep["env"], "")
        url = ep["base_url"].rstrip("/") + "/chat/completions"
        body: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if response_format:
            body["response_format"] = response_format
        data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(url, data=data, method="POST")
        req.add_header("Content-Type", "application/json")
        if key:
            req.add_header("Authorization", "Bearer " + key)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                payload = json.loads(resp.read().decode("utf-8", "replace"))
            return payload["choices"][0]["message"]["content"]
        except Exception:
            return self._offline(messages)

    def _offline(self, messages: List[Dict[str, str]]) -> str:
        """Deterministic offline stub: keeps the harness runnable with no keys."""
        last = messages[-1]["content"] if messages else ""
        return json.dumps({
            "offline": True,
            "note": "No LLM endpoint available; returning a deterministic stub.",
            "echo": last[:400],
        })


def chat(messages: List[Dict[str, str]], **kw) -> str:
    return LLMClient().chat(messages, **kw)
