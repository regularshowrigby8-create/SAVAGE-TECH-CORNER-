"""Provider-agnostic LLM layer (OpenAI-compatible, stdlib-only)."""
from .client import LLMClient, chat, available_endpoints
from .router import pick, route_stage

__all__ = ["LLMClient", "chat", "available_endpoints", "pick", "route_stage"]
