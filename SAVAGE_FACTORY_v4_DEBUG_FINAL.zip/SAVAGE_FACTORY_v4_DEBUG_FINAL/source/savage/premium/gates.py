"""L8 — Deterministic Gates.

The ONLY thing allowed to certify a release.  No model may override these.
Checks: files exist, code compiles, tests pass, no hollow code, no secrets,
no UTF-16LE-hidden strings.
"""
from __future__ import annotations

import re
import os
import subprocess
from pathlib import Path
from typing import List

from .scaffold import Scaffold

_SECRET = re.compile(
    r"(AKIA[0-9A-Z]{16}|(?:ghp|github_pat)_[A-Za-z0-9_]{20,}|"
    r"sk-[A-Za-z0-9]{20,}|AIza[0-9A-Za-z_-]{20,}|xox[baprs]-[A-Za-z0-9-]{10,}|"
    r"-----BEGIN " + r"(?:RSA |EC |OPENSSH )?PRIVATE " + r"KEY-----)"
)
# Assembled from fragments so this detector never trips over its own source.
_HOLLOW = ("raise NotImplemented" + "Error",
           "return True  # " + "gate",
           "pass  # " + "TODO")


def _run(cmd: List[str], cwd: Path, timeout: int = 120) -> tuple:
    try:
        allowed = {"PATH", "HOME", "LANG", "LC_ALL", "TMPDIR", "SYSTEMROOT", "WINDIR"}
        env = {k: v for k, v in os.environ.items() if k in allowed}
        env.setdefault("HOME", str(cwd))
        env.setdefault("LANG", "C.UTF-8")
        p = subprocess.run(cmd, cwd=str(cwd), env=env, capture_output=True,
                           text=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except FileNotFoundError:
        return 127, "not found: " + " ".join(cmd)
    except subprocess.TimeoutExpired:
        return 124, "timeout"
    except Exception as exc:
        return 1, repr(exc)


def _scan_text(root: Path) -> List[str]:
    hits = []
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        try:
            raw = p.read_bytes()
        except Exception:
            continue
        for enc in ("utf-8", "utf-16-le", "utf-16-be"):
            try:
                text = raw.decode(enc, errors="ignore")
            except Exception:
                continue
            if _SECRET.search(text):
                hits.append("secret in " + str(p.relative_to(root)))
                break
        if p.suffix in (".py", ".js", ".ts", ".java"):
            try:
                text = raw.decode("utf-8", errors="ignore")
            except Exception:
                continue
            for pat in _HOLLOW:
                if pat in text:
                    hits.append("hollow in " + str(p.relative_to(root)) + ": " + pat)
    return hits


def run_gates(out_dir: Path, scaffold: Scaffold) -> dict:
    out_dir = Path(out_dir)
    checks = []
    failures = []

    # 1. files exist
    missing = [f for f in scaffold.files if not (out_dir / f).exists()]
    checks.append({"name": "files_exist", "ok": not missing})
    failures += ["missing:" + m for m in missing]

    # 2. build
    rc, log = _run(scaffold.build_cmd, out_dir)
    checks.append({"name": "build", "ok": rc == 0, "log": log[-400:]})
    if rc != 0:
        failures.append("build failed (rc=%d)" % rc)

    # 3. tests
    rc_t, log_t = _run(scaffold.test_cmd, out_dir)
    checks.append({"name": "tests", "ok": rc_t == 0, "log": log_t[-400:]})
    if rc_t != 0:
        failures.append("tests failed (rc=%d)" % rc_t)

    # 4. anti-hollow + secrets (UTF-16LE aware)
    scan = _scan_text(out_dir)
    checks.append({"name": "anti_deception", "ok": not scan})
    failures += scan

    return {
        "passed": all(c["ok"] for c in checks),
        "checks": checks,
        "failures": failures,
        "gate_tier": "verified",
    }


def run_repository_gates(root: Path) -> dict:
    """Audit the actual repository tree and fail closed on missing evidence."""
    root = Path(root).resolve()
    checks, failures = [], []
    if not root.exists() or not root.is_dir():
        return {"passed": False, "checks": [{"name": "root", "ok": False}],
                "failures": ["repository root missing"], "gate_tier": "verified"}
    source = [p for p in root.rglob("*") if p.is_file() and
              ".git" not in p.parts and "node_modules" not in p.parts and
              "__pycache__" not in p.parts]
    checks.append({"name": "source_present", "ok": bool(source)})
    if not source:
        failures.append("repository has no source files")
    py_errors = []
    for p in source:
        if p.suffix == ".py":
            try:
                compile(p.read_text(encoding="utf-8", errors="strict"), str(p), "exec")
            except Exception as exc:
                py_errors.append(f"{p.relative_to(root)}: {exc}")
    checks.append({"name": "python_compile", "ok": not py_errors, "detail": py_errors[:5]})
    failures.extend("python:" + e for e in py_errors)
    scan = _scan_text(root)
    checks.append({"name": "anti_deception", "ok": not scan, "detail": scan[:20]})
    failures.extend(scan)
    hollow_ci = []
    for p in source:
        if ".github" in p.parts and p.suffix in (".yml", ".yaml"):
            text = p.read_text(encoding="utf-8", errors="ignore")
            if "continue-on-error: true" in text or "|| true" in text or "|| exit 0" in text:
                hollow_ci.append(str(p.relative_to(root)))
    checks.append({"name": "ci_fail_closed", "ok": not hollow_ci, "detail": hollow_ci})
    failures.extend("hollow CI:" + p for p in hollow_ci)
    return {"passed": not failures, "checks": checks, "failures": failures,
            "gate_tier": "verified"}
