"""L3 - Best-of-N Sampler.

Generate N candidate implementations in isolated workspaces.  With no model, the
scaffold's own files are the candidate (still a real, runnable artifact).  When
an ``isolate_root`` is supplied each candidate is materialised in its own private
git worktree (or isolated directory) via :mod:`savage.premium.worktree`.
"""
from __future__ import annotations

import dataclasses
import json
import hashlib
import shutil
from pathlib import Path
from typing import List, Optional

from ..llm.client import LLMClient
from .scaffold import Scaffold
from . import worktree as _worktree


@dataclasses.dataclass
class Candidate:
    idx: int
    path: Path
    files: List[str]
    diff: str = ""
    build_log: str = ""
    score: float = 0.0
    isolation: str = "dir"


def _write_scaffold(scaffold: Scaffold, dest: Path) -> List[str]:
    dest.mkdir(parents=True, exist_ok=True)
    written = []
    for rel, content in scaffold.files.items():
        p = dest / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content)
        written.append(rel)
    return written


def sample(spec: dict, scaffold: Scaffold, gold: list,
           client: Optional[LLMClient] = None, n: int = 8,
           out_dir: Optional[Path] = None,
           isolate_root: Optional[Path] = None) -> List[Candidate]:
    client = client or LLMClient()
    out_dir = Path(out_dir or ".")
    cands: List[Candidate] = []
    for i in range(max(1, n)):
        name = "candidate_%02d" % i
        if isolate_root is not None:
            info = _worktree.isolate(Path(out_dir), name, Path(isolate_root))
            cdir = Path(info["path"])
            mode = str(info["mode"])
        else:
            cdir = out_dir / name
            if cdir.exists():
                shutil.rmtree(cdir)
            mode = "dir"
        files = _write_scaffold(scaffold, cdir)
        # A candidate only counts as a variant when the model supplies a real,
        # validated file patch. A prose label is not a code change.
        suggestion = ""
        try:
            suggestion = client.chat(
                [{"role": "system", "content":
                  "Return JSON only: {\"file\":...,\"find\":...,\"replace\":...}. "
                  "The patch must be minimal and preserve tests."},
                 {"role": "user", "content":
                  "Spec: " + json.dumps(spec)[:800] +
                  "\nScaffold files: " + ", ".join(files)}],
                cls="cheap", temperature=0.0, max_tokens=256)
        except Exception:
            suggestion = ""
        changed = False
        try:
            start = suggestion.find("{")
            obj = json.loads(suggestion[start:]) if start >= 0 else {}
            f, find, repl = obj.get("file"), obj.get("find"), obj.get("replace")
            if f and find is not None and repl is not None:
                candidate_root = cdir.resolve()
                target = (candidate_root / f).resolve()
                if not Path(f).is_absolute() and target.is_relative_to(candidate_root) and target.is_file():
                    text = target.read_text(encoding="utf-8")
                    if find in text:
                        target.write_text(text.replace(find, repl, 1), encoding="utf-8")
                        changed = True
        except Exception:
            changed = False
        digest = hashlib.sha256()
        for rel in sorted(files):
            digest.update(rel.encode()); digest.update((cdir / rel).read_bytes())
        diff = "candidate %d content_sha256=%s variant=%s" % (i, digest.hexdigest(), changed)
        cands.append(Candidate(idx=i, path=cdir, files=files, diff=diff, isolation=mode))
    return cands
