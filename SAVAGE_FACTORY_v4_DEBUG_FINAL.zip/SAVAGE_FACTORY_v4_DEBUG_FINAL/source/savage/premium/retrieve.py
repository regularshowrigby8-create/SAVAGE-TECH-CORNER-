"""L7 — Golden-example retrieval.

Before generating, retrieve the closest proven example from factory/golden/.
Matching is a cheap lexical overlap score (no embeddings required), which keeps
the harness dependency-free while still grounding the model in real examples.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import List

from ..config import GOLDEN_DIR

_WORD = re.compile(r"[a-z0-9]+")


def _tokens(text: str) -> set:
    return set(_WORD.findall((text or "").lower()))


def load_golden() -> List[dict]:
    out = []
    if GOLDEN_DIR.exists():
        for p in sorted(GOLDEN_DIR.glob("*.json")):
            try:
                out.append(json.loads(p.read_text()))
            except Exception:
                continue
    return out


def retrieve(query: str, k: int = 2) -> List[dict]:
    q = _tokens(query)
    scored = []
    for g in load_golden():
        text = " ".join(str(g.get(k, "")) for k in ("title", "tags", "prompt", "summary"))
        overlap = len(q & _tokens(text))
        if overlap:
            scored.append((overlap, g))
    scored.sort(key=lambda x: -x[0])
    return [g for _, g in scored[:k]]


def ensure_seed_golden() -> None:
    """Seed a couple of golden examples so retrieval is never empty."""
    GOLDEN_DIR.mkdir(parents=True, exist_ok=True)
    seeds = [
        {
            "id": "golden-html-game",
            "title": "HTML5 canvas game",
            "tags": ["game", "canvas", "html", "browser", "arcade", "racing"],
            "prompt": "build a browser game",
            "summary": "Single-file HTML5 canvas game with requestAnimationFrame loop, "
                       "keyboard input, collision, score, and a deterministic test hook.",
        },
        {
            "id": "golden-python-cli",
            "title": "Python CLI tool",
            "tags": ["cli", "python", "argparse", "tool"],
            "prompt": "build a command line tool",
            "summary": "argparse CLI with --help, a pure function core, and pytest tests.",
        },
        {
            "id": "golden-rest-api",
            "title": "REST API service",
            "tags": ["api", "rest", "http", "server", "json"],
            "prompt": "build a rest api",
            "summary": "Stdlib http.server JSON API with routes, validation, and tests.",
        },
    ]
    for s in seeds:
        p = GOLDEN_DIR / (s["id"] + ".json")
        if not p.exists():
            p.write_text(json.dumps(s, indent=2))
