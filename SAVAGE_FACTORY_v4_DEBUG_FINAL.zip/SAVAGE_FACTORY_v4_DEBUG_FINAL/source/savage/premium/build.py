"""The zero-human-intervention build pipeline.

    build("car racing game")

Runs: retrieve -> spec -> scaffold -> sample(N, isolated) -> rank -> repair ->
public gates -> SEALED holdout, and returns a BuildResult.  The only input is the
prompt.  A candidate ships only if the public deterministic gates AND the sealed
holdout both pass.
"""
from __future__ import annotations

import dataclasses
import hashlib
import json
import shutil
import time
from pathlib import Path
from typing import List, Optional

from ..config import OUT_ROOT, DEFAULT_N, DEFAULT_BUDGET_ROUNDS
from ..llm.client import LLMClient
from . import spec as _spec, scaffold as _scaffold, sampler as _sampler
from . import verifier as _verifier, repair as _repair, retrieve as _retrieve
from . import gates as _gates, holdout as _holdout


@dataclasses.dataclass
class BuildResult:
    prompt: str
    spec: dict
    scaffold: str
    out_dir: str
    candidates: int
    best_score: float
    gates: dict
    sealed: dict
    isolation: str
    repair_history: list
    verdict: str
    elapsed_s: float
    artifact: str = ""

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)


def _slug(text: str) -> str:
    keep = [c if c.isalnum() else "-" for c in text.lower()]
    s = "".join(keep)
    while "--" in s:
        s = s.replace("--", "-")
    return (s.strip("-") or "build")[:48]


class Harness:
    """Facade over the 10 layers."""

    def __init__(self, client: Optional[LLMClient] = None, n: int = DEFAULT_N,
                 budget_rounds: int = DEFAULT_BUDGET_ROUNDS) -> None:
        self.client = client or LLMClient()
        self.n = n
        self.budget_rounds = budget_rounds

    def run(self, prompt: str, out_root: Optional[Path] = None) -> BuildResult:
        t0 = time.time()
        _retrieve.ensure_seed_golden()
        gold = _retrieve.retrieve(prompt, k=2)
        spec = _spec.amplify(prompt, client=self.client)
        scaf = _scaffold.select(spec)
        out_root = Path(out_root or OUT_ROOT) / (_slug(prompt) + "-" + str(int(t0)))
        out_root.mkdir(parents=True, exist_ok=True)
        # L10: isolate every candidate in its own private workspace.
        cands = _sampler.sample(spec, scaf, gold, client=self.client,
                                n=self.n, out_dir=out_root,
                                isolate_root=out_root / ".worktrees")
        isolation = cands[0].isolation if cands else "dir"
        try:
            ranked = _verifier.rank(cands, spec, scaf, client=self.client)
            if not ranked:
                raise RuntimeError("no candidates generated")
            best, gates, history = _repair.repair_until_green(
                ranked, spec, scaf, out_root, client=self.client,
                max_rounds=self.budget_rounds)
            # L9: sealed holdout - the generator never saw these checks.
            sealed_manifest = _holdout.seal(spec, scaf)
            sealed = _holdout.run_sealed(best.path, scaf, sealed_manifest)
            gates["sealed"] = sealed
            gates["passed"] = bool(gates.get("passed")) and bool(sealed["passed"])
            # A baseline scaffold is not a product-specific implementation.
            baseline = hashlib.sha256()
            actual = hashlib.sha256()
            for rel in sorted(scaf.files):
                baseline.update(rel.encode()); baseline.update(scaf.files[rel].encode())
                actual.update(rel.encode()); actual.update((best.path / rel).read_bytes())
            unchanged = baseline.digest() == actual.digest()
            gates["template_only"] = unchanged
            if unchanged:
                gates["passed"] = False
            # Promote the best candidate to the final artifact dir.
            final = out_root / "artifact"
            if final.exists():
                shutil.rmtree(final)
            shutil.copytree(best.path, final)
            verdict = "TEMPLATE-ONLY" if unchanged else ("SHIP" if gates["passed"] else "FIX-FIRST")
            (out_root / "verdict.json").write_text(json.dumps(
                {"verdict": verdict, "gates": gates, "sealed": sealed, "history": history},
                indent=2))
            return BuildResult(
                prompt=prompt, spec=spec, scaffold=scaf.name, out_dir=str(out_root),
                candidates=len(cands), best_score=best.score, gates=gates, sealed=sealed,
                isolation=isolation, repair_history=history, verdict=verdict,
                elapsed_s=round(time.time() - t0, 3), artifact=str(final))
        finally:
            for candidate in cands:
                try:
                    _worktree.release(candidate.path)
                except Exception:
                    pass


def build(prompt: str, *, n: int = DEFAULT_N, budget_rounds: int = DEFAULT_BUDGET_ROUNDS,
          out_root: Optional[Path] = None, client: Optional[LLMClient] = None) -> BuildResult:
    return Harness(client=client, n=n, budget_rounds=budget_rounds).run(prompt, out_root=out_root)
