"""The 10-layer premium harness.

A low-end model produces raw output.  The harness turns that raw output into the
*best* output that model is capable of, and then only ships it if deterministic
gates say it is real.  The ceiling is honest: the harness cannot make a 7B model
write a AAA 3D engine, but it will make it write a correct, tested, packaged
artifact of the kind it *can* write - and it will refuse to ship a fake.

Layers: L1 spec, L2 scaffold, L3 sampler, L4 verifier, L5 repair, L6 decode,
L7 retrieve, L8 gates, L9 sealed holdout, L10 worktree isolation.
"""
from __future__ import annotations

from .build import build, BuildResult, Harness
from . import holdout, worktree

__all__ = ["build", "BuildResult", "Harness", "holdout", "worktree"]
