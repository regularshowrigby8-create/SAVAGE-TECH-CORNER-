"""L4 — Verifier / Ensemble.

Rank candidates deterministically first (build + tests + anti-hollow scan), then
optionally ask a DIFFERENT model class to break ties.  The generating model and
the verifying model are never the same class.
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import List, Optional

from ..llm.client import LLMClient
from .scaffold import Scaffold
from .sampler import Candidate

# Assembled from fragments so this detector never trips over its own source.
_HOLLOW = ("return " + "True",
           "NotImplemented" + "Error",
           "raise NotImplemented" + "Error",
           "pass  # " + "TODO")


def _run(cmd: List[str], cwd: Path, timeout: int = 120) -> tuple:
    try:
        allowed = {"PATH", "HOME", "LANG", "LC_ALL", "TMPDIR", "SYSTEMROOT", "WINDIR"}
        env = {k: v for k, v in os.environ.items() if k in allowed}
        env.setdefault("HOME", str(cwd))
        env.setdefault("LANG", "C.UTF-8")
        p = subprocess.run(cmd, cwd=str(cwd), env=env, capture_output=True,
                           text=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except FileNotFoundError:
        return 127, "not found: " + " ".join(cmd)
    except subprocess.TimeoutExpired:
        return 124, "timeout"
    except Exception as exc:
        return 1, repr(exc)


def _scan_hollow(root: Path) -> List[str]:
    hits = []
    for p in root.rglob("*"):
        if p.is_file() and p.suffix in (".py", ".js", ".ts", ".java"):
            try:
                text = p.read_text(errors="ignore")
            except Exception:
                continue
            for pat in _HOLLOW:
                if pat in text:
                    hits.append(str(p.relative_to(root)) + ": " + pat)
    return hits


def score_candidate(c: Candidate, scaffold: Scaffold) -> float:
    score = 0.0
    rc, log = _run(scaffold.build_cmd, c.path)
    c.build_log = log
    if rc == 0:
        score += 2.0
    rc_t, log_t = _run(scaffold.test_cmd, c.path)
    if rc_t == 0:
        score += 3.0
    hollow = _scan_hollow(c.path)
    if not hollow:
        score += 2.0
    score += 0.1 * len(c.files)
    c.score = score
    return score


def rank(candidates: List[Candidate], spec: dict, scaffold: Scaffold,
         client: Optional[LLMClient] = None) -> List[Candidate]:
    for c in candidates:
        score_candidate(c, scaffold)
    candidates.sort(key=lambda c: -c.score)
    # Optional adversarial tie-break between the top two by a premium model.
    if client and len(candidates) >= 2 and abs(candidates[0].score - candidates[1].score) < 0.01:
        try:
            verdict = client.chat(
                [{"role": "system", "content":
                  "You are an adversarial verifier. Reply with the number 0 or 1 only."},
                 {"role": "user", "content":
                  "Which candidate is more likely correct?\n0: " + candidates[0].diff +
                  "\n1: " + candidates[1].diff}],
                cls="premium", temperature=0.0, max_tokens=4)
            if "1" in verdict and "0" not in verdict:
                candidates[0], candidates[1] = candidates[1], candidates[0]
        except Exception:
            pass
    return candidates
