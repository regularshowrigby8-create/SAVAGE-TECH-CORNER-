"""L5 — Self-Repair Loop.

Take the best candidate, run the deterministic gates, and if they fail, feed the
failure log back to the model and try again — up to max_rounds.  This is what
turns "raw output" into "best output the model can produce".
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import List, Optional

from ..llm.client import LLMClient
from .scaffold import Scaffold
from .sampler import Candidate
from . import gates as _gates


def repair_until_green(ranked: List[Candidate], spec: dict, scaffold: Scaffold,
                       out_dir: Path, client: Optional[LLMClient] = None,
                       max_rounds: int = 4) -> tuple:
    client = client or LLMClient()
    best = ranked[0]
    history = []
    result = _gates.run_gates(best.path, scaffold)
    for rnd in range(max_rounds):
        history.append({"round": rnd, "passed": result["passed"],
                        "failures": result.get("failures", [])})
        if result["passed"]:
            break
        # Ask the model for a fix; if offline, apply deterministic auto-fixes.
        fix = ""
        try:
            fix = client.chat(
                [{"role": "system", "content":
                  "You are a careful engineer. Propose the minimal fix as JSON "
                  '{"file": "...", "find": "...", "replace": "..."} only.'},
                 {"role": "user", "content":
                  "Spec: " + json.dumps(spec)[:600] +
                  "\nFailures: " + json.dumps(result.get("failures", []))[:600]}],
                cls="cheap", temperature=0.0, max_tokens=256)
        except Exception:
            fix = ""
        applied = _apply_fix(best.path, fix)
        if not applied:
            _auto_fix(best.path, result, scaffold)
        result = _gates.run_gates(best.path, scaffold)
    return best, result, history


def _apply_fix(root: Path, fix_text: str) -> bool:
    if not fix_text:
        return False
    try:
        start = fix_text.find("{")
        obj = json.loads(fix_text[start:]) if start != -1 else {}
    except Exception:
        return False
    f = obj.get("file")
    find = obj.get("find")
    repl = obj.get("replace")
    if not (f and find is not None and repl is not None):
        return False
    try:
        candidate_root = Path(root).resolve()
        p = (candidate_root / f).resolve()
        if Path(f).is_absolute() or not p.is_relative_to(candidate_root):
            return False
    except (OSError, ValueError):
        return False
    if not p.is_file():
        return False
    text = p.read_text(encoding="utf-8")
    if find not in text:
        return False
    p.write_text(text.replace(find, repl, 1), encoding="utf-8")
    return True


def _auto_fix(root: Path, result: dict, scaffold: Scaffold) -> None:
    """Deterministic fixes for the common, mechanical failures."""
    for fail in result.get("failures", []):
        if "missing" in fail:
            rel = fail.split("missing:", 1)[-1].strip()
            p = root / rel
            # Missing files are evidence of a broken candidate, not permission to
            # manufacture an empty placeholder that makes files_exist green.
            continue
