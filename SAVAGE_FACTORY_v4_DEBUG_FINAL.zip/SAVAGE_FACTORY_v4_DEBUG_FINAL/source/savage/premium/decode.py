"""L6 — Constrained decoding.

Force the model to emit valid JSON by (a) asking for a JSON response format,
(b) re-asking with an explicit GBNF grammar hint, and (c) extracting + repairing
the first balanced JSON object from whatever comes back.
"""
from __future__ import annotations

import json
import re
from typing import Any, Optional

SPEC_GBNF = r"""
root   ::= object
object ::= "{" ws pair (ws "," ws pair)* ws "}" | "{" ws "}"
pair   ::= string ws ":" ws value
value  ::= string | number | object | array | "true" | "false" | "null"
array  ::= "[" ws (value (ws "," ws value)*)? ws "]"
string ::= "\"" ( [^"\\] | "\\" ["\\/bfnrt] )* "\""
number ::= "-"? ("0" | [1-9] [0-9]*) ("." [0-9]+)? ([eE] [-+]? [0-9]+)?
ws     ::= [ \t\n\r]*
"""


def extract_json(text: str) -> Optional[Any]:
    """Pull the first balanced JSON value out of arbitrary model text."""
    if not text:
        return None
    text = text.strip()
    # strip markdown fences
    fence = re.search(r"```(?:json)?\s*(.*?)```", text, re.DOTALL)
    if fence:
        text = fence.group(1).strip()
    try:
        return json.loads(text)
    except Exception:
        pass
    # scan for the first balanced { } or [ ]
    for opener, closer in (("{", "}"), ("[", "]")):
        start = text.find(opener)
        while start != -1:
            depth = 0
            in_str = False
            esc = False
            for i in range(start, len(text)):
                ch = text[i]
                if in_str:
                    if esc:
                        esc = False
                    elif ch == "\\":
                        esc = True
                    elif ch == '"':
                        in_str = False
                    continue
                if ch == '"':
                    in_str = True
                elif ch == opener:
                    depth += 1
                elif ch == closer:
                    depth -= 1
                    if depth == 0:
                        chunk = text[start:i + 1]
                        try:
                            return json.loads(chunk)
                        except Exception:
                            break
            start = text.find(opener, start + 1)
    return None


def validate_spec(obj: Any) -> tuple:
    """Minimal, dependency-free validation against the spec contract."""
    if not isinstance(obj, dict):
        return False, ["spec is not an object"]
    errs = []
    for key in ("goal", "non_goals", "acceptance_tests", "interfaces", "data_model", "risks"):
        if key not in obj:
            errs.append("missing: " + key)
    tests = obj.get("acceptance_tests")
    if not isinstance(tests, list) or len(tests) < 3:
        errs.append("need >= 3 acceptance_tests")
    else:
        for t in tests:
            if not isinstance(t, dict) or "name" not in t or "check" not in t:
                errs.append("each test needs name+check")
                break
    if not isinstance(obj.get("goal", ""), str) or len(obj.get("goal", "")) < 8:
        errs.append("goal too short")
    return (not errs), errs


def repair_json(text: str) -> Optional[Any]:
    """Best-effort repair of common JSON mistakes."""
    obj = extract_json(text)
    if obj is not None:
        return obj
    if not text:
        return None
    fixed = text.strip()
    fixed = fixed.replace("True", "true").replace("False", "false").replace("None", "null")
    fixed = re.sub(r",(\s*[}\]])", r"\1", fixed)  # trailing commas
    return extract_json(fixed)
