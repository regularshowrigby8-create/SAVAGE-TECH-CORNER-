"""L2 — Scaffold selection.

Pick the right project skeleton for the spec, and (importantly) make the offline
path produce a *real, runnable* minimal project so the harness works with no
model at all.
"""
from __future__ import annotations

import dataclasses
import re
from typing import Dict, List


@dataclasses.dataclass
class Scaffold:
    name: str
    language: str
    files: Dict[str, str]
    build_cmd: List[str]
    test_cmd: List[str]
    run_hint: str = ""


_KEYWORDS = {
    "html_game": ["game", "canvas", "arcade", "racing", "platformer", "browser game", "shooter", "puzzle"],
    "android": ["android", "apk", "mobile app", "gradle"],
    "rest_api": ["api", "rest", "http", "server", "endpoint", "webhook"],
    "python_cli": ["cli", "command line", "script", "tool", "automation"],
    "web_app": ["website", "web app", "react", "frontend", "landing page", "dashboard"],
}


def _classify(spec: dict) -> str:
    blob = " ".join(str(spec.get(k, "")) for k in ("goal", "data_model")).lower()
    blob += " " + " ".join(spec.get("interfaces", []) or [])
    for kind, words in _KEYWORDS.items():
        if any(w in blob for w in words):
            return kind
    return "python_cli"


def _safe(spec: dict, default: str = "a tool", n: int = 60) -> str:
    """A goal string that is always safe to drop inside a quoted literal."""
    raw = str(spec.get("goal", default) or default)
    raw = re.sub(r"[\"'\\\r\n\t]+", " ", raw)
    raw = re.sub(r"\s+", " ", raw).strip()
    return raw[:n] or default


def _html_game(spec: dict) -> Scaffold:
    title = re.sub(r"[^A-Za-z0-9 ]", "", str(spec.get("goal", "Game")))[:40] or "Game"
    index = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>__TITLE__</title>
<style>
  html,body{margin:0;height:100%;background:#0b0f17;color:#e6edf3;
            font-family:system-ui,Segoe UI,Roboto,sans-serif}
  #wrap{display:flex;flex-direction:column;align-items:center;gap:8px;padding:12px}
  canvas{background:#111827;border-radius:12px;box-shadow:0 8px 40px #0008}
  .hud{font-variant-numeric:tabular-nums;opacity:.9}
</style>
</head>
<body>
<div id="wrap">
  <div class="hud">Score: <span id="score">0</span></div>
  <canvas id="c" width="640" height="480"></canvas>
  <div class="hud">Arrows / WASD to steer</div>
</div>
<script src="game.js"></script>
</body>
</html>
""".replace("__TITLE__", title)
    game = """// __TITLE__ — deterministic, testable HTML5 canvas game.
(function (global) {
  "use strict";
  function createState() {
    return { player: { x: 320, y: 400, vx: 0 }, score: 0, t: 0,
             obstacles: [{ x: 200, y: 0, w: 60, h: 60, vy: 3 }] };
  }
  function step(s, input, dt) {
    input = input || {};
    var ax = 0;
    if (input.left) ax -= 1;
    if (input.right) ax += 1;
    s.player.vx = ax * 5;
    s.player.x = Math.max(0, Math.min(640 - 24, s.player.x + s.player.vx));
    s.t += dt;
    for (var i = 0; i < s.obstacles.length; i++) {
      var o = s.obstacles[i];
      o.y += o.vy * dt * 60;
      if (o.y > 480) { o.y = -60; o.x = Math.random() * (640 - o.w); s.score += 1; }
      if (Math.abs(o.x - s.player.x) < 24 && Math.abs(o.y - s.player.y) < 24) {
        s.score = 0; o.y = -60;
      }
    }
    return s;
  }
  function render(ctx, s) {
    ctx.clearRect(0, 0, 640, 480);
    ctx.fillStyle = "#38bdf8";
    ctx.fillRect(s.player.x, s.player.y, 24, 24);
    ctx.fillStyle = "#f87171";
    s.obstacles.forEach(function (o) { ctx.fillRect(o.x, o.y, o.w, o.h); });
  }
  var api = { createState: createState, step: step, render: render };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  global.SavageGame = api;
})(typeof window !== "undefined" ? window : globalThis);
""".replace("__TITLE__", title)
    test = """// Deterministic test hook for the game core (node test.js).
var g = require("./game.js");
var s = g.createState();
for (var i = 0; i < 120; i++) g.step(s, { left: i % 2 === 0 }, 1 / 60);
if (typeof s.score !== "number") { console.error("FAIL: score missing"); process.exit(1); }
console.log("PASS: game core ran 120 frames, score=" + s.score);
"""
    return Scaffold(
        name="html_game", language="javascript",
        files={"index.html": index, "game.js": game, "test.js": test},
        build_cmd=["node", "--check", "game.js"],
        test_cmd=["node", "test.js"],
        run_hint="open index.html in a browser",
    )


def _python_cli(spec: dict) -> Scaffold:
    main = '''"""Generated CLI: __GOAL__"""
from __future__ import annotations

import argparse
import json


def core(text: str) -> dict:
    """Pure function core (easy to test)."""
    return {"length": len(text), "upper": text.upper(), "words": len(text.split())}


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="__GOAL__")
    p.add_argument("text", nargs="?", default="hello world")
    p.add_argument("--json", action="store_true")
    args = p.parse_args(argv)
    result = core(args.text)
    if args.json:
        print(json.dumps(result))
    else:
        print(result["upper"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
'''.replace("__GOAL__", _safe(spec, "a tool", 60))
    test = '''"""Tests for the generated CLI (stdlib unittest)."""
import unittest

from main import core


class CoreTests(unittest.TestCase):
    def test_length(self):
        self.assertEqual(core("abc")["length"], 3)

    def test_words(self):
        self.assertEqual(core("a b c")["words"], 3)

    def test_upper(self):
        self.assertEqual(core("hi")["upper"], "HI")


if __name__ == "__main__":
    unittest.main()
'''
    return Scaffold(
        name="python_cli", language="python",
        files={"main.py": main, "test_main.py": test},
        build_cmd=["python3", "-m", "py_compile", "main.py"],
        test_cmd=["python3", "test_main.py"],
        run_hint="python3 main.py --help",
    )


def _rest_api(spec: dict) -> Scaffold:
    server = '''"""Generated stdlib REST API: __GOAL__"""
from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, HTTPServer

STORE: dict = {}


class Handler(BaseHTTPRequestHandler):
    def _send(self, code: int, payload: dict) -> None:
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            return self._send(200, {"status": "ok"})
        if self.path == "/items":
            return self._send(200, {"items": list(STORE.values())})
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        if self.path != "/items":
            return self._send(404, {"error": "not found"})
        n = int(self.headers.get("Content-Length", 0))
        try:
            data = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            return self._send(400, {"error": "bad json"})
        if "name" not in data:
            return self._send(422, {"error": "name required"})
        key = str(len(STORE) + 1)
        STORE[key] = {"id": key, "name": data["name"]}
        return self._send(201, STORE[key])

    def log_message(self, *a):  # silence
        pass


def serve(port: int = 8000) -> None:
    HTTPServer(("127.0.0.1", port), Handler).serve_forever()


if __name__ == "__main__":
    serve()
'''.replace("__GOAL__", _safe(spec, "an api", 60))
    test = '''"""Tests for the generated REST API (stdlib unittest)."""
import json
import threading
import unittest
import urllib.request
from http.server import HTTPServer

from server import Handler


def _serve():
    srv = HTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1]


class ApiTests(unittest.TestCase):
    def test_health(self):
        srv, port = _serve()
        try:
            with urllib.request.urlopen("http://127.0.0.1:%d/health" % port) as r:
                self.assertEqual(json.loads(r.read())["status"], "ok")
        finally:
            srv.shutdown()

    def test_post_item(self):
        srv, port = _serve()
        try:
            req = urllib.request.Request(
                "http://127.0.0.1:%d/items" % port,
                data=json.dumps({"name": "widget"}).encode(),
                headers={"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(req) as r:
                self.assertEqual(r.status, 201)
        finally:
            srv.shutdown()


if __name__ == "__main__":
    unittest.main()
'''
    return Scaffold(
        name="rest_api", language="python",
        files={"server.py": server, "test_server.py": test},
        build_cmd=["python3", "-m", "py_compile", "server.py"],
        test_cmd=["python3", "test_server.py"],
        run_hint="python3 server.py",
    )


def _android(spec: dict) -> Scaffold:
    manifest = '''<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.savage.generated">
    <uses-permission android:name="android.permission.INTERNET"/>
    <application android:label="Generated" android:theme="@android:style/Theme.Material">
        <activity android:name=".MainActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
    </application>
</manifest>
'''
    activity = '''package com.savage.generated;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setText("__GOAL__");
        setContentView(tv);
    }
}
'''.replace("__GOAL__", _safe(spec, "Generated app", 60))
    validate = '''"""Static structural validation for the generated Android project.

This does NOT build an APK -- that needs the Android SDK and happens in the
isolated cell factory/spaces/apk-cli.  It proves the project is well-formed so
the harness can gate it honestly in a plain environment.
"""
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def check():
    problems = []
    manifest = ROOT / "AndroidManifest.xml"
    if not manifest.exists():
        problems.append("AndroidManifest.xml missing")
    else:
        try:
            ET.parse(str(manifest))
        except Exception as exc:
            problems.append("AndroidManifest.xml not well-formed: %r" % exc)
    java = ROOT / "src" / "com" / "savage" / "generated" / "MainActivity.java"
    if not java.exists():
        problems.append("MainActivity.java missing")
    else:
        src = java.read_text()
        if src.count("{") != src.count("}"):
            problems.append("MainActivity.java braces unbalanced")
        if "package com.savage.generated;" not in src:
            problems.append("MainActivity.java package declaration wrong")
        if "extends Activity" not in src:
            problems.append("MainActivity.java does not extend Activity")
    return problems


if __name__ == "__main__":
    probs = check()
    if probs:
        for p in probs:
            print("FAIL:", p)
        sys.exit(1)
    print("PASS: static Android validation (no SDK; real APK builds in factory/spaces/apk-cli)")
'''
    test = '''"""unittest wrapper around the static Android validator."""
import unittest

import validate


class AndroidTests(unittest.TestCase):
    def test_structure(self):
        self.assertEqual(validate.check(), [])


if __name__ == "__main__":
    unittest.main()
'''
    build = '''#!/usr/bin/env bash
# Try a real gradle build; otherwise fall back to honest static validation.
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
if command -v gradle >/dev/null 2>&1 && [ -f build.gradle ]; then
  echo "=== gradle assembleDebug ==="
  gradle --no-daemon assembleDebug
else
  echo "=== no Android SDK/gradle: static validation only ==="
  python3 validate.py
fi
'''
    return Scaffold(
        name="android", language="java",
        files={"AndroidManifest.xml": manifest,
               "src/com/savage/generated/MainActivity.java": activity,
               "validate.py": validate, "test_android.py": test, "build.sh": build},
        build_cmd=["bash", "build.sh"],
        test_cmd=["python3", "test_android.py"],
        run_hint="real APK build runs in factory/spaces/apk-cli",
    )


def _web_app(spec: dict) -> Scaffold:
    index = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>__TITLE__</title>
<style>
 body{margin:0;font-family:system-ui,Segoe UI,Roboto,sans-serif;background:#0b0f17;color:#e6edf3}
 header{padding:48px 24px;text-align:center}
 h1{font-size:2.4rem;margin:0 0 8px}
 main{max-width:820px;margin:0 auto;padding:24px}
 .card{background:#111827;border:1px solid #1f2937;border-radius:16px;padding:20px;margin:12px 0}
</style></head>
<body>
<header><h1>__TITLE__</h1><p>Generated web app.</p></header>
<main>
 <div class="card"><h2>Overview</h2><p>__GOAL__</p></div>
 <div class="card"><h2>Status</h2><p id="status">ready</p></div>
</main>
<script src="app.js"></script>
</body></html>
""".replace("__TITLE__", _safe(spec, "Web App", 40)).replace(
        "__GOAL__", _safe(spec, "a web app", 160))
    app = """// Generated web app logic.
(function () {
  "use strict";
  function init() {
    var el = document.getElementById("status");
    if (el) el.textContent = "ready";
  }
  if (typeof document !== "undefined") document.addEventListener("DOMContentLoaded", init);
  if (typeof module !== "undefined" && module.exports) module.exports = { init: init };
})();
"""
    test = """var app = require("./app.js");
if (typeof app.init !== "function") { console.error("FAIL"); process.exit(1); }
console.log("PASS: web app module loads");
"""
    return Scaffold(
        name="web_app", language="javascript",
        files={"index.html": index, "app.js": app, "test.js": test},
        build_cmd=["node", "--check", "app.js"],
        test_cmd=["node", "test.js"],
        run_hint="open index.html",
    )


_BUILDERS = {
    "html_game": _html_game,
    "python_cli": _python_cli,
    "rest_api": _rest_api,
    "android": _android,
    "web_app": _web_app,
}


def select(spec: dict) -> Scaffold:
    kind = _classify(spec)
    return _BUILDERS[kind](spec)
