"""L9 - Sealed / Holdout verification (the dark-factory pattern).

The generating model only ever sees the *public* spec.  A separate, sealed set of
checks is derived deterministically from the spec + scaffold and is applied only
at verification time.  A candidate earns SHIP only if it passes BOTH the public
deterministic gates AND the sealed holdout.  The grader is never the thing that
was told what to make.

This is deliberately dependency-free: the sealed set is a fixed list of
structural checks (entrypoint, anti-hollow, secrets, compile, tests, determinism,
test presence, size bounds) evaluated on the finished candidate directory.
"""
from __future__ import annotations

import hashlib
import json
import re
import os
import subprocess
from pathlib import Path
from typing import Dict, List, Tuple

# Assembled from fragments so this detector never trips over its own source.
_HOLLOW = ("raise NotImplemented" + "Error",
           "pass  # " + "TODO",
           "return True  # " + "gate")
_SECRET = re.compile(
    r"(AKIA[0-9A-Z]{16}|(?:ghp|github_pat)_[A-Za-z0-9_]{20,}|"
    r"sk-[A-Za-z0-9]{20,}|AIza[0-9A-Za-z_-]{20,}|xox[baprs]-[A-Za-z0-9-]{10,}|"
    r"-----BEGIN " + r"(?:RSA |EC |OPENSSH )?PRIVATE " + r"KEY-----)"
)

CODE_SUFFIXES = (".py", ".js", ".ts", ".java", ".html", ".sh")


def _run(cmd: List[str], cwd: Path, timeout: int = 120) -> Tuple[int, str]:
    try:
        allowed = {"PATH", "HOME", "LANG", "LC_ALL", "TMPDIR", "SYSTEMROOT", "WINDIR"}
        env = {k: v for k, v in os.environ.items() if k in allowed}
        env.setdefault("HOME", str(cwd))
        env.setdefault("LANG", "C.UTF-8")
        p = subprocess.run(cmd, cwd=str(cwd), env=env, capture_output=True,
                           text=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except FileNotFoundError:
        return 127, "not found: " + " ".join(cmd)
    except subprocess.TimeoutExpired:
        return 124, "timeout"
    except Exception as exc:
        return 1, repr(exc)


def seal(spec: dict, scaffold) -> dict:
    """Derive the sealed check set.  Deterministic: same spec -> same seal."""
    blob = json.dumps({"goal": spec.get("goal", ""), "files": sorted(scaffold.files)},
                      sort_keys=True)
    return {
        "sealed_id": hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16],
        "scaffold": scaffold.name,
        "checks": [
            "entrypoint_present", "no_hollow", "no_secrets", "compiles",
            "tests_pass", "tests_deterministic", "has_tests", "size_bounds",
        ],
    }


def _iter_code(root: Path):
    for p in root.rglob("*"):
        if p.is_file() and p.suffix in CODE_SUFFIXES:
            yield p


def run_sealed(candidate_dir: Path, scaffold, sealed: dict) -> dict:
    """Run the sealed checks against a finished candidate directory."""
    candidate_dir = Path(candidate_dir)
    checks: List[dict] = []
    failures: List[str] = []

    def add(name: str, ok: bool, detail: str = "") -> None:
        checks.append({"name": name, "ok": bool(ok), "detail": detail[:200]})
        if not ok:
            failures.append(name + ((":" + detail[:80]) if detail else ""))

    # 1. entrypoint present
    entry = sorted(scaffold.files)[0] if scaffold.files else ""
    add("sealed.entrypoint_present", bool(entry) and (candidate_dir / entry).exists(), entry)

    # 2. anti-hollow
    hollow = []
    for p in _iter_code(candidate_dir):
        text = p.read_text(errors="ignore")
        for pat in _HOLLOW:
            if pat in text:
                hollow.append(str(p.relative_to(candidate_dir)))
                break
    add("sealed.no_hollow", not hollow, ",".join(hollow[:3]))

    # 3. no secrets (UTF-16LE aware)
    leaks = []
    for p in candidate_dir.rglob("*"):
        if not p.is_file():
            continue
        try:
            raw = p.read_bytes()
        except Exception:
            continue
        for enc in ("utf-8", "utf-16-le", "utf-16-be"):
            if _SECRET.search(raw.decode(enc, "ignore")):
                leaks.append(str(p.relative_to(candidate_dir)))
                break
    add("sealed.no_secrets", not leaks, ",".join(leaks[:3]))

    # 4. compiles
    rc, log = _run(scaffold.build_cmd, candidate_dir)
    add("sealed.compiles", rc == 0, log[-160:])

    # 5. tests pass
    rc_t, log_t = _run(scaffold.test_cmd, candidate_dir)
    add("sealed.tests_pass", rc_t == 0, log_t[-160:])

    # 6. tests deterministic (run a second time; the exit code must match)
    rc_t2, _ = _run(scaffold.test_cmd, candidate_dir)
    add("sealed.tests_deterministic", rc_t == rc_t2, "rc1=%d rc2=%d" % (rc_t, rc_t2))

    # 7. has tests
    has_test = any(re.search(r"(^|[/\\])test", str(p.relative_to(candidate_dir)))
                   for p in _iter_code(candidate_dir))
    add("sealed.has_tests", has_test)

    # 8. size bounds
    n = sum(1 for f in candidate_dir.rglob("*") if f.is_file())
    add("sealed.size_bounds", 1 <= n <= 500, "files=%d" % n)

    return {"sealed_id": sealed.get("sealed_id"), "passed": not failures,
            "checks": checks, "failures": failures}
