"""L1 — Spec Amplifier.

Turn a one-line prompt into a typed, testable spec.  The model is asked for JSON
and the result is validated + repaired.  If no model is available (offline), a
deterministic spec is synthesised so the pipeline still runs.
"""
from __future__ import annotations

import json
from typing import Optional

from ..llm.client import LLMClient
from . import decode, retrieve

_SYSTEM = (
    "You are a senior software architect. Turn the user request into a JSON spec "
    "with EXACTLY these keys: goal (string), non_goals (array of strings), "
    "acceptance_tests (array of >=3 objects with name and check), interfaces "
    "(array of strings), data_model (string), risks (array of strings). "
    "Every acceptance test's 'check' must be a concrete shell command or a "
    "boolean predicate. Reply with JSON only."
)


def _offline_spec(prompt: str) -> dict:
    p = prompt.strip() or "a small tool"
    return {
        "goal": "Build: " + p,
        "non_goals": ["No cloud dependencies", "No network unless required"],
        "acceptance_tests": [
            {"name": "builds", "check": "the project compiles with its build command"},
            {"name": "tests pass", "check": "the project's test command exits 0"},
            {"name": "no hollow code", "check": "no return True / NotImplementedError gates"},
        ],
        "interfaces": ["CLI or HTTP entrypoint", "pure core function"],
        "data_model": "minimal in-memory model",
        "risks": ["ambiguous requirements", "missing runtime deps"],
    }


def amplify(prompt: str, *, client: Optional[LLMClient] = None) -> dict:
    gold = retrieve.retrieve(prompt, k=2)
    gold_txt = json.dumps(gold, indent=2) if gold else "(none)"
    client = client or LLMClient()
    messages = [
        {"role": "system", "content": _SYSTEM},
        {"role": "user", "content":
            "Request: " + prompt + "\n\nProven examples:\n" + gold_txt +
            "\n\nGrammar (for reference):\n" + decode.SPEC_GBNF},
    ]
    raw = client.chat(messages, cls="premium", temperature=0.2,
                      response_format={"type": "json_object"})
    obj = decode.repair_json(raw)
    ok, errs = decode.validate_spec(obj)
    if not ok:
        # one repair round, then fall back
        raw2 = client.chat(
            messages + [{"role": "user", "content":
                         "That was invalid: " + "; ".join(errs) + ". Return valid JSON only."}],
            cls="premium", temperature=0.0,
            response_format={"type": "json_object"})
        obj = decode.repair_json(raw2)
        ok, _ = decode.validate_spec(obj)
    if not ok or (isinstance(obj, dict) and obj.get("offline")):
        return _offline_spec(prompt)
    obj["_source_prompt"] = prompt
    return obj
