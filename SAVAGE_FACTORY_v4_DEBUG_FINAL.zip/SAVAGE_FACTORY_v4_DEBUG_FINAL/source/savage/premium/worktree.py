"""L10 - Worktree isolation.

Every candidate is generated in its own private, disposable workspace so
candidates can never contaminate each other (the har / agentree / agent-worktree
pattern).  When the factory lives inside a git repository with at least one
commit we use a real ``git worktree``; otherwise we fall back to an isolated
directory under ``<root>/.worktrees/``.  Either way the contract is identical:
a private directory per candidate, released when the build is done.
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import Dict


def git_available() -> bool:
    return shutil.which("git") is not None


def _is_git_repo(path: Path) -> bool:
    try:
        p = subprocess.run(["git", "-C", str(path), "rev-parse", "--is-inside-work-tree"],
                           capture_output=True, text=True, timeout=10)
        if p.returncode != 0:
            return False
        head = subprocess.run(["git", "-C", str(path), "rev-parse", "--verify", "HEAD"],
                              capture_output=True, text=True, timeout=10)
        return head.returncode == 0
    except Exception:
        return False


def isolate(base_repo: Path, name: str, root: Path) -> Dict[str, object]:
    """Create a private workspace for one candidate.

    Returns ``{"path": Path, "mode": "worktree"|"dir"}``.  Never raises: on any
    failure it degrades to a plain isolated directory.
    """
    base_repo = Path(base_repo)
    root = Path(root)
    dest = root / ".worktrees" / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        release(dest)
    if git_available() and _is_git_repo(base_repo):
        try:
            p = subprocess.run(
                ["git", "-C", str(base_repo), "worktree", "add", "--detach", str(dest)],
                capture_output=True, text=True, timeout=60)
            if p.returncode == 0:
                return {"path": dest, "mode": "worktree"}
        except Exception:
            pass
    dest.mkdir(parents=True, exist_ok=True)
    return {"path": dest, "mode": "dir"}


def release(path: Path) -> None:
    """Tear down a workspace created by :func:`isolate`."""
    path = Path(path)
    if not path.exists():
        return
    # A linked worktree has a .git *file* (not a directory) pointing at the parent.
    if (path / ".git").is_file():
        try:
            result = subprocess.run(["git", "-C", str(path), "worktree", "remove", "--force", str(path)],
                                    capture_output=True, text=True, timeout=60)
            if result.returncode == 0 and not path.exists():
                return
        except Exception:
            pass
    if path.exists():
        shutil.rmtree(path, ignore_errors=False)
