"""savage — the auto-run premium factory.

`import savage` IS the installation.  On import it idempotently ensures the
factory is materialised, dependencies are present, the MCP fleet is registered
and the environment is sane.  It is non-fatal: if anything fails it records the
reason and continues, so importing can never break a host program.

Public surface:
    ensure_ready(force=False) -> dict      # idempotent bootstrap
    Harness                                # the 8-layer facade
    build(prompt, **kw) -> BuildResult     # the zero-human pipeline
"""
from __future__ import annotations

import os

from .bootstrap import ensure_ready

__version__ = "3.0.0"
__all__ = ["ensure_ready", "build", "Harness", "__version__"]


def __getattr__(name):  # lazy so `import savage` stays cheap
    if name in ("build", "Harness"):
        from .premium import Harness, build
        return {"build": build, "Harness": Harness}[name]
    raise AttributeError(name)


# Auto-run on import (marker-gated, budget-capped, non-fatal).
if os.environ.get("SAVAGE_AUTORUN", "1") == "1":
    try:
        ensure_ready()
    except Exception as _exc:  # never break the host
        os.environ.setdefault("SAVAGE_BOOTSTRAP_ERROR", repr(_exc))
