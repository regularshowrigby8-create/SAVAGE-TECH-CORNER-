"""A minimal stdio JSON-RPC 2.0 MCP client (stdlib only).

Speaks the Model Context Protocol over a subprocess' stdin/stdout.  Includes the
resilience the fleet needs: it retries on the notorious -32000 EOF error and
re-spawns a dead server once.
"""
from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional


class MCPError(RuntimeError):
    pass


class MCPClient:
    def __init__(self, command: List[str], env: Optional[dict] = None) -> None:
        self.command = command
        self.env = {**os.environ, **(env or {})}
        self.proc: Optional[subprocess.Popen] = None
        self._id = 0

    def _spawn(self) -> None:
        self.proc = subprocess.Popen(
            self.command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, env=self.env, text=True, bufsize=1)

    def _rpc(self, method: str, params: Optional[dict] = None) -> dict:
        if self.proc is None or self.proc.poll() is not None:
            self._spawn()
        self._id += 1
        msg = {"jsonrpc": "2.0", "id": self._id, "method": method, "params": params or {}}
        assert self.proc and self.proc.stdin
        self.proc.stdin.write(json.dumps(msg) + "\n")
        self.proc.stdin.flush()
        assert self.proc.stdout
        line = self.proc.stdout.readline()
        if not line:
            raise MCPError("-32000 EOF")
        return json.loads(line)

    def call(self, method: str, params: Optional[dict] = None, retries: int = 2) -> dict:
        last = None
        for attempt in range(retries + 1):
            try:
                return self._rpc(method, params)
            except MCPError as exc:
                last = exc
                time.sleep(0.2 * (attempt + 1))
                self.close()
            except Exception as exc:
                last = exc
                self.close()
        raise MCPError("call failed after retries: %r" % last)

    def close(self) -> None:
        try:
            if self.proc:
                self.proc.terminate()
        except Exception:
            pass
        self.proc = None


def list_servers(config: Optional[Path] = None) -> List[dict]:
    config = config or (Path(__file__).resolve().parent.parent.parent / ".savage" / "mcp.json")
    if Path(config).exists():
        return json.loads(Path(config).read_text()).get("servers", [])
    return []


def call(server_cmd: List[str], method: str, params: Optional[dict] = None) -> dict:
    c = MCPClient(server_cmd)
    try:
        return c.call(method, params)
    finally:
        c.close()
