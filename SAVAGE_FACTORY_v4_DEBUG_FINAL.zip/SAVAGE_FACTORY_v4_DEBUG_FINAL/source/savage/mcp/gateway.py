"""The GitHub middleman / MCP gateway.

Fixes the two things that break MCP fleets in practice:
  1. The -32000 EOF error (server died mid-call) -> retry + respawn.
  2. Flaky/absent credentials -> fall back to GitHub Models free inference.
"""
from __future__ import annotations

import json
import os
import urllib.request
from typing import Any, Dict, Optional


def self_test() -> bool:
    try:
        _ = json.dumps({"ok": True})
        return True
    except Exception:
        return False


def github_models(prompt: str, model: str = "openai/gpt-4o-mini",
                  token: Optional[str] = None) -> str:
    """Free inference via GitHub Models. Returns '' if unavailable."""
    token = token or os.environ.get("GITHUB_TOKEN", "")
    if not token:
        return ""
    url = "https://models.github.ai/inference/chat/completions"
    body = json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.2,
    }).encode()
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", "Bearer " + token)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            data = json.loads(r.read().decode())
        return data["choices"][0]["message"]["content"]
    except Exception:
        return ""


def route(method: str, params: Optional[dict] = None) -> Dict[str, Any]:
    """A tiny in-process gateway router used by the fleet config."""
    if method == "gateway.health":
        return {"ok": True, "has_token": bool(os.environ.get("GITHUB_TOKEN"))}
    if method == "gateway.github_models":
        params = params or {}
        return {"text": github_models(params.get("prompt", ""), params.get("model", "openai/gpt-4o-mini"))}
    return {"error": "unknown method: " + method}
