"""Central configuration + path resolution for the savage package."""
from __future__ import annotations

import os
from pathlib import Path


def repo_root() -> Path:
    env = os.environ.get("SAVAGE_ROOT")
    if env:
        return Path(env).expanduser().resolve()
    # savage/config.py -> savage/ -> repo root
    return Path(__file__).resolve().parent.parent


ROOT = repo_root()
SAVAGE_DIR = ROOT / "savage"
FACTORY_DIR = ROOT / "factory"
STATE_DIR = ROOT / ".savage"
LOG_DIR = STATE_DIR / "logs"
CACHE_DIR = STATE_DIR / "cache"
GOLDEN_DIR = ROOT / "factory" / "golden"
OUT_ROOT = ROOT / "builds"

STAGES = ("intake", "spec", "build", "verify", "package", "ship", "improve")

ROUTING = {
    "intake": "none",
    "spec": "premium",
    "build": "cheap",
    "verify": "premium",
    "package": "none",
    "ship": "none",
    "improve": "cheap",
}

DEFAULT_N = int(os.environ.get("SAVAGE_N", "8"))
DEFAULT_BUDGET_ROUNDS = int(os.environ.get("SAVAGE_BUDGET_ROUNDS", "4"))
DEFAULT_TIMEOUT = int(os.environ.get("SAVAGE_TIMEOUT", "120"))


def ensure_dirs() -> None:
    for d in (STATE_DIR, LOG_DIR, CACHE_DIR, GOLDEN_DIR, OUT_ROOT):
        d.mkdir(parents=True, exist_ok=True)
