"""Load the tool registry and enforce trust tiers.

Rule: only VERIFIED tools may gate a release.  Everything else may assist, but
may never be the thing that says "ship".
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List, Optional

from ..config import FACTORY_DIR

GATE_TIERS = ("verified",)


class Registry:
    def __init__(self, tools: List[dict]) -> None:
        self.tools = tools
        self.by_id: Dict[str, dict] = {t["id"]: t for t in tools}

    def get(self, tool_id: str) -> Optional[dict]:
        return self.by_id.get(tool_id)

    def by_group(self, group: str) -> List[dict]:
        return [t for t in self.tools if t.get("group") == group]

    def by_tier(self, tier: str) -> List[dict]:
        return [t for t in self.tools if t.get("tier") == tier]

    def summary(self) -> dict:
        out: Dict[str, int] = {}
        groups: Dict[str, int] = {}
        for t in self.tools:
            out[t["tier"]] = out.get(t["tier"], 0) + 1
            groups[t["group"]] = groups.get(t["group"], 0) + 1
        return {"total": len(self.tools), "by_tier": out, "by_group": groups}


def load(path: Optional[Path] = None) -> Registry:
    path = path or (FACTORY_DIR / "registry" / "tools.json")
    if not Path(path).exists():
        return Registry([])
    data = json.loads(Path(path).read_text())
    return Registry(data.get("tools", data if isinstance(data, list) else []))


def enforce_gate_tier(tool: dict) -> bool:
    """Return True only if the tool is allowed to gate a release."""
    return tool.get("tier") in GATE_TIERS
