"""The adopted-repo catalog, auto-registered on import."""
from __future__ import annotations

import json
from pathlib import Path

from ..config import SAVAGE_DIR

_CATALOG = SAVAGE_DIR / "undercover" / "catalog.json"
_REGISTERED = False


def ensure_registered(force: bool = False) -> dict:
    global _REGISTERED
    if _REGISTERED and not force:
        return {"registered": True, "cached": True}
    if _CATALOG.exists():
        _REGISTERED = True
        return {"registered": True, "path": str(_CATALOG)}
    return {"registered": False}


def load() -> list:
    if _CATALOG.exists():
        return json.loads(_CATALOG.read_text()).get("repos", [])
    return []
