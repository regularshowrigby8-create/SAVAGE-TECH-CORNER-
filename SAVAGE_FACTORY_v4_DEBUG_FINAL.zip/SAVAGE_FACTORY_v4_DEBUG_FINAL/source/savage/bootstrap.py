"""Idempotent, non-fatal, budget-capped bootstrap for the savage factory.

`ensure_ready()` runs a fixed list of steps, each guarded by a marker file so it
only runs once.  The whole thing is capped at SAVAGE_BOOTSTRAP_BUDGET seconds
(default 1.5s) and every failure is recorded, never raised.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

from . import config

_MARKER = config.STATE_DIR / ".bootstrapped"
_STEPS: list = []
_RESULTS: dict = {}


def step(fn):
    """Register a bootstrap step."""
    _STEPS.append(fn)
    return fn


def _record(name: str, ok: bool, detail: str = "") -> None:
    _RESULTS[name] = {"ok": ok, "detail": detail, "ts": time.time()}


@step
def _dirs() -> None:
    config.ensure_dirs()
    _record("dirs", True)


@step
def _deps() -> None:
    """Best-effort: only require stdlib. Optional deps are never fatal."""
    missing = []
    for mod in ("urllib.request", "json", "subprocess"):
        try:
            __import__(mod)
        except Exception:
            missing.append(mod)
    _record("deps", not missing, ",".join(missing))


@step
def _registry() -> None:
    reg = config.FACTORY_DIR / "registry" / "tools.json"
    _record("registry", reg.exists(), str(reg))


@step
def _mcp() -> None:
    cfg = config.STATE_DIR / "mcp.json"
    if not cfg.exists():
        cfg.write_text(json.dumps({"servers": [], "transport": "stdio"}, indent=2))
    _record("mcp", True, str(cfg))


@step
def _gateway() -> None:
    from .mcp import gateway  # local import; safe if missing
    ok = gateway.self_test()
    _record("gateway", ok)


@step
def _env() -> None:
    have = [k for k in (
        "GITHUB_TOKEN", "GROQ_API_KEY", "CEREBRAS_API_KEY", "GEMINI_API_KEY",
        "DEEPSEEK_API_KEY", "OPENROUTER_API_KEY", "MISTRAL_API_KEY",
        "TOGETHER_API_KEY",
    ) if os.environ.get(k)]
    _record("env", True, ",".join(have) or "no-keys (offline mode)")


def ensure_ready(force: bool = False) -> dict:
    """Run the bootstrap once.  Returns a dict of step results."""
    budget = float(os.environ.get("SAVAGE_BOOTSTRAP_BUDGET", "1.5"))
    start = time.time()
    if _MARKER.exists() and not force:
        try:
            return json.loads(_MARKER.read_text())
        except Exception:
            pass
    for fn in _STEPS:
        if time.time() - start > budget:
            _record(fn.__name__, False, "budget exceeded")
            break
        try:
            fn()
        except Exception as exc:  # non-fatal
            _record(fn.__name__, False, repr(exc))
    try:
        config.STATE_DIR.mkdir(parents=True, exist_ok=True)
        _MARKER.write_text(json.dumps(_RESULTS, indent=2))
    except Exception:
        pass
    return _RESULTS
