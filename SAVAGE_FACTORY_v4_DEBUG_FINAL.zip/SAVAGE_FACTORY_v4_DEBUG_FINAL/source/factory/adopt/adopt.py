"""The Adopter - analyse an existing repository and produce a KEEP/DELETE plan.

This is the answer to "what does the factory delete and what does it keep?".
It is dry-run first and NEVER deletes anything unless ``apply=True``.  The plan
is a plain, auditable manifest (``ADOPT.md`` + ``adopt_plan.json``) so a low-end
model can read exactly what will happen *before* it happens.

Categories
----------
KEEP     - never touched (VCS, docs, the factory itself, licenses).
DELETE   - safe to remove (caches, bytecode, vendored deps, editor junk).
MIRROR   - a duplicate tree that shadows a kept one; needs explicit confirmation.
REWRITE  - present but must be rewritten (hollow CI gates).
UNKNOWN  - left completely alone; the model decides.
"""
from __future__ import annotations

import fnmatch
import filecmp
import subprocess
import json
import os
import re
import shutil
from pathlib import Path
from typing import Dict, List

KEEP_PATTERNS = [
    ".git/**", ".gitignore", ".gitattributes", ".gitmodules",
    "README*", "LICENSE*", "CHANGELOG*", "CONTRIBUTING*", "CODE_OF_CONDUCT*",
    "SAVAGE_FACTORY.py", "savage/**", "factory/**", "docs/**", "tools/**",
    ".github/workflows/savage-factory-gate.yml",
    ".github/workflows/apk-cli.yml",
    ".github/workflows/cleaner.yml",
    ".github/workflows/improver.yml",
]

DELETE_PATTERNS = [
    # bytecode + caches
    "**/__pycache__/**", "**/__pycache__", "**/*.pyc", "**/*.pyo", "**/*.pyd",
    "**/.pytest_cache/**", "**/.mypy_cache/**", "**/.ruff_cache/**",
    "**/.tox/**", "**/.ipynb_checkpoints/**", ".savage/cache/**",
    "**/.cache/**",
    # vendored deps + build output
    "**/node_modules/**", "**/.next/**", "**/dist/**", "**/build/**",
    "**/*.egg-info/**", "**/.eggs/**",
    # OS + editor + log junk
    "**/.DS_Store", "**/Thumbs.db", "**/*.log", "**/*.tmp", "**/*.bak",
    "**/*.orig",
]

# Duplicate mirror trees: the classic `factory-2` vs `factories/factory-2` problem.
MIRROR_PAIRS = [("factory-2", "factories/factory-2"),
                ("factory-3", "factories/factory-3")]

REWRITE_PATTERNS = [".github/workflows/*.yml", ".github/workflows/*.yaml"]

# Substrings that mark a CI workflow as a *hollow* gate (it can never fail).
HOLLOW_CI = ("continue-on-error: true", "|| true", "|| exit 0")


def _match(rel: str, pat: str) -> bool:
    """Glob match with ``**`` support (fnmatch alone does not do globstar).

    Rules:
      * a bare pattern with no ``/`` (e.g. ``*.pyc``, ``README*``) matches the
        basename at any depth, including the repo root;
      * ``**/`` is stripped (it means "at any depth");
      * ``dir/**`` matches everything under ``dir`` (``dir`` may be a glob such
        as ``*.egg-info`` and may itself contain ``/``);
      * anything else is a suffix / direct glob match.
    """
    rel = rel.replace(os.sep, "/")
    name = rel.rsplit("/", 1)[-1]
    if pat.startswith("**/"):
        pat = pat[3:]
    if "/" not in pat:
        return fnmatch.fnmatch(name, pat)
    if pat.endswith("/**"):
        base = pat[:-3]
        if "/" in base:
            return (rel == base or rel.startswith(base + "/")
                    or ("/" + rel).find("/" + base + "/") != -1)
        return any(fnmatch.fnmatch(seg, base) for seg in rel.split("/")[:-1])
    return rel == pat or rel.endswith("/" + pat) or fnmatch.fnmatch(rel, pat)


def _classify(rel: str) -> str:
    # DELETE is evaluated first: caches and junk are always cleaned, even when
    # they live inside a kept tree (e.g. savage/__pycache__/x.pyc).  KEEP then
    # protects real source/docs/VCS; REWRITE flags hollow CI; the rest is UNKNOWN.
    for pat in DELETE_PATTERNS:
        if _match(rel, pat):
            return "DELETE"
    for pat in KEEP_PATTERNS:
        if _match(rel, pat):
            return "KEEP"
    for pat in REWRITE_PATTERNS:
        if _match(rel, pat):
            return "REWRITE"
    return "UNKNOWN"


def _same_tree(a: Path, b: Path) -> bool:
    """Return true only when both directory trees have identical files and bytes."""
    try:
        left = {str(x.relative_to(a)): x for x in a.rglob("*") if x.is_file()}
        right = {str(x.relative_to(b)): x for x in b.rglob("*") if x.is_file()}
        if set(left) != set(right):
            return False
        return all(x.read_bytes() == right[rel].read_bytes() for rel, x in left.items())
    except (OSError, ValueError):
        return False


def _dir_size(p: Path) -> int:
    if p.is_file():
        try:
            return p.stat().st_size
        except Exception:
            return 0
    total = 0
    for root, _, files in os.walk(p):
        for f in files:
            try:
                total += (Path(root) / f).stat().st_size
            except Exception:
                pass
    return total


def _hollow_ci(path: Path) -> List[str]:
    try:
        text = path.read_text(errors="ignore")
    except Exception:
        return []
    return [h for h in HOLLOW_CI if h in text]


def scan(root: str) -> Dict[str, List[dict]]:
    """Walk the repo and classify every path.  Read-only."""
    root = Path(root)
    buckets: Dict[str, List[dict]] = {"KEEP": [], "DELETE": [], "MIRROR": [],
                                      "REWRITE": [], "UNKNOWN": []}
    seen_dirs: set = set()
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d != ".git" or dirpath == str(root)]
        for name in files:
            p = Path(dirpath) / name
            rel = str(p.relative_to(root)).replace(os.sep, "/")
            cat = _classify(rel)
            entry = {"path": rel, "bytes": _dir_size(p), "category": cat}
            if cat == "REWRITE":
                hits = _hollow_ci(p)
                if hits:
                    entry["reason"] = "hollow CI gate: " + ", ".join(hits)
                else:
                    entry["category"] = "UNKNOWN"
            buckets[entry["category"]].append(entry)
        seen_dirs.add(dirpath)

    # duplicate mirror trees
    for a, b in MIRROR_PAIRS:
        pa, pb = root / a, root / b
        if pa.is_dir() and pb.is_dir():
            if _same_tree(pa, pb):
                buckets["MIRROR"].append({
                    "path": a, "bytes": _dir_size(pa), "category": "MIRROR",
                    "reason": "byte-identical duplicate of " + b + " (keep " + b + ")",
                    "keep": b,
                })
            else:
                buckets["UNKNOWN"].append({
                    "path": a, "bytes": _dir_size(pa), "category": "UNKNOWN",
                    "reason": "DRIFT: differs from " + b + "; never auto-delete",
                })

    for k in buckets:
        buckets[k].sort(key=lambda e: e["path"])
    return buckets


def plan(root: str) -> dict:
    """Return the full, auditable adoption plan (dry-run)."""
    root = Path(root)
    buckets = scan(root)
    reclaim = sum(e["bytes"] for e in buckets["DELETE"])
    mirror_bytes = sum(e["bytes"] for e in buckets["MIRROR"])
    return {
        "root": str(root),
        "dry_run": True,
        "counts": {k: len(v) for k, v in buckets.items()},
        "reclaim_bytes": reclaim,
        "mirror_bytes": mirror_bytes,
        "buckets": buckets,
        "rules": {
            "keep": KEEP_PATTERNS,
            "delete": DELETE_PATTERNS,
            "mirror": [list(p) for p in MIRROR_PAIRS],
            "rewrite": REWRITE_PATTERNS,
            "hollow_ci": list(HOLLOW_CI),
        },
    }


def _tracked(root: Path, rel: str) -> bool:
    try:
        p = subprocess.run(["git", "-C", str(root), "ls-files", "--error-unmatch", "--", rel],
                           capture_output=True, text=True, timeout=10)
        return p.returncode == 0
    except Exception:
        return False


def _safe_path(root: Path, rel: str) -> Path | None:
    try:
        root = root.resolve()
        p = (root / rel).resolve()
        return p if p.is_relative_to(root) else None
    except (OSError, ValueError):
        return None


def apply(plan_dict: dict, include_mirrors: bool = False) -> dict:
    """Execute only untracked DELETE/MIRROR entries; tracked evidence is preserved."""
    root = Path(plan_dict["root"]).resolve()
    removed: List[str] = []
    skipped: List[str] = []
    entries = list(plan_dict.get("buckets", {}).get("DELETE", []))
    if include_mirrors:
        entries += list(plan_dict.get("buckets", {}).get("MIRROR", []))
    for entry in entries:
        rel = entry["path"]
        p = _safe_path(root, rel)
        if p is None or _tracked(root, rel):
            skipped.append(rel)
            continue
        try:
            if p.is_dir():
                shutil.rmtree(p)
            elif p.exists():
                p.unlink()
            if not p.exists():
                removed.append(rel)
        except Exception as exc:
            skipped.append(rel + ": " + str(exc))
    return {"removed": removed, "skipped": skipped, "count": len(removed)}


def render_markdown(plan_dict: dict) -> str:
    """Human/agent-readable ADOPT.md."""
    c = plan_dict["counts"]
    lines = [
        "# ADOPT.md - what the factory keeps, deletes and rewrites",
        "",
        "Generated by SAVAGE FACTORY. This is a **dry-run plan**: nothing is",
        "deleted until you run `adopt --apply`.",
        "",
        "## Summary",
        "",
        "| Category | Files | Meaning |",
        "|---|---|---|",
        "| KEEP | %d | Never touched. |" % c.get("KEEP", 0),
        "| DELETE | %d | Safe to remove (%.1f KB reclaimable). |" % (
            c.get("DELETE", 0), plan_dict["reclaim_bytes"] / 1024),
        "| MIRROR | %d | Duplicate tree; needs explicit confirmation. |" % c.get("MIRROR", 0),
        "| REWRITE | %d | Hollow CI gate; must be rewritten. |" % c.get("REWRITE", 0),
        "| UNKNOWN | %d | Left alone; the model decides. |" % c.get("UNKNOWN", 0),
        "",
        "## KEEP (never touched)",
        "",
    ]
    for e in plan_dict["buckets"]["KEEP"][:80]:
        lines.append("- `%s`" % e["path"])
    lines += ["", "## DELETE (removed by `adopt --apply`)", ""]
    for e in plan_dict["buckets"]["DELETE"][:120]:
        lines.append("- `%s`" % e["path"])
    if not plan_dict["buckets"]["DELETE"]:
        lines.append("- (nothing)")
    lines += ["", "## MIRROR (duplicate trees - confirm before deleting)", ""]
    for e in plan_dict["buckets"]["MIRROR"]:
        lines.append("- `%s` - %s" % (e["path"], e.get("reason", "")))
    if not plan_dict["buckets"]["MIRROR"]:
        lines.append("- (none)")
    lines += ["", "## REWRITE (hollow CI gates - replace with the real gate)", ""]
    for e in plan_dict["buckets"]["REWRITE"]:
        lines.append("- `%s` - %s" % (e["path"], e.get("reason", "")))
    if not plan_dict["buckets"]["REWRITE"]:
        lines.append("- (none)")
    lines += [
        "",
        "## How to apply",
        "",
        "```bash",
        "python3 SAVAGE_FACTORY.py adopt            # dry-run (this report)",
        "python3 SAVAGE_FACTORY.py adopt --apply    # delete the DELETE bucket",
        "python3 SAVAGE_FACTORY.py adopt --apply --mirrors   # also delete mirrors",
        "```",
        "",
    ]
    return "\n".join(lines)
