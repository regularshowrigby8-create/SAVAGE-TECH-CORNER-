"""The Adopter space: analyse an existing repo and produce a KEEP/DELETE plan."""
from . import adopt

__all__ = ["adopt"]
