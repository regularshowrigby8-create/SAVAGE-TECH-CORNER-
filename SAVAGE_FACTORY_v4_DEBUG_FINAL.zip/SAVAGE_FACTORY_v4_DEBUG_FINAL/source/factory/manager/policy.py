"""Tier enforcement + stage routing policy."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List

STAGE_MODEL_CLASS = {
    "intake": "none", "spec": "premium", "build": "cheap", "verify": "premium",
    "package": "none", "ship": "none", "improve": "cheap",
}
GATE_TIERS = ("verified",)


class Policy:
    def __init__(self, registry_path: Path) -> None:
        self.registry_path = Path(registry_path)
        self.tools: Dict[str, dict] = {}
        if self.registry_path.exists():
            data = json.loads(self.registry_path.read_text())
            for t in data.get("tools", []):
                self.tools[t["id"]] = t

    def route(self, stage: str) -> str:
        return STAGE_MODEL_CLASS.get(stage, "cheap")

    def may_gate(self, tool_id: str) -> bool:
        t = self.tools.get(tool_id)
        return bool(t) and t.get("tier") in GATE_TIERS

    def check_job(self, job: dict) -> List[str]:
        errs = []
        stage = job.get("stage")
        if stage not in STAGE_MODEL_CLASS:
            errs.append("unknown stage: " + str(stage))
        for tool_id in job.get("gate_tools", []):
            if not self.may_gate(tool_id):
                errs.append("tool may not gate a release: " + tool_id)
        return errs
