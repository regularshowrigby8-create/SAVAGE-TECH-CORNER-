"""The Factory Manager loop: pop -> route -> execute -> gate -> ack.

Deterministic shell, agentic core.  The manager never lets an unverified tool
gate a release.
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Callable, Optional

from .queue import Queue
from .policy import Policy


class Manager:
    def __init__(self, root: Path, registry_path: Path,
                 handler: Optional[Callable[[dict], dict]] = None) -> None:
        self.queue = Queue(Path(root) / "queue")
        self.policy = Policy(registry_path)
        self.handler = handler or self._default_handler
        self.log = Path(root) / "manager.log"

    def _default_handler(self, job: dict) -> dict:
        stage = job.get("stage", "build")
        model_class = self.policy.route(stage)
        return {"stage": stage, "model_class": model_class, "status": "routed"}

    def _write_log(self, rec: dict) -> None:
        with open(self.log, "a") as f:
            f.write(json.dumps(rec) + "\n")

    def submit(self, stage: str, prompt: str, **kw) -> str:
        job = {"stage": stage, "prompt": prompt}
        job.update(kw)
        return self.queue.push(job)

    def step(self) -> Optional[dict]:
        job = self.queue.pop()
        if job is None:
            return None
        errs = self.policy.check_job(job)
        if errs:
            self.queue.ack(job, {"status": "REJECTED", "errors": errs})
            self._write_log({"job": job["id"], "status": "REJECTED", "errors": errs})
            return {"job": job, "status": "REJECTED", "errors": errs}
        try:
            result = self.handler(job)
            status = "OK"
        except Exception as exc:
            result = {"error": repr(exc)}
            status = "ERROR"
        self.queue.ack(job, result)
        self._write_log({"job": job["id"], "status": status, "result": result})
        return {"job": job, "status": status, "result": result}

    def run(self, max_jobs: int = 100, idle_sleep: float = 0.5) -> int:
        processed = 0
        while processed < max_jobs:
            out = self.step()
            if out is None:
                break
            processed += 1
        return processed
