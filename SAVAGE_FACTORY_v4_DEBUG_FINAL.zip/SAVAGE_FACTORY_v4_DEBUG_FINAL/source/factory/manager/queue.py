"""A durable JSONL job queue with O_EXCL lockfiles.

Crash-safe: every push is an fsync'd append; every pop is an atomic rename into
an in-flight file.  No database required.
"""
from __future__ import annotations

import json
import os
import time
import uuid
from pathlib import Path
from typing import Optional


class Queue:
    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.pending = self.root / "pending.jsonl"
        self.inflight = self.root / "inflight"
        self.done = self.root / "done.jsonl"
        self.inflight.mkdir(exist_ok=True)

    def _lock(self, name: str):
        p = self.root / (name + ".lock")
        try:
            fd = os.open(str(p), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            return fd, p
        except FileExistsError:
            return None, p

    def _unlock(self, fd, p) -> None:
        if fd is not None:
            try:
                os.close(fd)
            except Exception:
                pass
        try:
            p.unlink()
        except Exception:
            pass

    def push(self, job: dict) -> str:
        job = dict(job)
        job.setdefault("id", uuid.uuid4().hex)
        job.setdefault("ts", time.time())
        with open(self.pending, "a") as f:
            f.write(json.dumps(job) + "\n")
            f.flush()
            os.fsync(f.fileno())
        return job["id"]

    def pop(self) -> Optional[dict]:
        fd, lockp = self._lock("pop")
        if fd is None:
            return None
        try:
            if not self.pending.exists():
                return None
            lines = self.pending.read_text().splitlines()
            if not lines:
                return None
            head, rest = lines[0], lines[1:]
            job = json.loads(head)
            self.pending.write_text("\n".join(rest) + ("\n" if rest else ""))
            (self.inflight / (job["id"] + ".json")).write_text(json.dumps(job))
            return job
        finally:
            self._unlock(fd, lockp)

    def ack(self, job: dict, result: Optional[dict] = None) -> None:
        rec = dict(job)
        rec["result"] = result or {}
        rec["finished"] = time.time()
        with open(self.done, "a") as f:
            f.write(json.dumps(rec) + "\n")
        p = self.inflight / (job["id"] + ".json")
        if p.exists():
            p.unlink()

    def depth(self) -> int:
        if not self.pending.exists():
            return 0
        return len(self.pending.read_text().splitlines())
