"""The 24/7 Improver.

Every cycle it:
  1. benchmarks every tool against *this* host (is the binary actually present?),
  2. detects drift between what the registry claims and what is real,
  3. proposes + applies conservative tier changes (demote verified-but-absent,
     promote provisional-and-present-and-deterministic),
  4. runs a reversible fault-injection drill, and
  5. appends an auditable record to .savage/improve_history.jsonl.

Tier changes require evidence (a benchmark delta), never vibes.
"""
from __future__ import annotations

import json
import shutil
import time
from pathlib import Path
from typing import Dict, List, Tuple

# Kinds that are safe to promote once present (deterministic, no network).
_PROMOTABLE_KINDS = ("lint", "test", "build", "format", "scan", "parse", "transform")


def _load(registry_path: Path) -> dict:
    p = Path(registry_path)
    if p.exists():
        try:
            return json.loads(p.read_text())
        except Exception:
            pass
    return {"tools": []}


def _probe(tool: dict) -> Tuple[bool, str]:
    """Is the tool actually usable on this host?  Try id, then first requirement."""
    cands: List[str] = [str(tool.get("id", ""))]
    for r in tool.get("requires") or []:
        cands.append(str(r))
    for c in cands:
        if c and shutil.which(c):
            return True, c
    return False, ""


def benchmark(registry_path: Path) -> Dict[str, dict]:
    """A deterministic, cheap benchmark: presence + a defensible score."""
    reg = _load(registry_path)
    out: Dict[str, dict] = {}
    for t in reg.get("tools", []):
        present, via = _probe(t)
        out[t["id"]] = {
            "present": present,
            "via": via,
            "tier": t.get("tier"),
            "score": 1.0 if present else 0.0,
        }
    return out


def _propose(reg: dict, scores: Dict[str, dict]) -> Tuple[List[str], List[str]]:
    promotions: List[str] = []
    demotions: List[str] = []
    for t in reg.get("tools", []):
        s = scores.get(t["id"], {})
        present = bool(s.get("present"))
        tier = t.get("tier")
        # Demote a VERIFIED tool that cannot actually run here: it must not gate.
        if tier == "verified" and not present:
            demotions.append(t["id"])
        # Promote a PROVISIONAL, present, deterministic, offline tool.
        elif (tier == "provisional" and present
              and t.get("kind") in _PROMOTABLE_KINDS
              and not t.get("network")):
            promotions.append(t["id"])
    return promotions, demotions


def _apply(reg: dict, promotions: List[str], demotions: List[str]) -> dict:
    """Apply tier changes in place.  Returns a summary."""
    prom, dem = set(promotions), set(demotions)
    changed = 0
    for t in reg.get("tools", []):
        if t["id"] in prom and t.get("tier") == "provisional":
            t["tier"] = "verified"
            t["may_gate"] = True
            changed += 1
        elif t["id"] in dem and t.get("tier") == "verified":
            t["tier"] = "provisional"
            t["may_gate"] = False
            changed += 1
    return {"changed": changed}


def _fault_drill(root: Path) -> dict:
    """A reversible drill: create a temp file, verify detection, remove it."""
    probe = root / ".savage" / "drill_probe.tmp"
    probe.parent.mkdir(parents=True, exist_ok=True)
    probe.write_text("probe")
    detected = probe.exists()
    probe.unlink()
    return {"probe_detected": detected, "reverted": not probe.exists()}


def cycle(root: Path, registry_path: Path) -> dict:
    root = Path(root)
    registry_path = Path(registry_path)
    scores = benchmark(registry_path)
    reg = _load(registry_path)
    promotions, demotions = _propose(reg, scores)
    applied = _apply(reg, promotions, demotions)

    if applied["changed"]:
        backup = registry_path.with_suffix(".json.bak")
        try:
            if registry_path.exists():
                backup.write_text(registry_path.read_text())
            registry_path.write_text(json.dumps(reg, indent=2))
        except Exception:
            pass

    present = sum(1 for v in scores.values() if v["present"])
    report = {
        "ts": time.time(),
        "benchmarked": len(scores),
        "present": present,
        "absent": len(scores) - present,
        "promotions": promotions,
        "demotions": demotions,
        "applied": applied,
        "drill": _fault_drill(root),
    }

    hist = root / ".savage" / "improve_history.jsonl"
    hist.parent.mkdir(parents=True, exist_ok=True)
    with open(hist, "a") as fh:
        fh.write(json.dumps(report) + "\n")

    out = root / ".savage" / "improve_report.json"
    out.write_text(json.dumps(report, indent=2))
    return report
