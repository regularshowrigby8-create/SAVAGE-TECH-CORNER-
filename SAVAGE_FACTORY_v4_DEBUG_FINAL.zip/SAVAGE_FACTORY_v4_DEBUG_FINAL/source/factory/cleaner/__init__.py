"""Dry-run-first destructive maintenance."""
from .cleaner import plan, apply

__all__ = ["plan", "apply"]
