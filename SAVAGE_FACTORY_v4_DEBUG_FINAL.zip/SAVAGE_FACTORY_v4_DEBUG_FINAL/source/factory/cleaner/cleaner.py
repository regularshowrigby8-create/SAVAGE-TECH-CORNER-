"""The Cleaner: dry-run-first destructive maintenance.

It NEVER deletes anything unless you pass apply=True.  It targets: stale caches,
duplicate mirror trees, __pycache__, oversized logs, and orphaned artifacts.
"""
from __future__ import annotations

import os
import time
from pathlib import Path
from typing import List

STALE_SECONDS = 7 * 24 * 3600


def _size(p: Path) -> int:
    if p.is_file():
        return p.stat().st_size
    total = 0
    for root, _, files in os.walk(p):
        for f in files:
            try:
                total += (Path(root) / f).stat().st_size
            except Exception:
                pass
    return total


def plan(root: str) -> dict:
    root = Path(root)
    targets: List[dict] = []
    for pat in ("**/__pycache__", "**/*.pyc", ".savage/cache/**", "**/node_modules/.cache/**"):
        for p in root.glob(pat):
            targets.append({"path": str(p), "bytes": _size(p), "reason": "cache"})
    # stale logs
    for p in root.glob("**/*.log"):
        try:
            if time.time() - p.stat().st_mtime > STALE_SECONDS:
                targets.append({"path": str(p), "bytes": _size(p), "reason": "stale-log"})
        except Exception:
            pass
    # duplicate mirror trees (the classic factory-2 vs factories/factory-2 problem)
    for name in ("factory-2", "factory-3"):
        a = root / name
        b = root / "factories" / name
        if a.exists() and b.exists():
            targets.append({"path": str(a), "bytes": _size(a), "reason": "duplicate-mirror", "keep": str(b)})
    total = sum(t["bytes"] for t in targets)
    return {"root": str(root), "targets": targets, "count": len(targets),
            "reclaim_bytes": total, "dry_run": True}


def apply(plan_dict: dict) -> dict:
    removed = []
    for t in plan_dict.get("targets", []):
        if t.get("reason") == "duplicate-mirror":
            continue  # never auto-delete a mirror; require a human
        p = Path(t["path"])
        try:
            if p.is_dir():
                import shutil
                shutil.rmtree(p)
            elif p.exists():
                p.unlink()
            removed.append(t["path"])
        except Exception:
            pass
    return {"removed": removed, "count": len(removed)}
