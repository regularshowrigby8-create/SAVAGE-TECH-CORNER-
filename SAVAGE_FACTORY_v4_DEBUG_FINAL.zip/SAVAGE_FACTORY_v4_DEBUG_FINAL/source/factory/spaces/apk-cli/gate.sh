#!/usr/bin/env bash
# The APK-CLI release gate.  Only VERIFIED tools may certify.  Fails closed.
set -euo pipefail
OUT_DIR="${1:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)/artifacts/apk-cli}"
fail=0

echo "=== APK-CLI RELEASE GATE ==="

# 1. An APK must exist.
APK_COUNT=$(find "$OUT_DIR" -name '*.apk' 2>/dev/null | wc -l | tr -d ' ')
if [ "$APK_COUNT" -lt 1 ]; then
  echo "FAIL: no APK produced"; fail=1
else
  echo "PASS: $APK_COUNT APK(s) produced"
fi

# 2. Every APK must be a valid zip (catches truncated/corrupt files).
for apk in $(find "$OUT_DIR" -name '*.apk' 2>/dev/null); do
  if unzip -t "$apk" >/dev/null 2>&1; then
    echo "PASS: $apk is a valid zip"
  else
    echo "FAIL: $apk is corrupt"; fail=1
  fi
done

# 3. Provenance must exist.
if [ -f "$OUT_DIR/provenance.json" ]; then
  echo "PASS: provenance present"
else
  echo "FAIL: provenance.json missing"; fail=1
fi

# 4. No UTF-16LE-hidden package strings (anti-deception).
if command -v python3 >/dev/null 2>&1; then
  python3 - "$OUT_DIR" <<'PY' || fail=1
import sys, pathlib
root = pathlib.Path(sys.argv[1])
bad = []
for p in root.rglob('*.apk'):
    raw = p.read_bytes()
    for enc in ('utf-16-le', 'utf-16-be'):
        if 'acr.browser.barebones' in raw.decode(enc, 'ignore'):
            bad.append(str(p))
if bad:
    print('FAIL: hidden package string in', bad); sys.exit(1)
print('PASS: no hidden package strings')
PY
fi

if [ "$fail" -ne 0 ]; then
  echo "VERDICT: FAIL"; exit 1
fi
echo "VERDICT: PASS"
