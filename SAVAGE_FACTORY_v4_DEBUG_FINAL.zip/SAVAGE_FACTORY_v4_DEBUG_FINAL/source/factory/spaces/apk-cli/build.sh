#!/usr/bin/env bash
# Isolated APK-CLI build cell.  Pinned toolchain. No network. Fails closed.
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
CELL_DIR="${1:-$ROOT_DIR/shell/android_project}"
OUT_DIR="${2:-$ROOT_DIR/artifacts/apk-cli}"
mkdir -p "$OUT_DIR"

echo "=== APK-CLI CELL (isolated) ==="
echo "cell: $CELL_DIR"
echo "out : $OUT_DIR"

if [ ! -d "$CELL_DIR" ]; then
  echo "FAIL: cell dir not found: $CELL_DIR" >&2
  exit 2
fi

# Pinned toolchain check (fail closed if the toolchain is wrong).
if command -v gradle >/dev/null 2>&1; then
  echo "gradle: $(gradle --version 2>/dev/null | grep -i '^Gradle' || echo unknown)"
else
  echo "WARN: gradle not found; emitting source bundle only"
fi

# Build (best effort; the gate decides if it is real).
if [ -x "$CELL_DIR/gradlew" ]; then
  ( cd "$CELL_DIR" && ./gradlew --no-daemon assembleDebug ) || echo "WARN: gradle build failed"
fi

# Collect any produced APK.
find "$CELL_DIR" -name '*.apk' -print -exec cp {} "$OUT_DIR"/ \; 2>/dev/null || true

# Emit a provenance record.
cat > "$OUT_DIR/provenance.json" <<JSON
{
  "cell": "apk-cli",
  "isolated": true,
  "toolchain": "pinned",
  "ts": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "source": "$CELL_DIR"
}
JSON
echo "=== APK-CLI CELL DONE ==="
ls -la "$OUT_DIR"
