"""Programmatic driver for the isolated APK-CLI cell."""
from __future__ import annotations

import subprocess
from pathlib import Path


def build(cell_dir: str, out_dir: str) -> dict:
    here = Path(__file__).resolve().parent
    p = subprocess.run(["bash", str(here / "build.sh"), cell_dir, out_dir],
                       capture_output=True, text=True)
    return {"rc": p.returncode, "log": p.stdout + p.stderr}


def gate(out_dir: str) -> dict:
    here = Path(__file__).resolve().parent
    p = subprocess.run(["bash", str(here / "gate.sh"), out_dir],
                       capture_output=True, text=True)
    return {"rc": p.returncode, "passed": p.returncode == 0, "log": p.stdout + p.stderr}
