"""Isolated build spaces.  Only the APK-CLI space may emit a release binary."""
