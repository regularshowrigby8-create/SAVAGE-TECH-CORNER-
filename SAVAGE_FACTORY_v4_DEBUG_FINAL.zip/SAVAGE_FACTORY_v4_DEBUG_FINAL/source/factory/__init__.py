"""The factory machinery: manager, spaces, cleaner, improver."""
__version__ = "3.0.0"
