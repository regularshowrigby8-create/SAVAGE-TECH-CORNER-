import os
import subprocess
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
FACTORY = HERE / "SAVAGE_FACTORY.py"


def run(root, *args):
    return subprocess.run(["python3", str(FACTORY), "--root", str(root), *args],
                          text=True, capture_output=True)


class HardeningTests(unittest.TestCase):
    def test_clean_init_and_gate(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            self.assertEqual(run(root, "init").returncode, 0)
            self.assertEqual(run(root, "gate").returncode, 0)

    def test_gate_rejects_hollow_and_secret(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            self.assertEqual(run(root, "init").returncode, 0)
            (root / "bad.py").write_text(
                "raise NotImplementedError\nTOKEN=github_pat_abcdefghijklmnopqrstuvwxyz123456\n")
            result = run(root, "gate")
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("VERDICT: FAIL", result.stdout)

    def test_init_conflict_is_non_destructive(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            target = root / "docs/factory-v4/README.md"
            target.parent.mkdir(parents=True)
            target.write_text("keep this")
            result = run(root, "init")
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(target.read_text(), "keep this")

    def test_template_is_not_ship(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            self.assertEqual(run(root, "init").returncode, 0)
            result = run(root, "build", "build a tiny python cli tool", "-n", "2", "--rounds", "1")
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("TEMPLATE-ONLY", result.stdout)

    def test_adopt_preserves_tracked_delete_match(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            subprocess.run(["git", "init", "-q"], cwd=root, check=True)
            subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=root, check=True)
            subprocess.run(["git", "config", "user.name", "test"], cwd=root, check=True)
            tracked = root / "tracked.log"
            tracked.write_text("evidence")
            subprocess.run(["git", "add", "tracked.log"], cwd=root, check=True)
            subprocess.run(["git", "commit", "-qm", "init"], cwd=root, check=True)
            self.assertEqual(run(root, "init").returncode, 0)
            result = run(root, "adopt", "--apply")
            self.assertEqual(result.returncode, 0)
            self.assertTrue(tracked.exists())


if __name__ == "__main__":
    unittest.main()
