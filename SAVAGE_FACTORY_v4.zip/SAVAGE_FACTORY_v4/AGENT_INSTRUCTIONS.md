# AGENT INSTRUCTIONS — SAVAGE FACTORY

You are a model, possibly a small one. You do **not** need to understand the
code in `SAVAGE_FACTORY.py`. You only need to **run** it. Running it builds the whole
factory on disk, identically every time, and then the factory builds,
verifies, packages, ships and improves software with zero human intervention.

## STEP 1 — place the file

Put the single file at the root of your repository, named exactly:

```
SAVAGE_FACTORY.py
```

## STEP 2 — run these three commands, in order, from the repo root

```bash
python3 SAVAGE_FACTORY.py init      # materialise the factory (writes ~90 files)
python3 SAVAGE_FACTORY.py doctor    # self-verify; must print: VERDICT: ALL GREEN
python3 SAVAGE_FACTORY.py catalog   # print the 382-tool registry
```

## STEP 3 — done

If `doctor` prints `VERDICT: ALL GREEN`, the factory is real and working.
Nothing else is required. There is nothing to configure and no dependency to
install: this file uses only the Python standard library.

## STEP 4 (optional) — build something

```bash
python3 SAVAGE_FACTORY.py build "car racing game"
```

## STEP 5 (optional) — see what will be deleted/kept BEFORE anything changes

```bash
python3 SAVAGE_FACTORY.py adopt          # dry-run report (writes ADOPT.md)
python3 SAVAGE_FACTORY.py adopt --apply  # only then does it delete anything
```

## IF YOU ONLY RUN ONE THING

```bash
python3 SAVAGE_FACTORY.py all
```

`all` = init + doctor + catalog, in one shot.

## WHAT THIS FILE KEEPS AND DELETES IN YOUR EXISTING REPO

The factory is **additive by default**. `init` only ever **writes** new files
(`savage/`, `factory/`, `.github/workflows/`, `README.md`, `docs/`, `tools/`).
It never deletes or overwrites your existing work unless you pass `--force`.

Deletion is a separate, explicit, dry-run-first command: `adopt`. It
classifies every path into five buckets and writes them to `ADOPT.md`:

| Bucket  | Meaning | Touched by `--apply`? |
|---------|---------|-----------------------|
| KEEP    | `.git/`, `README*`, `LICENSE*`, `docs/`, the factory itself | never |
| DELETE  | `__pycache__/`, `*.pyc`, `node_modules/`, caches, junk | yes |
| MIRROR  | duplicate tree (e.g. `factory-2/`) | only with `--mirrors` |
| REWRITE | hollow CI gate (`continue-on-error: true`, `|| true`) | reported only |
| UNKNOWN | anything unrecognised | never |

So the answer to "what gets deleted?" is: **nothing**, until you run
`adopt --apply`. And even then, only the DELETE bucket. KEEP and UNKNOWN are
never touched.

## THE MODEL THIS FILE BUILDS

* **7 STAGES**: intake -> spec -> build -> verify -> package -> ship -> improve
* **4 TIERS**: VERIFIED / PROVISIONAL / UNVERIFIED / QUARANTINE.
  Only VERIFIED tools may gate a release.
* **10 LAYERS**: L1 Spec Amplifier, L2 Scaffold Selector, L3 Best-of-N
  Sampler, L4 Verifier/Ensemble, L5 Self-Repair Loop, L6 Constrained
  Decoding, L7 Golden Retrieval, L8 Deterministic Gates, L9 Sealed Holdout,
  L10 Worktree Isolation.
* **5 SPACES**: `factory/manager`, `factory/spaces/apk-cli`,
  `factory/cleaner`, `factory/improver`, `factory/adopt`.
* **1 BUS**: MCP (stdio JSON-RPC 2.0) — a 32-server fleet.

## DESIGN LAW

"Deterministic shell, agentic core." The workflow is plain Python + JSON.
Agents are bounded nodes. Nothing merges without a deterministic gate. No
piracy, no leaked keys, no ToS bypass, no faked results. Ever.

## HOW A LOW-END MODEL GETS PREMIUM OUTPUT

1. Run `init`. Everything appears. Nothing to interpret.
2. Run `doctor`. ALL GREEN means the factory is real and working.
3. Call `build("your idea")`. The harness amplifies the spec (L1), picks a
   scaffold (L2), samples N candidates in isolated worktrees (L3/L10),
   verifies with a DIFFERENT model (L4), repairs until the deterministic
   gates pass (L5/L8), then re-checks against a SEALED holdout the generator
   never saw (L9). It returns a verified artifact + a BuildResult.
4. That is it. The premium result comes from the harness, not the model.
