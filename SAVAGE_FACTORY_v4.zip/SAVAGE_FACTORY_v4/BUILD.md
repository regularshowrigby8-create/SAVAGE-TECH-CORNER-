# BUILD — SAVAGE FACTORY

Everything here is standard-library Python 3.11. There is nothing to install.

## 0. Materialise

```bash
python3 SAVAGE_FACTORY.py init
python3 SAVAGE_FACTORY.py doctor     # must end with: VERDICT: ALL GREEN
```

`init` is idempotent and additive. Re-running it only writes files that are
missing or changed; it never deletes. Pass `--force` to overwrite.

## 1. Build an artifact

```bash
python3 SAVAGE_FACTORY.py build "a CLI that converts CSV to JSON"
```

The premium harness runs the 10 layers:

1. **L1 Spec Amplifier** — turns a one-line prompt into a structured spec.
2. **L2 Scaffold Selector** — picks one of the shipped scaffolds.
3. **L3 Best-of-N Sampler** — generates N candidates.
4. **L10 Worktree Isolation** — each candidate gets a private, disposable
   workspace (a real `git worktree` when git is available, otherwise an
   isolated directory under `.worktrees/`).
5. **L4 Verifier/Ensemble** — scores candidates with a different model.
6. **L5 Self-Repair Loop** — repairs the best candidate until gates pass.
7. **L6 Constrained Decoding** — GBNF grammar keeps JSON well-formed.
8. **L7 Golden Retrieval** — pulls proven patterns from the golden store.
9. **L8 Deterministic Gates** — compile, tests, no-hollow, no-secrets.
10. **L9 Sealed Holdout** — re-verifies against a sealed check set the
    generator never saw. A build only "passes" if public **and** sealed pass.

## 2. Gate

```bash
python3 SAVAGE_FACTORY.py gate
```

Deterministic gates only. Only **VERIFIED** tools may gate a release.

## 3. Package & ship

The only release emitter is the isolated APK/CLI cell:

```bash
bash factory/spaces/apk-cli/build.sh
bash factory/spaces/apk-cli/gate.sh
```

Nothing else may emit a release artifact.

## 4. Maintain

```bash
python3 SAVAGE_FACTORY.py clean [--apply]   # dry-run by default
python3 SAVAGE_FACTORY.py improve           # one 24/7 improvement cycle
python3 SAVAGE_FACTORY.py adopt [--apply]   # keep/delete planner (dry-run first)
```

## 5. Rebuild this single file (only if you edited the sources)

```bash
python3 _parts/pack.py
cat _parts/01_data.py _parts/02_data2.py _parts/00_bundle.py _parts/06_runtime.py > SAVAGE_FACTORY.py
python3 -m py_compile SAVAGE_FACTORY.py
```
