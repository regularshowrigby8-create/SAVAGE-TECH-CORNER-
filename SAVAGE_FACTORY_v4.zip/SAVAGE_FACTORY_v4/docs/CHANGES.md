# CHANGES — what the factory adds, and what you should keep

This is the exact change list for adopting the factory into an existing repo.
Nothing here is destructive. `init` is additive; `adopt` is the only command
that deletes, and it is dry-run first.

## ADDED by `init` (new files; your existing files are untouched)

| Path | What it is |
|------|-----------|
| `SAVAGE_FACTORY.py` | the single-file factory you already have |
| `savage/` | the engine (bootstrap, config, llm, premium, registry, mcp, undercover) |
| `savage/premium/holdout.py` | L9 sealed holdout verifier |
| `savage/premium/worktree.py` | L10 worktree isolation |
| `factory/manager/` | routing + durable queue |
| `factory/spaces/apk-cli/` | isolated APK/CLI build cell (only release emitter) |
| `factory/cleaner/` | dry-run-first maintenance |
| `factory/improver/` | 24/7 self-improvement |
| `factory/adopt/` | keep/delete planner |
| `factory/registry/` | `tools.json`, `repos.json`, `mcp.json`, `tools.md` |
| `factory/rules/` | one rule set per stage |
| `.github/workflows/` | gate, apk-cli, cleaner, improver |
| `docs/` | `SAVAGE_FACTORY.md`, `ADOPT_RULES.md`, `CHANGES.md` |
| `tools/savage_factory.py` | thin CLI wrapper |
| `AGENT_INSTRUCTIONS.md` | one-page runbook for a model |
| `BUILD.md` | build / verify / ship guide |
| `README.md` | project readme (only if absent, unless `--force`) |

## KEPT — never modified, never deleted

* `.git/` and all history
* `README*`, `LICENSE*`, `NOTICE*`, `CHANGELOG*`, `CONTRIBUTING*`
* `docs/` and `doc/`
* every source file you already had that is not in a DELETE pattern
* the factory itself once installed

## DELETED — only by `adopt --apply`

* caches and bytecode: `__pycache__/`, `*.pyc`, `.pytest_cache/`, `.mypy_cache/`
* dependency/build dirs: `node_modules/`, `dist/`, `build/`, `.next/`
* OS/log junk: `.DS_Store`, `Thumbs.db`, `*.log`, `*.tmp`, `*.bak`

## DELETED — only by `adopt --apply --mirrors`

* duplicate trees such as `factory-2/` that are shadowed by `factories/factory-2/`

## REWRITTEN (by you, reported by `adopt`)

* hollow CI gates containing `continue-on-error: true` or `|| true` should be
  replaced with `.github/workflows/savage-factory-gate.yml`.

## UNKNOWN

* everything else — left exactly as it is.

## The one-line summary

**Run `python3 SAVAGE_FACTORY.py init`. It only adds. Run `python3 SAVAGE_FACTORY.py adopt` to
see the plan. Run `adopt --apply` only if you agree with the DELETE bucket.**
