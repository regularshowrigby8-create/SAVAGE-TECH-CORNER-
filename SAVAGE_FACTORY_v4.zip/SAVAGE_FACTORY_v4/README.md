# SAVAGE FACTORY — upload & run guide

**Deliverable: one file — `SAVAGE_FACTORY.py`** (≈250 KB, 3,360 lines, Python 3.11
standard library only, no dependencies). It is a complete multi-stage software
factory that materialises itself on disk when you run it.

---

## 1. What to do (the whole thing)

1. Put `SAVAGE_FACTORY.py` at the **root** of your GitHub repo (name it exactly
   `SAVAGE_FACTORY.py`).
2. Tell your low-end agent to run, from the repo root:

   ```bash
   python3 SAVAGE_FACTORY.py all
   ```

   `all` = `init` + `doctor` + `catalog`. If it prints **`VERDICT: ALL GREEN`**,
   the factory is real and working. There is nothing to install or configure.

That is the entire install. Everything else is optional.

---

## 2. Commands

| Command | What it does |
|---|---|
| `python3 SAVAGE_FACTORY.py all` | init + doctor + catalog (run this if unsure) |
| `python3 SAVAGE_FACTORY.py init` | write the factory (~98 files) — **additive, never deletes** |
| `python3 SAVAGE_FACTORY.py doctor` | self-verify → `VERDICT: ALL GREEN` |
| `python3 SAVAGE_FACTORY.py catalog` | print the 382-tool registry |
| `python3 SAVAGE_FACTORY.py build "your idea"` | run the 10-layer premium harness |
| `python3 SAVAGE_FACTORY.py gate` | deterministic gates |
| `python3 SAVAGE_FACTORY.py adopt` | **dry-run**: what would be kept / deleted |
| `python3 SAVAGE_FACTORY.py adopt --apply` | delete ONLY the DELETE bucket |
| `python3 SAVAGE_FACTORY.py adopt --apply --mirrors` | also delete duplicate trees |
| `python3 SAVAGE_FACTORY.py clean [--apply]` | cache maintenance (dry-run by default) |
| `python3 SAVAGE_FACTORY.py improve` | one 24/7 self-improvement cycle |
| `python3 SAVAGE_FACTORY.py mcp` | print the 32-server MCP fleet |

---

## 3. What it keeps and what it deletes in YOUR repo

`init` is **additive**: it only *writes* new files and never deletes or
overwrites your work unless you pass `--force`. Deletion is a separate,
**dry-run-first** command (`adopt`):

| Bucket | Meaning | Deleted by `--apply`? |
|---|---|---|
| **KEEP** | `.git/`, `README*`, `LICENSE*`, `docs/`, the factory itself | never |
| **DELETE** | `__pycache__/`, `*.pyc`, `node_modules/`, `dist/`, `build/`, `*.log`, caches | yes |
| **MIRROR** | duplicate tree (e.g. `factory-2/` shadowed by `factories/factory-2/`) | only with `--mirrors` |
| **REWRITE** | hollow CI gate (`continue-on-error: true`, `|| true`) | reported only |
| **UNKNOWN** | anything unrecognised | never |

So: **nothing is deleted until you run `adopt --apply`**, and even then only the
DELETE bucket. KEEP and UNKNOWN are never touched. Full rules:
`docs/ADOPT_RULES.md`; file-by-file change list: `docs/CHANGES.md` (both are
written by `init`).

---

## 4. What the factory is

* **7 stages** — intake → spec → build → verify → package → ship → improve
* **4 trust tiers** — VERIFIED / PROVISIONAL / UNVERIFIED / QUARANTINE
  (only VERIFIED may gate a release)
* **10-layer premium harness** — L1 spec amplifier, L2 scaffold selector,
  L3 best-of-N sampler, L4 verifier/ensemble, L5 self-repair, L6 constrained
  decoding, L7 golden retrieval, L8 deterministic gates, **L9 sealed holdout**,
  **L10 worktree isolation**
* **5 spaces** — `factory/manager`, `factory/spaces/apk-cli`, `factory/cleaner`,
  `factory/improver`, **`factory/adopt`**
* **1 bus** — MCP over stdio JSON-RPC 2.0, a 32-server fleet
* **382 tools**, **94 repos** in the corpus

Design law: **"deterministic shell, agentic core."** Nothing merges without a
deterministic gate. No piracy, no leaked keys, no ToS bypass, no faked results.

---

## 5. What's new in this version (v4.0.0)

* Single file renamed to **`SAVAGE_FACTORY.py`** with a **READ THIS FIRST** header
  that is the entire manual for a low-end model.
* **L9 Sealed Holdout** — a build only passes if it clears a sealed check set the
  generator never saw (anti-overfit / anti-deception).
* **L10 Worktree Isolation** — every candidate gets a private, disposable
  workspace (real `git worktree` when git is present, else an isolated dir).
* **`factory/adopt`** — the keep/delete planner that answers "what does it delete
  and what does it keep?" *before* anything is touched.
* **+24 factory-pattern repos** and **+39 tools** (group O), including sealed
  verification, worktree isolation, and the minimal/strong process-control
  factories.
* Generated docs: `AGENT_INSTRUCTIONS.md`, `BUILD.md`, `docs/ADOPT_RULES.md`,
  `docs/CHANGES.md`.

---

## 6. Verified (clean room)

```
init    -> 98 files, 382 tools, 94 repos, 32 MCP servers
doctor  -> VERDICT: ALL GREEN
catalog -> 382 tools, groups A..O
build   -> all 5 scaffolds SHIP (sealed holdout passes; isolation dir + worktree)
gate    -> VERDICT: PASS
adopt   -> dry-run / --apply / --mirrors all correct
clean   -> dry-run + --apply OK
improve -> OK        mcp -> live stdio JSON-RPC OK
import savage -> auto-run OK
```
